# OpenAPI Examples Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 15 | 13 | 1 | 0 | 1 | 0 |

## Unexpected Failures

- **specs/openapi/examples/convert-example-to-partial.spec.ts**: specs/openapi/examples/convert-example-to-partial.spec.ts › Example Generation › Convert generated example to partial for 'test-openapi/examples/product_search_bff_v5_convert_to_partial.yaml'
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-examples-con-a5f03-v5-convert-to-partial-yaml--chromium/test-failed-1.png`
  - Error Preview:
````
Error: Waiting for examples list or details view to become visible

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
````

## Expected Failures

- **specs/openapi/examples/edit-save-validate-fix-examples.spec.ts**: specs/openapi/examples/edit-save-validate-fix-examples.spec.ts › Edit, save, validate and fix examples › Edit, save and validate examples for 'products' path of the 'test-openapi/examples/product_search_bff_v5_examples_validate_and_fix.yaml' for response codes 200
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-examples-edi-df0f0-yaml-for-response-codes-200-chromium/test-finished-1.png`
  - Error Preview:
````
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 6
````
