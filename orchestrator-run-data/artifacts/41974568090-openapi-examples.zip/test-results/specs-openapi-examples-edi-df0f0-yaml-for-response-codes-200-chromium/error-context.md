# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/examples/edit-save-validate-fix-examples.spec.ts >> Edit, save, validate and fix examples >> Edit, save and validate examples for 'products' path of the 'test-openapi/examples/product_search_bff_v5_examples_validate_and_fix.yaml' for response codes 200
- Location: specs/openapi/examples/edit-save-validate-fix-examples.spec.ts:10:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 1
Received: 6
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_examples_validate_and_fix.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_examples_validate_and_fix.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/examples/product_search_bff_v5_examples_validate_and_fix.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - generic [ref=e40]:
          - generic [ref=e42]:
            - button "Save & Validate" [ref=e43] [cursor=pointer]
            - button "Fix Example" [ref=e44] [cursor=pointer]
            - button "Convert To Partial" [ref=e45] [cursor=pointer]
          - generic [ref=e47]:
            - generic [ref=e48]:
              - button "← Go Back" [ref=e49] [cursor=pointer]
              - list [ref=e50]:
                - listitem [ref=e51]:
                  - generic [ref=e52]: "Path:"
                  - generic [ref=e53]: /products
                - listitem [ref=e54]:
                  - generic [ref=e55]: "Method:"
                  - generic [ref=e56]: POST
                - listitem [ref=e57]:
                  - generic [ref=e58]: "Request:"
                  - generic [ref=e59]: application/json
                - listitem [ref=e60]:
                  - generic [ref=e61]: "Response:"
                  - generic [ref=e62]: 201 application/json
            - list [ref=e63]:
              - listitem [ref=e64]:
                - generic [ref=e65]:
                  - paragraph [ref=e66]:
                    - generic [ref=e67]: "File path: ./test-openapi/examples/product_search_bff_v5_examples_validate_and_fix_examples/"
                    - generic [ref=e70]:
                      - generic [ref=e71]:
                        - generic "createProduct_application_json_201_application_json_1.json" [ref=e72]
                        - generic:
                          - generic:
                            - generic: Filename
                            - textbox [disabled]
                      - button "Rename createProduct_application_json_201_application_json_1.json" [ref=e73] [cursor=pointer]
                  - generic [ref=e75]:
                    - generic "External example" [ref=e76]: External
                    - generic [ref=e77]: Invalid Example
                - generic [ref=e78]:
                  - generic [ref=e79] [cursor=pointer]:
                    - img [ref=e80]
                    - paragraph [ref=e82]: Example has 2 Errors
                  - generic [ref=e83]: ">> http-response.status R1001: Type mismatch Documentation: https://docs.specmatic.io/rules#r1001 Summary: The value type does not match the expected type defined in the specification Example format expected type number, but example contained value \"201\" of type string No matching specification found for this example"
                - generic [ref=e88]:
                  - generic [ref=e89]:
                    - generic [ref=e90]:
                      - generic [ref=e91]: "1"
                      - generic [ref=e92]: "2"
                      - generic [ref=e93]: "3"
                      - generic [ref=e94]: "4"
                      - generic [ref=e95]: "5"
                      - generic [ref=e96]: "6"
                      - generic [ref=e97]: "7"
                      - generic [ref=e98]: "8"
                      - generic [ref=e99]: "9"
                      - generic [ref=e100]: "10"
                      - generic [ref=e101]: "11"
                      - generic [ref=e102]: "12"
                      - generic [ref=e103]: "13"
                      - generic [ref=e104]: "14"
                      - generic [ref=e105]: "15"
                      - generic [ref=e106]: "16"
                      - generic [ref=e107]: "17"
                      - generic [ref=e108]: "18"
                      - generic [ref=e109]: "19"
                      - generic [ref=e110]: "20"
                      - generic [ref=e111]: "21"
                      - generic [ref=e112]: "22"
                      - generic [ref=e113]: "23"
                      - generic [ref=e114]: "24"
                    - generic [ref=e115]:
                      - generic [ref=e116]: ⌄
                      - generic [ref=e117]: ⌄
                      - generic [ref=e118]: ⌄
                      - generic [ref=e119]: ⌄
                      - generic [ref=e121]: ⌄
                      - generic [ref=e122]: ⌄
                      - generic [ref=e123]: ⌄
                  - textbox [ref=e128]:
                    - generic [ref=e129]: "{"
                    - generic [ref=e130]: "\"http-request\": {"
                    - generic [ref=e131]: "\"path\": \"/products\","
                    - generic [ref=e132]: "\"method\": \"POST\","
                    - generic [ref=e133]: "\"headers\": {"
                    - generic [ref=e134]: "\"Content-Type\": \"application/json\""
                    - generic [ref=e135]: "},"
                    - generic [ref=e136]: "\"body\": {"
                    - generic [ref=e137]: "\"name\": \"Galago leomelanochaitus\","
                    - generic [ref=e138]: "\"type\": \"book\","
                    - generic [ref=e139]: "\"inventory\": \"10\""
                    - generic [ref=e140]: "}"
                    - generic [ref=e141]: "},"
                    - generic [ref=e142]: "\"http-response\": {"
                    - generic [ref=e143]:
                      - generic [ref=e144]: "\"status\": \"201\""
                      - text: ","
                    - generic [ref=e145]: "\"body\": {"
                    - generic [ref=e146]: "\"id\": 831"
                    - generic [ref=e147]: "},"
                    - generic [ref=e148]: "\"status-text\": \"Created\","
                    - generic [ref=e149]: "\"headers\": {"
                    - generic [ref=e150]: "\"Content-Type\": \"application/json\""
                    - generic [ref=e151]: "}"
                    - generic [ref=e152]: "}"
                    - generic [ref=e153]: "}"
        - generic [ref=e155]:
          - list [ref=e156]:
            - listitem [ref=e157] [cursor=pointer]:
              - img "success" [ref=e158]
              - paragraph [ref=e159]: "Success:"
              - generic [ref=e160]: "0"
            - listitem [ref=e161] [cursor=pointer]:
              - img "failed" [ref=e162]
              - paragraph [ref=e163]: "Failed:"
              - generic [ref=e164]: "0"
            - listitem [ref=e165] [cursor=pointer]:
              - img "skipped" [ref=e166]
              - paragraph [ref=e167]: "Skipped:"
              - generic [ref=e168]: "0"
            - listitem [ref=e169] [cursor=pointer]:
              - img "total-tests" [ref=e170]
              - paragraph [ref=e171]: "Total:"
              - generic [ref=e172]: "0"
          - generic [ref=e173]:
            - textbox "Port" [ref=e175]
            - button "Run" [ref=e176] [cursor=pointer]
        - generic [ref=e180]:
          - text: ⚠
          - list [ref=e181]:
            - listitem [ref=e182] [cursor=pointer]:
              - img "success" [ref=e183]
              - paragraph [ref=e184]: "Success:"
              - generic [ref=e185]: "0"
            - listitem [ref=e186] [cursor=pointer]:
              - img "failed" [ref=e187]
              - paragraph [ref=e188]: "Failed:"
              - generic [ref=e189]: "0"
            - listitem [ref=e190] [cursor=pointer]:
              - img "skipped" [ref=e191]
              - paragraph [ref=e192]: "Skipped:"
              - generic [ref=e193]: "0"
            - listitem [ref=e194] [cursor=pointer]:
              - img "excluded" [ref=e195]
              - paragraph [ref=e196]: "Excluded:"
              - generic [ref=e197]: "0"
            - listitem [ref=e198] [cursor=pointer]:
              - img "total-tests" [ref=e199]
              - paragraph [ref=e200]: "Total:"
              - generic [ref=e201]: "0"
          - generic [ref=e202]:
            - generic [ref=e203]:
              - generic [ref=e204]:
                - checkbox [ref=e205]
                - generic [ref=e206]: Generative
              - textbox "Service URL" [ref=e208]: http://localhost:8080
            - button "Run" [ref=e209] [cursor=pointer]
        - generic [ref=e212]:
          - generic [ref=e214]:
            - generic "Switch between preview and editor" [ref=e215]:
              - generic [ref=e216]: Preview
              - button "Toggle editor view" [ref=e217] [cursor=pointer]
              - generic [ref=e219]: Editor
            - button "Test Backward Compatibility" [ref=e220] [cursor=pointer]
            - button "Generate Dictionary" [ref=e221] [cursor=pointer]
          - generic [ref=e224]:
            - generic:
              - img
            - generic [ref=e225]:
              - generic [ref=e229]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e231]:
                  - text: Order BFF
                  - generic [ref=e232]:
                    - generic [ref=e234]: "5.0"
                    - generic [ref=e236]: OAS 3.0
                - paragraph [ref=e239]: Sample Order BFF
                - link "Contact the developer" [ref=e241] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e244]:
                - heading "WIP API still under development" [level=3] [ref=e247] [cursor=pointer]:
                  - generic [ref=e248]: WIP
                  - paragraph [ref=e251]: API still under development
                  - button "Collapse operation" [expanded] [ref=e252]:
                    - img [ref=e253]
                - generic [ref=e256]:
                  - heading "Product Product Related APIs" [level=3] [ref=e257] [cursor=pointer]:
                    - generic [ref=e258]: Product
                    - paragraph [ref=e261]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e262]:
                      - img [ref=e263]
                  - generic [ref=e266]:
                    - generic [ref=e269] [cursor=pointer]:
                      - button "POST /products" [ref=e270]:
                        - generic [ref=e271]: POST
                        - generic [ref=e274]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e277]:
                        - img [ref=e278]
                    - generic [ref=e282] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e283]:
                        - generic [ref=e284]: GET
                        - generic [ref=e287]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e290]:
                        - img [ref=e291]
                - generic [ref=e294]:
                  - heading "Order Order Related APIs" [level=3] [ref=e295] [cursor=pointer]:
                    - generic [ref=e296]: Order
                    - paragraph [ref=e299]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e300]:
                      - img [ref=e301]
                  - generic [ref=e307] [cursor=pointer]:
                    - button "POST /ordres" [ref=e308]:
                      - generic [ref=e309]: POST
                      - generic [ref=e312]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e315]:
                      - img [ref=e316]
                - generic [ref=e319]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e320] [cursor=pointer]:
                    - generic [ref=e321]: Monitor
                    - paragraph [ref=e324]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e325]:
                      - img [ref=e326]
                  - generic [ref=e332] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e333]':
                      - generic [ref=e334]: GET
                      - generic [ref=e338]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e341]':
                      - img [ref=e342]
              - generic [ref=e346]:
                - heading "Schemas" [level=4] [ref=e347] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e348]:
                    - generic [ref=e349]: Schemas
                    - img [ref=e350]
                - generic [ref=e352]:
                  - button "ProductInventory" [ref=e355] [cursor=pointer]:
                    - generic [ref=e357]: ProductInventory
                  - button "Product Type" [ref=e360] [cursor=pointer]:
                    - generic [ref=e362]: Product Type
                  - button "MonitorLink" [ref=e365] [cursor=pointer]:
                    - generic [ref=e367]: MonitorLink
                  - button "Id" [ref=e370] [cursor=pointer]:
                    - generic [ref=e372]: Id
                  - button "Product Details" [ref=e375] [cursor=pointer]:
                    - generic [ref=e377]: Product Details
                  - button "Product" [ref=e380] [cursor=pointer]:
                    - generic [ref=e382]: Product
                  - button "CreatedOn" [ref=e385] [cursor=pointer]:
                    - generic [ref=e387]: CreatedOn
                  - button "Order Details" [ref=e390] [cursor=pointer]:
                    - generic [ref=e392]: Order Details
                  - button "Order" [ref=e395] [cursor=pointer]:
                    - generic [ref=e397]: Order
                  - button "MonitorResponse" [ref=e400] [cursor=pointer]:
                    - generic [ref=e402]: MonitorResponse
                  - button "Request" [ref=e405] [cursor=pointer]:
                    - generic [ref=e407]: Request
                  - button "Response" [ref=e410] [cursor=pointer]:
                    - generic [ref=e412]: Response
                  - button "HeaderItem" [ref=e415] [cursor=pointer]:
                    - generic [ref=e417]: HeaderItem
                  - button "Bad Request" [ref=e420] [cursor=pointer]:
                    - generic [ref=e422]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  53  |   examplePage: ExampleGenerationPage,
  54  |   page: Page,
  55  |   eyes: Eyes,
  56  | ) {
  57  |   await test.step(`Validate the fixed example and verify details`, async () => {
  58  |     await examplePage.saveEditedExample("Valid Example");
  59  | 
  60  |     await takeAndAttachScreenshot(
  61  |       page,
  62  |       "Edited, fixed and validated example",
  63  |       eyes,
  64  |     );
  65  |   });
  66  | }
  67  | 
  68  | async function fixExampleWithAutoCorrection(
  69  |   examplePage: ExampleGenerationPage,
  70  | ) {
  71  |   await test.step(`Fix example with auto-fix and verify details`, async () => {
  72  |     await examplePage.fixExampleWithAutoFix();
  73  |   });
  74  | }
  75  | 
  76  | async function verifyInvalidExampleDetails(examplePage: ExampleGenerationPage) {
  77  |   await test.step(`Verify invalid example details`, async () => {
  78  |     const [errorCount, errorBlob] =
  79  |       await examplePage.getDetailsOfErrorsInExample();
  80  |     console.log(
  81  |       "Validation errors in example:",
  82  |       JSON.stringify({ errorCount, errorBlob }, null, 2),
  83  |     );
  84  | 
  85  |     expect.soft(errorCount).toBe(2);
  86  |     expect
  87  |       .soft(errorBlob)
  88  |       .toContain(
  89  |         `Property "inventy" in the example was not in the specification. Did you mean "inventory"?`,
  90  |       );
  91  |     expect
  92  |       .soft(errorBlob)
  93  |       .toContain(
  94  |         `Property "idty" in the example was not in the specification. Did you mean "id"?`,
  95  |       );
  96  |   });
  97  | }
  98  | 
  99  | async function makeInvalidEditsInExample(examplePage: ExampleGenerationPage) {
  100 |   await test.step(`Make invalid edits in example`, async () => {
  101 |     const edits: Edit[] = [
  102 |       {
  103 |         current: { mode: "keyAndAnyNumber", key: "inventory" },
  104 |         changeTo: '"inventy": "10"',
  105 |       },
  106 |       {
  107 |         current: { mode: "keyAndAnyNumber", key: "id" },
  108 |         changeTo: '"idty": "abc"',
  109 |       },
  110 |     ];
  111 |     await examplePage.editExample(edits);
  112 |     await examplePage.saveEditedExample("Invalid Example");
  113 |   });
  114 | }
  115 | 
  116 | async function makeTypeMismatchEditsInExample(
  117 |   examplePage: ExampleGenerationPage,
  118 | ) {
  119 |   await test.step(`Make type-mismatch edits — status and inventory as strings`, async () => {
  120 |     const edits: Edit[] = [
  121 |       {
  122 |         current: { mode: "keyAndAnyNumber", key: "status" },
  123 |         changeTo: '"status": "201",',
  124 |       },
  125 |       {
  126 |         current: { mode: "keyAndAnyNumber", key: "inventory" },
  127 |         changeTo: '"inventory": "10"',
  128 |       },
  129 |     ];
  130 |     await examplePage.editExample(edits);
  131 |     await examplePage.saveEditedExample("Invalid Example");
  132 |   });
  133 | }
  134 | 
  135 | async function verifyCollapsedErrorSummary(
  136 |   examplePage: ExampleGenerationPage,
  137 |   expectedCount: number,
  138 | ) {
  139 |   await test.step(`Verify collapsed error summary shows ${expectedCount} error(s)`, async () => {
  140 |     const collapsedCount = await examplePage.getCollapsedErrorSummaryCount();
  141 |     console.log(`Collapsed summary error count: ${collapsedCount}`);
  142 |     expect.soft(collapsedCount).toBe(expectedCount);
  143 |   });
  144 | }
  145 | 
  146 | async function verifyExpandedErrorBlocks(
  147 |   examplePage: ExampleGenerationPage,
  148 |   expectedBlockCount: number,
  149 | ) {
  150 |   await test.step(`Expand error dropdown and verify ${expectedBlockCount} error block(s) visible`, async () => {
  151 |     const visibleBlocks = await examplePage.getVisibleErrorBlockCount();
  152 |     console.log(`Visible error blocks after expanding: ${visibleBlocks}`);
> 153 |     expect.soft(visibleBlocks).toBe(expectedBlockCount);
      |                                ^ Error: expect(received).toBe(expected) // Object.is equality
  154 |   });
  155 | }
  156 | 
```