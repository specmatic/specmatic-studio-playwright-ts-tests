# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/examples/convert-example-to-partial.spec.ts >> Example Generation >> Convert generated example to partial for 'test-openapi/examples/product_search_bff_v5_convert_to_partial.yaml'
- Location: specs/openapi/examples/convert-example-to-partial.spec.ts:11:7

# Error details

```
Error: Waiting for examples list or details view to become visible

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_convert_to_partial.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_convert_to_partial.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/examples/product_search_bff_v5_convert_to_partial.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - generic [ref=e42]:
          - button "Inline" [ref=e43] [cursor=pointer]
          - button "Export" [ref=e44] [cursor=pointer]
          - button "Generate" [ref=e45] [cursor=pointer]
          - button "Validate" [ref=e46] [cursor=pointer]
          - button "Fix" [ref=e47] [cursor=pointer]
          - button "Delete" [ref=e48] [cursor=pointer]
        - generic [ref=e51]:
          - list [ref=e52]:
            - listitem [ref=e53] [cursor=pointer]:
              - img "success" [ref=e54]
              - paragraph [ref=e55]: "Success:"
              - generic [ref=e56]: "0"
            - listitem [ref=e57] [cursor=pointer]:
              - img "failed" [ref=e58]
              - paragraph [ref=e59]: "Failed:"
              - generic [ref=e60]: "0"
            - listitem [ref=e61] [cursor=pointer]:
              - img "skipped" [ref=e62]
              - paragraph [ref=e63]: "Skipped:"
              - generic [ref=e64]: "0"
            - listitem [ref=e65] [cursor=pointer]:
              - img "total-tests" [ref=e66]
              - paragraph [ref=e67]: "Total:"
              - generic [ref=e68]: "0"
          - generic [ref=e69]:
            - textbox "Port" [ref=e71]
            - button "Run" [ref=e72] [cursor=pointer]
        - generic [ref=e76]:
          - text: ⚠
          - list [ref=e77]:
            - listitem [ref=e78] [cursor=pointer]:
              - img "success" [ref=e79]
              - paragraph [ref=e80]: "Success:"
              - generic [ref=e81]: "0"
            - listitem [ref=e82] [cursor=pointer]:
              - img "failed" [ref=e83]
              - paragraph [ref=e84]: "Failed:"
              - generic [ref=e85]: "0"
            - listitem [ref=e86] [cursor=pointer]:
              - img "skipped" [ref=e87]
              - paragraph [ref=e88]: "Skipped:"
              - generic [ref=e89]: "0"
            - listitem [ref=e90] [cursor=pointer]:
              - img "excluded" [ref=e91]
              - paragraph [ref=e92]: "Excluded:"
              - generic [ref=e93]: "0"
            - listitem [ref=e94] [cursor=pointer]:
              - img "total-tests" [ref=e95]
              - paragraph [ref=e96]: "Total:"
              - generic [ref=e97]: "0"
          - generic [ref=e98]:
            - generic [ref=e99]:
              - generic [ref=e100]:
                - checkbox [ref=e101]
                - generic [ref=e102]: Generative
              - textbox "Service URL" [ref=e104]: http://localhost:8080
            - button "Run" [ref=e105] [cursor=pointer]
        - generic [ref=e108]:
          - generic [ref=e110]:
            - generic "Switch between preview and editor" [ref=e111]:
              - generic [ref=e112]: Preview
              - button "Toggle editor view" [ref=e113] [cursor=pointer]
              - generic [ref=e115]: Editor
            - button "Test Backward Compatibility" [ref=e116] [cursor=pointer]
            - button "Generate Dictionary" [ref=e117] [cursor=pointer]
          - generic [ref=e120]:
            - img [ref=e122]
            - generic [ref=e123]:
              - generic [ref=e127]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e129]:
                  - text: Order BFF
                  - generic [ref=e130]:
                    - generic [ref=e132]: "5.0"
                    - generic [ref=e134]: OAS 3.0
                - paragraph [ref=e137]: Sample Order BFF
                - link "Contact the developer" [ref=e139] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e142]:
                - heading "WIP API still under development" [level=3] [ref=e145]:
                  - generic [ref=e146]: WIP
                  - paragraph [ref=e149]: API still under development
                  - button "Collapse operation" [expanded] [ref=e150] [cursor=pointer]:
                    - img [ref=e151]
                - generic [ref=e154]:
                  - heading "Product Product Related APIs" [level=3] [ref=e155]:
                    - generic [ref=e156]: Product
                    - paragraph [ref=e159]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e160] [cursor=pointer]:
                      - img [ref=e161]
                  - generic [ref=e164]:
                    - generic [ref=e167]:
                      - button "POST /products" [ref=e168] [cursor=pointer]:
                        - text: POST
                        - generic [ref=e171]: /products
                      - generic "Copy to clipboard" [ref=e172]:
                        - img [ref=e173]
                      - button "post /products" [ref=e176] [cursor=pointer]:
                        - img [ref=e177]
                    - generic [ref=e181]:
                      - button "GET /findAvailableProducts" [ref=e182] [cursor=pointer]:
                        - text: GET
                        - generic [ref=e185]: /findAvailableProducts
                      - generic "Copy to clipboard" [ref=e186]:
                        - img [ref=e187]
                      - button "get /findAvailableProducts" [ref=e190] [cursor=pointer]:
                        - img [ref=e191]
                - generic [ref=e194]:
                  - heading "Order Order Related APIs" [level=3] [ref=e195]:
                    - generic [ref=e196]: Order
                    - paragraph [ref=e199]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e200] [cursor=pointer]:
                      - img [ref=e201]
                  - generic [ref=e207]:
                    - button "POST /ordres" [ref=e208] [cursor=pointer]:
                      - text: POST
                      - generic [ref=e211]: /ordres
                    - generic "Copy to clipboard" [ref=e212]:
                      - img [ref=e213]
                    - button "post /ordres" [ref=e216] [cursor=pointer]:
                      - img [ref=e217]
                - generic [ref=e220]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e221]:
                    - generic [ref=e222]: Monitor
                    - paragraph [ref=e225]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e226] [cursor=pointer]:
                      - img [ref=e227]
                  - generic [ref=e233]:
                    - 'button "GET /monitor/{id}" [ref=e234] [cursor=pointer]':
                      - text: GET
                      - generic [ref=e238]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard" [ref=e239]:
                      - img [ref=e240]
                    - 'button "get /monitor/{id}" [ref=e243] [cursor=pointer]':
                      - img [ref=e244]
              - generic [ref=e248]:
                - heading "Schemas" [level=4] [ref=e249]:
                  - button "Schemas" [expanded] [ref=e250] [cursor=pointer]:
                    - text: Schemas
                    - img [ref=e251]
                - generic [ref=e253]:
                  - button "ProductInventory" [ref=e256] [cursor=pointer]:
                    - generic [ref=e258]: ProductInventory
                  - button "Product Type" [ref=e261] [cursor=pointer]:
                    - generic [ref=e263]: Product Type
                  - button "MonitorLink" [ref=e266] [cursor=pointer]:
                    - generic [ref=e268]: MonitorLink
                  - button "Id" [ref=e271] [cursor=pointer]:
                    - generic [ref=e273]: Id
                  - button "Product Details" [ref=e276] [cursor=pointer]:
                    - generic [ref=e278]: Product Details
                  - button "Product" [ref=e281] [cursor=pointer]:
                    - generic [ref=e283]: Product
                  - button "CreatedOn" [ref=e286] [cursor=pointer]:
                    - generic [ref=e288]: CreatedOn
                  - button "Order Details" [ref=e291] [cursor=pointer]:
                    - generic [ref=e293]: Order Details
                  - button "Order" [ref=e296] [cursor=pointer]:
                    - generic [ref=e298]: Order
                  - button "MonitorResponse" [ref=e301] [cursor=pointer]:
                    - generic [ref=e303]: MonitorResponse
                  - button "Request" [ref=e306] [cursor=pointer]:
                    - generic [ref=e308]: Request
                  - button "Response" [ref=e311] [cursor=pointer]:
                    - generic [ref=e313]: Response
                  - button "HeaderItem" [ref=e316] [cursor=pointer]:
                    - generic [ref=e318]: HeaderItem
                  - button "Bad Request" [ref=e321] [cursor=pointer]:
                    - generic [ref=e323]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  822  |       await expect(row).toBeVisible({ timeout: 5000 });
  823  | 
  824  |       const rowCheckbox = row.locator('input[type="checkbox"]').first();
  825  |       await expect(rowCheckbox).toBeVisible({ timeout: 3000 });
  826  |       await rowCheckbox.check({ force: true });
  827  | 
  828  |       const bulkDeleteBtn = root.locator(this.bulkDeleteBtnSelector);
  829  |       await expect(bulkDeleteBtn).toBeVisible({ timeout: 3000 });
  830  |       await bulkDeleteBtn.click();
  831  | 
  832  |       await this.verifyTitleAndCloseDialog(this.protocol === "async" ? "Examples deleted" : "Delete Examples Complete");
  833  |       await expect(this.getInlineRows(name, context)).toHaveCount(0, { timeout: 5000});
  834  |     });
  835  |   }
  836  | 
  837  |   private async selectAll(root: Locator) {
  838  |     const selectAll = root.locator(this.selectAllCheckboxSelector);
  839  |     await selectAll.waitFor({ timeout: 3000 });
  840  |     const count = await selectAll.count();
  841  |     console.log(`\tselect-all checkbox found, count: ${count}`);
  842  | 
  843  |     if (count === 0) {
  844  |       throw new Error(
  845  |         `selectAll: No checkboxes found for selector '${this.selectAllCheckboxSelector}'`,
  846  |       );
  847  |     }
  848  | 
  849  |     for (let i = 0; i < count; i++) {
  850  |       await this.setCheckboxChecked(
  851  |         selectAll.nth(i),
  852  |         true,
  853  |         `select-all checkbox[${i}]`,
  854  |       );
  855  |     }
  856  | 
  857  |     await takeAndAttachScreenshot(this.page, `select-all-checked`);
  858  |   }
  859  | 
  860  |   private async uncheckSelectAll(root: Locator) {
  861  |     const selectAll = root.locator(this.selectAllCheckboxSelector);
  862  |     await selectAll.waitFor({ timeout: 3000 });
  863  |     console.log("\tuncheck select-all checkbox found");
  864  |     if (await selectAll.isChecked()) {
  865  |       await this.setCheckboxChecked(
  866  |         selectAll.first(),
  867  |         false,
  868  |         "select-all checkbox",
  869  |       );
  870  |       console.log("\tselect-all checkbox unchecked");
  871  |       await takeAndAttachScreenshot(this.page, `select-all-unchecked`);
  872  |     }
  873  |   }
  874  | 
  875  |   private async setCheckboxChecked(
  876  |     checkbox: Locator,
  877  |     checked: boolean,
  878  |     label: string,
  879  |   ) {
  880  |     await expect(checkbox).toBeAttached({ timeout: 5000 });
  881  |     await expect(checkbox).toBeEnabled({ timeout: 5000 });
  882  | 
  883  |     for (let attempt = 1; attempt <= 3; attempt++) {
  884  |       await checkbox.scrollIntoViewIfNeeded().catch(() => {});
  885  | 
  886  |       try {
  887  |         if (checked) {
  888  |           await checkbox.check({ force: true, timeout: 2000 });
  889  |         } else {
  890  |           await checkbox.uncheck({ force: true, timeout: 2000 });
  891  |         }
  892  |       } catch (error) {
  893  |         console.log(
  894  |           `\t${label} ${checked ? "check" : "uncheck"} attempt ${attempt} failed: ${error}`,
  895  |         );
  896  |         await checkbox.evaluate((element, targetChecked) => {
  897  |           const input = element as HTMLInputElement;
  898  |           if (input.checked !== targetChecked) {
  899  |             input.click();
  900  |           }
  901  |         }, checked);
  902  |       }
  903  | 
  904  |       const currentState = await checkbox.isChecked();
  905  |       console.log(
  906  |         `\t${label} checked after attempt ${attempt}: ${currentState}`,
  907  |       );
  908  |       if (currentState === checked) {
  909  |         return;
  910  |       }
  911  | 
  912  |       await this.page.waitForTimeout(200 * attempt);
  913  |     }
  914  | 
  915  |     throw new Error(
  916  |       `${label} could not be ${checked ? "checked" : "unchecked"} after 3 attempts`,
  917  |     );
  918  |   }
  919  | 
  920  |   async waitForExamplesIFrame() {
  921  |     await this.examplesRoot.waitFor({ state: "visible", timeout: 10000 });
> 922  |     await expect
       |     ^ Error: Waiting for examples list or details view to become visible
  923  |       .poll(
  924  |         async () => {
  925  |           const locator = this.examplesRoot.locator(
  926  |             "table.examples-protocol-table, .examples-empty, #examples, code-editor .cm-content, .examples-detail-issues, #back",
  927  |           );
  928  |           const count = await locator.count();
  929  |           for (let i = 0; i < count; i++) {
  930  |             if (
  931  |               await locator
  932  |                 .nth(i)
  933  |                 .isVisible()
  934  |                 .catch(() => false)
  935  |             ) {
  936  |               return true;
  937  |             }
  938  |           }
  939  |           return false;
  940  |         },
  941  |         {
  942  |           timeout: 10000,
  943  |           intervals: [200, 400, 800],
  944  |           message:
  945  |             "Waiting for examples list or details view to become visible",
  946  |         },
  947  |       )
  948  |       .toBeTruthy();
  949  |     console.log("\tExamples panel is visible");
  950  |     return this.examplesRoot;
  951  |   }
  952  | 
  953  |   private async waitForExamplesContentReady(
  954  |     iframe: import("@playwright/test").Frame,
  955  |   ) {
  956  |     await expect
  957  |       .poll(
  958  |         async () => {
  959  |           const locator = this.examplesRoot.locator(
  960  |             "table.examples-protocol-table, #valid-examples-table, #invalid-examples-table, .examples-empty, #examples, code-editor .cm-content, .examples-detail-issues, #back, table",
  961  |           );
  962  |           const count = await locator.count();
  963  |           for (let i = 0; i < count; i++) {
  964  |             if (
  965  |               await locator
  966  |                 .nth(i)
  967  |                 .isVisible()
  968  |                 .catch(() => false)
  969  |             ) {
  970  |               return true;
  971  |             }
  972  |           }
  973  |           return false;
  974  |         },
  975  |         {
  976  |           timeout: 10000,
  977  |           intervals: [200, 400, 800],
  978  |           message: "Waiting for examples iframe content to become interactive",
  979  |         },
  980  |       )
  981  |       .toBeTruthy();
  982  |   }
  983  | 
  984  |   private async getGeneratedExamplesCount(
  985  |     iframe: import("@playwright/test").Frame,
  986  |   ): Promise<number> {
  987  |     return await iframe.locator("tr[data-example-relative-path]").count();
  988  |   }
  989  | 
  990  |   private async getInteractiveSelectAllCheckbox(
  991  |     iframe: import("@playwright/test").Frame,
  992  |   ): Promise<Locator> {
  993  |     const selectAll = iframe.locator(this.selectAllCheckboxSelector);
  994  |     await selectAll.first().waitFor({ state: "attached", timeout: 5000 });
  995  | 
  996  |     const count = await selectAll.count();
  997  |     console.log(`\tselect-all checkbox found, count: ${count}`);
  998  | 
  999  |     for (let i = 0; i < count; i++) {
  1000 |       const checkbox = selectAll.nth(i);
  1001 |       const [visible, enabled] = await Promise.all([
  1002 |         checkbox.isVisible().catch(() => false),
  1003 |         checkbox.isEnabled().catch(() => false),
  1004 |       ]);
  1005 | 
  1006 |       console.log(
  1007 |         `\tselect-all checkbox[${i}] visible=${visible} enabled=${enabled}`,
  1008 |       );
  1009 | 
  1010 |       if (visible && enabled) {
  1011 |         return checkbox;
  1012 |       }
  1013 |     }
  1014 | 
  1015 |     return selectAll.first();
  1016 |   }
  1017 | 
  1018 |   async validateAllExamples() {
  1019 |     await test.step(`Validate all generated examples`, async () => {
  1020 |       console.log(`Validating all generated examples`);
  1021 |       const root = await this.waitForExamplesIFrame();
  1022 |       const generatedExamplesBeforeValidation =
```