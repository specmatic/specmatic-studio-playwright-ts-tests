# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/update-service-spec/fix-spec-typo.spec.ts >> Fix Spec Typo - Conditional Update >> Fix /ordres typo to /orders when it exists
- Location: specs/openapi/update-service-spec/fix-spec-typo.spec.ts:11:7

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: "Changes are backward compatible"
Received: "49 passed of 49 scenarios"
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_fix_typo.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_fix_typo.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/spec-editing/product_search_bff_v5_fix_typo.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - table [ref=e43]:
          - rowgroup [ref=e44]:
            - row "S. No Path Method Request Response Examples Action" [ref=e45]:
              - columnheader [ref=e46]:
                - checkbox [ref=e48]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e49]:
            - row "/products POST application/json 201 application/json Generate" [ref=e50]:
              - cell [ref=e51]:
                - checkbox [ref=e52]
              - cell [ref=e53]
              - cell "/products" [ref=e54]
              - cell "POST" [ref=e55]:
                - paragraph [ref=e56]: POST
              - cell "application/json" [ref=e57]:
                - paragraph [ref=e58]: application/json
              - cell "201 application/json" [ref=e59]:
                - paragraph [ref=e60]: "201"
                - generic [ref=e61]: application/json
              - cell "Generate" [ref=e62]:
                - button "Generate" [ref=e64] [cursor=pointer]
              - cell [ref=e65]
            - row "202 Generate" [ref=e66]:
              - cell [ref=e67]:
                - checkbox [ref=e68]
              - cell [ref=e69]
              - cell "202" [ref=e70]:
                - paragraph [ref=e71]: "202"
              - cell "Generate" [ref=e72]:
                - button "Generate" [ref=e74] [cursor=pointer]
              - cell [ref=e75]
            - row "400 application/json Generate" [ref=e76]:
              - cell [ref=e77]:
                - checkbox [ref=e78]
              - cell [ref=e79]
              - cell "400 application/json" [ref=e80]:
                - paragraph [ref=e81]: "400"
                - generic [ref=e82]: application/json
              - cell "Generate" [ref=e83]:
                - button "Generate" [ref=e85] [cursor=pointer]
              - cell [ref=e86]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e87]:
              - cell [ref=e88]:
                - checkbox [ref=e89]
              - cell [ref=e90]
              - cell "/findAvailableProducts" [ref=e91]
              - cell "GET" [ref=e92]:
                - paragraph [ref=e93]: GET
              - cell "NA" [ref=e94]:
                - paragraph [ref=e95]: NA
              - cell "200 application/json" [ref=e96]:
                - paragraph [ref=e97]: "200"
                - generic [ref=e98]: application/json
              - cell "Generate" [ref=e99]:
                - button "Generate" [ref=e101] [cursor=pointer]
              - cell [ref=e102]
            - row "429 Generate" [ref=e103]:
              - cell [ref=e104]:
                - checkbox [ref=e105]
              - cell [ref=e106]
              - cell "429" [ref=e107]:
                - paragraph [ref=e108]: "429"
              - cell "Generate" [ref=e109]:
                - button "Generate" [ref=e111] [cursor=pointer]
              - cell [ref=e112]
            - row "400 application/json Generate" [ref=e113]:
              - cell [ref=e114]:
                - checkbox [ref=e115]
              - cell [ref=e116]
              - cell "400 application/json" [ref=e117]:
                - paragraph [ref=e118]: "400"
                - generic [ref=e119]: application/json
              - cell "Generate" [ref=e120]:
                - button "Generate" [ref=e122] [cursor=pointer]
              - cell [ref=e123]
            - row "/orders POST application/json 201 application/json Generate" [ref=e124]:
              - cell [ref=e125]:
                - checkbox [ref=e126]
              - cell [ref=e127]
              - cell "/orders" [ref=e128]
              - cell "POST" [ref=e129]:
                - paragraph [ref=e130]: POST
              - cell "application/json" [ref=e131]:
                - paragraph [ref=e132]: application/json
              - cell "201 application/json" [ref=e133]:
                - paragraph [ref=e134]: "201"
                - generic [ref=e135]: application/json
              - cell "Generate" [ref=e136]:
                - button "Generate" [ref=e138] [cursor=pointer]
              - cell [ref=e139]
            - row "202 Generate" [ref=e140]:
              - cell [ref=e141]:
                - checkbox [ref=e142]
              - cell [ref=e143]
              - cell "202" [ref=e144]:
                - paragraph [ref=e145]: "202"
              - cell "Generate" [ref=e146]:
                - button "Generate" [ref=e148] [cursor=pointer]
              - cell [ref=e149]
            - row "400 application/json Generate" [ref=e150]:
              - cell [ref=e151]:
                - checkbox [ref=e152]
              - cell [ref=e153]
              - cell "400 application/json" [ref=e154]:
                - paragraph [ref=e155]: "400"
                - generic [ref=e156]: application/json
              - cell "Generate" [ref=e157]:
                - button "Generate" [ref=e159] [cursor=pointer]
              - cell [ref=e160]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e161]':
              - cell [ref=e162]:
                - checkbox [ref=e163]
              - cell [ref=e164]
              - 'cell "/monitor/{id}" [ref=e165]'
              - cell "GET" [ref=e166]:
                - paragraph [ref=e167]: GET
              - cell "NA" [ref=e168]:
                - paragraph [ref=e169]: NA
              - cell "200 application/json" [ref=e170]:
                - paragraph [ref=e171]: "200"
                - generic [ref=e172]: application/json
              - cell "Generate" [ref=e173]:
                - button "Generate" [ref=e175] [cursor=pointer]
              - cell [ref=e176]
            - row "400 application/json Generate" [ref=e177]:
              - cell [ref=e178]:
                - checkbox [ref=e179]
              - cell [ref=e180]
              - cell "400 application/json" [ref=e181]:
                - paragraph [ref=e182]: "400"
                - generic [ref=e183]: application/json
              - cell "Generate" [ref=e184]:
                - button "Generate" [ref=e186] [cursor=pointer]
              - cell [ref=e187]
        - generic [ref=e189]:
          - list [ref=e190]:
            - listitem [ref=e191] [cursor=pointer]:
              - img "success" [ref=e192]
              - paragraph [ref=e193]: "Success:"
              - generic [ref=e194]: "0"
            - listitem [ref=e195] [cursor=pointer]:
              - img "failed" [ref=e196]
              - paragraph [ref=e197]: "Failed:"
              - generic [ref=e198]: "0"
            - listitem [ref=e199] [cursor=pointer]:
              - img "skipped" [ref=e200]
              - paragraph [ref=e201]: "Skipped:"
              - generic [ref=e202]: "0"
            - listitem [ref=e203] [cursor=pointer]:
              - img "total-tests" [ref=e204]
              - paragraph [ref=e205]: "Total:"
              - generic [ref=e206]: "0"
          - generic [ref=e207]:
            - textbox "Port" [ref=e209]
            - button "Run" [ref=e210] [cursor=pointer]
        - generic [ref=e214]:
          - text: ⚠
          - list [ref=e215]:
            - listitem [ref=e216] [cursor=pointer]:
              - img "success" [ref=e217]
              - paragraph [ref=e218]: "Success:"
              - generic [ref=e219]: "0"
            - listitem [ref=e220] [cursor=pointer]:
              - img "failed" [ref=e221]
              - paragraph [ref=e222]: "Failed:"
              - generic [ref=e223]: "0"
            - listitem [ref=e224] [cursor=pointer]:
              - img "skipped" [ref=e225]
              - paragraph [ref=e226]: "Skipped:"
              - generic [ref=e227]: "0"
            - listitem [ref=e228] [cursor=pointer]:
              - img "wip" [ref=e229]
              - paragraph [ref=e230]: "Wip:"
              - generic [ref=e231]: "0"
            - listitem [ref=e232] [cursor=pointer]:
              - img "excluded" [ref=e233]
              - paragraph [ref=e234]: "Excluded:"
              - generic [ref=e235]: "0"
            - listitem [ref=e236] [cursor=pointer]:
              - img "total-tests" [ref=e237]
              - paragraph [ref=e238]: "Total:"
              - generic [ref=e239]: "0"
          - generic [ref=e240]:
            - generic [ref=e241]:
              - generic [ref=e242]:
                - checkbox [ref=e243]
                - generic [ref=e244]: Generative
              - textbox "Service URL" [ref=e246]: http://localhost:8080
            - button "Run" [ref=e247] [cursor=pointer]
        - generic [ref=e250]:
          - generic [ref=e252]:
            - generic "Switch between preview and editor" [ref=e253]:
              - generic [ref=e254]: Preview
              - button "Toggle editor view" [pressed] [ref=e255] [cursor=pointer]
              - generic [ref=e257]: Editor
            - button "Test Backward Compatibility" [ref=e258] [cursor=pointer]
            - button "Generate Dictionary" [ref=e259] [cursor=pointer]
          - generic [ref=e265]:
            - generic [ref=e266]:
              - generic [ref=e267]:
                - generic [ref=e268]: "50"
                - generic [ref=e269]: "51"
                - generic [ref=e270]: "52"
                - generic [ref=e271]: "53"
                - generic [ref=e272]: "54"
                - generic [ref=e273]: "55"
                - generic [ref=e274]: "56"
                - generic [ref=e275]: "57"
                - generic [ref=e276]: "58"
                - generic [ref=e277]: "59"
                - generic [ref=e278]: "60"
                - generic [ref=e279]: "61"
                - generic [ref=e280]: "62"
                - generic [ref=e281]: "63"
                - generic [ref=e282]: "64"
                - generic [ref=e283]: "65"
                - generic [ref=e284]: "66"
                - generic [ref=e285]: "67"
                - generic [ref=e286]: "68"
                - generic [ref=e287]: "69"
                - generic [ref=e288]: "70"
                - generic [ref=e289]: "71"
                - generic [ref=e290]: "72"
                - generic [ref=e291]: "73"
                - generic [ref=e292]: "74"
                - generic [ref=e293]: "75"
                - generic [ref=e294]: "76"
                - generic [ref=e295]: "77"
                - generic [ref=e296]: "78"
                - generic [ref=e297]: "79"
                - generic [ref=e298]: "80"
                - generic [ref=e299]: "81"
                - generic [ref=e300]: "82"
                - generic [ref=e301]: "83"
                - generic [ref=e302]: "84"
                - generic [ref=e303]: "85"
                - generic [ref=e304]: "86"
                - generic [ref=e305]: "87"
                - generic [ref=e306]: "88"
                - generic [ref=e307]: "89"
                - generic [ref=e308]: "90"
                - generic [ref=e309]: "91"
                - generic [ref=e310]: "92"
                - generic [ref=e311]: "93"
                - generic [ref=e312]: "94"
                - generic [ref=e313]: "95"
                - generic [ref=e314]: "96"
                - generic [ref=e315]: "97"
                - generic [ref=e316]: "98"
                - generic [ref=e317]: "99"
                - generic [ref=e318]: "100"
                - generic [ref=e319]: "101"
                - generic [ref=e320]: "102"
                - generic [ref=e321]: "103"
                - generic [ref=e322]: "104"
                - generic [ref=e323]: "105"
                - generic [ref=e324]: "106"
                - generic [ref=e325]: "107"
                - generic [ref=e326]: "108"
                - generic [ref=e327]: "109"
                - generic [ref=e328]: "110"
                - generic [ref=e329]: "111"
                - generic [ref=e330]: "112"
                - generic [ref=e331]: "113"
                - generic [ref=e332]: "114"
                - generic [ref=e333]: "115"
                - generic [ref=e334]: "116"
                - generic [ref=e335]: "117"
                - generic [ref=e336]: "118"
                - generic [ref=e337]: "119"
                - generic [ref=e338]: "120"
                - generic [ref=e339]: "121"
                - generic [ref=e340]: "122"
                - generic [ref=e341]: "123"
                - generic [ref=e342]: "124"
                - generic [ref=e343]: "125"
                - generic [ref=e344]: "126"
                - generic [ref=e345]: "127"
                - generic [ref=e346]: "128"
                - generic [ref=e347]: "129"
                - generic [ref=e348]: "130"
                - generic [ref=e349]: "131"
                - generic [ref=e350]: "132"
                - generic [ref=e351]: "133"
                - generic [ref=e352]: "134"
                - generic [ref=e353]: "135"
                - generic [ref=e354]: "136"
                - generic [ref=e355]: "137"
                - generic [ref=e356]: "138"
                - generic [ref=e357]: "139"
                - generic [ref=e358]: "140"
                - generic [ref=e359]: "141"
                - generic [ref=e360]: "142"
                - generic [ref=e361]: "143"
                - generic [ref=e362]: "144"
                - generic [ref=e363]: "145"
                - generic [ref=e364]: "146"
                - generic [ref=e365]: "147"
                - generic [ref=e366]: "148"
                - generic [ref=e367]: "149"
                - generic [ref=e368]: "150"
              - generic [ref=e369]:
                - generic [ref=e370]: ⌄
                - generic [ref=e371]: ⌄
                - generic [ref=e372]: ⌄
                - generic [ref=e373]: ⌄
                - generic [ref=e374]: ⌄
                - generic [ref=e375]: ⌄
                - generic [ref=e376]: ⌄
                - generic [ref=e377]: ⌄
                - generic [ref=e378]: ⌄
                - generic [ref=e379]: ⌄
                - generic [ref=e380]: ⌄
                - generic [ref=e381]: ⌄
                - generic [ref=e382]: ⌄
                - generic [ref=e383]: ⌄
                - generic [ref=e384]: ⌄
                - generic [ref=e385]: ⌄
                - generic [ref=e386]: ⌄
                - generic [ref=e387]: ⌄
                - generic [ref=e388]: ⌄
                - generic [ref=e389]: ⌄
                - generic [ref=e390]: ⌄
                - generic [ref=e391]: ⌄
                - generic [ref=e392]: ⌄
                - generic [ref=e393]: ⌄
                - generic [ref=e394]: ⌄
                - generic [ref=e395]: ⌄
                - generic [ref=e396]: ⌄
                - generic [ref=e397]: ⌄
                - generic [ref=e398]: ⌄
                - generic [ref=e399]: ⌄
                - generic [ref=e400]: ⌄
                - generic [ref=e401]: ⌄
                - generic [ref=e402]: ⌄
                - generic [ref=e403]: ⌄
                - generic [ref=e404]: ⌄
                - generic [ref=e405]: ⌄
                - generic [ref=e406]: ⌄
                - generic [ref=e407]: ⌄
                - generic [ref=e408]: ⌄
                - generic [ref=e409]: ⌄
                - generic [ref=e410]: ⌄
                - generic [ref=e411]: ⌄
                - generic [ref=e412]: ⌄
                - generic [ref=e413]: ⌄
                - generic [ref=e414]: ⌄
                - generic [ref=e415]: ⌄
                - generic [ref=e416]: ⌄
                - generic [ref=e417]: ⌄
                - generic [ref=e418]: ⌄
                - generic [ref=e419]: ⌄
                - generic [ref=e420]: ⌄
                - generic [ref=e421]: ⌄
                - generic [ref=e422]: ⌄
                - generic [ref=e423]: ⌄
                - generic [ref=e424]: ⌄
                - generic [ref=e425]: ⌄
            - textbox [ref=e428]:
              - generic [ref=e430]: "$ref: \"#/components/schemas/BadRequest\""
              - generic [ref=e431]: "/findAvailableProducts:"
              - generic [ref=e432]: "parameters:"
              - generic [ref=e433]: "- schema:"
              - generic [ref=e434]: "$ref: \"#/components/schemas/ProductType\""
              - generic [ref=e435]: "name: type"
              - generic [ref=e436]: "in: query"
              - generic [ref=e437]: "required: false"
              - generic [ref=e438]: "- name: pageSize"
              - generic [ref=e439]: "in: header"
              - generic [ref=e440]: "schema:"
              - generic [ref=e441]: "type: integer"
              - generic [ref=e442]: "required: true"
              - generic [ref=e443]: "- name: from-date"
              - generic [ref=e444]: "in: query"
              - generic [ref=e445]: "required: true"
              - generic [ref=e446]: "schema:"
              - generic [ref=e447]: "type: string"
              - generic [ref=e448]: "format: date"
              - generic [ref=e449]: "- name: to-date"
              - generic [ref=e450]: "in: query"
              - generic [ref=e451]: "required: true"
              - generic [ref=e452]: "schema:"
              - generic [ref=e453]: "type: string"
              - generic [ref=e454]: "format: date"
              - generic [ref=e455]: "get:"
              - generic [ref=e456]: "description: Find available products"
              - generic [ref=e457]: "operationId: findAvailableProducts"
              - generic [ref=e458]: "tags:"
              - generic [ref=e459]: "- Product"
              - generic [ref=e460]: "responses:"
              - generic [ref=e461]: "\"200\":"
              - generic [ref=e462]: "description: OK"
              - generic [ref=e463]: "content:"
              - generic [ref=e464]: "application/json:"
              - generic [ref=e465]: "schema:"
              - generic [ref=e466]: "type: array"
              - generic [ref=e467]: "items:"
              - generic [ref=e468]: "$ref: \"#/components/schemas/Product\""
              - generic [ref=e469]: "\"429\":"
              - generic [ref=e470]: "description: TooManyRequests"
              - generic [ref=e471]: "headers:"
              - generic [ref=e472]: "Retry-After:"
              - generic [ref=e473]: "schema:"
              - generic [ref=e474]: "type: integer"
              - generic [ref=e475]: "description: The number of seconds to wait before making the next request"
              - generic [ref=e476]: "\"400\":"
              - generic [ref=e477]: "description: Bad Request"
              - generic [ref=e478]: "content:"
              - generic [ref=e479]: "application/json:"
              - generic [ref=e480]: "schema:"
              - generic [ref=e481]: "$ref: \"#/components/schemas/BadRequest\""
              - generic [ref=e482]: "/orders:"
              - generic [ref=e483]: "post:"
              - generic [ref=e484]: "description: Create a new order"
              - generic [ref=e485]: "operationId: createOrder"
              - generic [ref=e486]: "tags:"
              - generic [ref=e487]: "- Order"
              - generic [ref=e488]: "requestBody:"
              - generic [ref=e489]: "content:"
              - generic [ref=e490]: "application/json:"
              - generic [ref=e491]: "schema:"
              - generic [ref=e492]: "$ref: \"#/components/schemas/OrderBase\""
              - generic [ref=e493]: "responses:"
              - generic [ref=e494]: "\"201\":"
              - generic [ref=e495]: "description: Order created"
              - generic [ref=e496]: "content:"
              - generic [ref=e497]: "application/json:"
              - generic [ref=e498]: "schema:"
              - generic [ref=e499]: "$ref: \"#/components/schemas/Id\""
              - generic [ref=e500]: "\"202\":"
              - generic [ref=e501]: "description: Order accepted"
              - generic [ref=e502]: "headers:"
              - generic [ref=e503]: "Link:"
              - generic [ref=e504]: "schema:"
              - generic [ref=e505]: "$ref: \"#/components/schemas/MonitorLink\""
              - generic [ref=e506]: "\"400\":"
              - generic [ref=e507]: "description: Bad Request"
              - generic [ref=e508]: "content:"
              - generic [ref=e509]: "application/json:"
              - generic [ref=e510]: "schema:"
              - generic [ref=e511]: "$ref: \"#/components/schemas/BadRequest\""
              - generic [ref=e512]: "/monitor/{id}:"
              - generic [ref=e513]: "get:"
              - generic [ref=e514]: "description: Retrieves a Monitor by ID"
              - generic [ref=e515]: "operationId: retrieveMonitor"
              - generic [ref=e516]: "tags:"
              - generic [ref=e517]: "- Monitor"
              - generic [ref=e518]: "parameters:"
              - generic [ref=e519]: "- name: id"
              - generic [ref=e520]: "in: path"
              - generic [ref=e521]: "required: true"
              - generic [ref=e522]: "schema:"
              - generic [ref=e523]: "type: integer"
              - generic [ref=e524]: "responses:"
              - generic [ref=e525]: "\"200\":"
              - generic [ref=e526]: "description: Monitor status"
              - generic [ref=e527]: "content:"
              - generic [ref=e528]: "application/json:"
              - generic [ref=e529]: "schema:"
              - generic [ref=e530]: "$ref: \"#/components/schemas/MonitorResponse\""
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - generic [ref=e532]:
    - button "×" [ref=e533] [cursor=pointer]
    - paragraph [ref=e534]: ✓Backward Compatibility Check Complete
    - generic [ref=e535]: 49 passed of 49 scenarios
  - contentinfo
```

# Test source

```ts
  1  | import { test, expect } from "../../../utils/eyesFixture";
  2  | import {
  3  |   PRODUCT_SEARCH_BFF_SPEC_FIX_TYPO,
  4  |   ORDER_BFF_SERVICE_URL,
  5  | } from "../../specNames";
  6  | import { ServiceSpecConfigPage } from "../../../page-objects/service-spec-config-page";
  7  | import { ApiContractPage } from "../../../page-objects/api-contract-page";
  8  | import { validateSummaryAndTableCounts } from "../helpers/execute-contract-tests-helper";
  9  | 
  10 | test.describe("Fix Spec Typo - Conditional Update", () => {
  11 |   test(
  12 |     "Fix /ordres typo to /orders when it exists",
  13 |     { tag: ["@spec", "@fixSpecTypo", "@eyes", "@expected-failure"] },
  14 |     async ({ page, eyes }, testInfo) => {
  15 |       test.fail(true, "Network error exits test execution");
  16 |       const configPage = new ServiceSpecConfigPage(
  17 |         page,
  18 |         testInfo,
  19 |         eyes,
  20 |         PRODUCT_SEARCH_BFF_SPEC_FIX_TYPO,
  21 |       );
  22 | 
  23 |       const contractPage = new ApiContractPage(
  24 |         page,
  25 |         testInfo,
  26 |         eyes,
  27 |         PRODUCT_SEARCH_BFF_SPEC_FIX_TYPO,
  28 |       );
  29 | 
  30 |       await configPage.navigateToSpec(PRODUCT_SEARCH_BFF_SPEC_FIX_TYPO);
  31 | 
  32 |       await test.step("Typo detected: Fixing /ordres to /orders", async () => {
  33 |         await configPage.editSpecInEditor("  /ordres:", "  /orders:");
  34 |         await configPage.clickSaveAfterEdit();
  35 |       });
  36 | 
  37 |       //TODO: Add Backward Compatibility
  38 |       await test.step("Check Backward Compataibility", async () => {
  39 |         await configPage.runBackwardCompatibilityTest();
  40 |         const toastText = await configPage.getAlertMessageText();
> 41 |         expect(toastText).toBe("Changes are backward compatible");
     |                           ^ Error: expect(received).toBe(expected) // Object.is equality
  42 |         await configPage.dismissAlert();
  43 |         await expect(page.locator("#alert-container")).toBeEmpty();
  44 |       });
  45 |       //TODO: RUn Contract Test and Assert Count
  46 |       await test.step("Run contract test for spec with fixed typo and assert count", async () => {
  47 |         await configPage.verifyEndpointInContractTable("/orders");
  48 |         await contractPage.enterServiceUrl(ORDER_BFF_SERVICE_URL);
  49 |         await contractPage.clickRunContractTests();
  50 |         await validateSummaryAndTableCounts(contractPage, {
  51 |           success: 12,
  52 |           failed: 21,
  53 |           total: 41,
  54 |           error: 0,
  55 |           notcovered: 8,
  56 |           excluded: 0,
  57 |         });
  58 |       });
  59 |     },
  60 |   );
  61 | });
  62 | 
```