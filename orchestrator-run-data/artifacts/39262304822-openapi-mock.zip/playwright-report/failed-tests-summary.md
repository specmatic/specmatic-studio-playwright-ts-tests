# OpenAPI Mock Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 3 | 2 | 1 | 0 | 0 | 0 |

## Unexpected Failures

- **specs/openapi/run-mock-server/run-mock-server-negative.spec.ts**: specs/openapi/run-mock-server/run-mock-server-negative.spec.ts › Mock Server - Negative Scenarios › Should show error when starting mock on an already used port
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-run-mock-ser-03f69-ock-on-an-already-used-port-chromium/test-failed-1.png`
  - Error Preview:
````
Error: Waiting for visible selector from: .tab-pane[data-type="mock"][data-active="true"] table#mock, [data-type="mock"] table#mock, table#mock, [data-type="mock"] .header ol.counts

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
````

## Expected Failures

_None_
