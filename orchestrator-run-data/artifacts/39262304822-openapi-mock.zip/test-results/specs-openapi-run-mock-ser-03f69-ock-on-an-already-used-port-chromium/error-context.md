# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/run-mock-server/run-mock-server-negative.spec.ts >> Mock Server - Negative Scenarios >> Should show error when starting mock on an already used port
- Location: specs/openapi/run-mock-server/run-mock-server-negative.spec.ts:18:7

# Error details

```
Error: Waiting for visible selector from: .tab-pane[data-type="mock"][data-active="true"] table#mock, [data-type="mock"] table#mock, table#mock, [data-type="mock"] .header ol.counts

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_mock_negative.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_mock_negative.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/mock/product_search_bff_v5_mock_negative.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - table [ref=e43]:
          - rowgroup [ref=e44]:
            - row "S. No Path Method Request Response Examples Action" [ref=e45]:
              - columnheader [ref=e46]:
                - checkbox [ref=e48]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e49]:
            - row "/products POST application/json 201 application/json Generate" [ref=e50]:
              - cell [ref=e51]:
                - checkbox [ref=e52]
              - cell [ref=e53]
              - cell "/products" [ref=e54]
              - cell "POST" [ref=e55]:
                - paragraph [ref=e56]: POST
              - cell "application/json" [ref=e57]:
                - paragraph [ref=e58]: application/json
              - cell "201 application/json" [ref=e59]:
                - paragraph [ref=e60]: "201"
                - generic [ref=e61]: application/json
              - cell "Generate" [ref=e62]:
                - button "Generate" [ref=e64] [cursor=pointer]
              - cell [ref=e65]
            - row "202 Generate" [ref=e66]:
              - cell [ref=e67]:
                - checkbox [ref=e68]
              - cell [ref=e69]
              - cell "202" [ref=e70]:
                - paragraph [ref=e71]: "202"
              - cell "Generate" [ref=e72]:
                - button "Generate" [ref=e74] [cursor=pointer]
              - cell [ref=e75]
            - row "400 application/json Generate" [ref=e76]:
              - cell [ref=e77]:
                - checkbox [ref=e78]
              - cell [ref=e79]
              - cell "400 application/json" [ref=e80]:
                - paragraph [ref=e81]: "400"
                - generic [ref=e82]: application/json
              - cell "Generate" [ref=e83]:
                - button "Generate" [ref=e85] [cursor=pointer]
              - cell [ref=e86]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e87]:
              - cell [ref=e88]:
                - checkbox [ref=e89]
              - cell [ref=e90]
              - cell "/findAvailableProducts" [ref=e91]
              - cell "GET" [ref=e92]:
                - paragraph [ref=e93]: GET
              - cell "NA" [ref=e94]:
                - paragraph [ref=e95]: NA
              - cell "200 application/json" [ref=e96]:
                - paragraph [ref=e97]: "200"
                - generic [ref=e98]: application/json
              - cell "Generate" [ref=e99]:
                - button "Generate" [ref=e101] [cursor=pointer]
              - cell [ref=e102]
            - row "429 Generate" [ref=e103]:
              - cell [ref=e104]:
                - checkbox [ref=e105]
              - cell [ref=e106]
              - cell "429" [ref=e107]:
                - paragraph [ref=e108]: "429"
              - cell "Generate" [ref=e109]:
                - button "Generate" [ref=e111] [cursor=pointer]
              - cell [ref=e112]
            - row "400 application/json Generate" [ref=e113]:
              - cell [ref=e114]:
                - checkbox [ref=e115]
              - cell [ref=e116]
              - cell "400 application/json" [ref=e117]:
                - paragraph [ref=e118]: "400"
                - generic [ref=e119]: application/json
              - cell "Generate" [ref=e120]:
                - button "Generate" [ref=e122] [cursor=pointer]
              - cell [ref=e123]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e124]:
              - cell [ref=e125]:
                - checkbox [ref=e126]
              - cell [ref=e127]
              - cell "/ordres" [ref=e128]
              - cell "POST" [ref=e129]:
                - paragraph [ref=e130]: POST
              - cell "application/json" [ref=e131]:
                - paragraph [ref=e132]: application/json
              - cell "201 application/json" [ref=e133]:
                - paragraph [ref=e134]: "201"
                - generic [ref=e135]: application/json
              - cell "Generate" [ref=e136]:
                - button "Generate" [ref=e138] [cursor=pointer]
              - cell [ref=e139]
            - row "202 Generate" [ref=e140]:
              - cell [ref=e141]:
                - checkbox [ref=e142]
              - cell [ref=e143]
              - cell "202" [ref=e144]:
                - paragraph [ref=e145]: "202"
              - cell "Generate" [ref=e146]:
                - button "Generate" [ref=e148] [cursor=pointer]
              - cell [ref=e149]
            - row "400 application/json Generate" [ref=e150]:
              - cell [ref=e151]:
                - checkbox [ref=e152]
              - cell [ref=e153]
              - cell "400 application/json" [ref=e154]:
                - paragraph [ref=e155]: "400"
                - generic [ref=e156]: application/json
              - cell "Generate" [ref=e157]:
                - button "Generate" [ref=e159] [cursor=pointer]
              - cell [ref=e160]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e161]':
              - cell [ref=e162]:
                - checkbox [ref=e163]
              - cell [ref=e164]
              - 'cell "/monitor/{id}" [ref=e165]'
              - cell "GET" [ref=e166]:
                - paragraph [ref=e167]: GET
              - cell "NA" [ref=e168]:
                - paragraph [ref=e169]: NA
              - cell "200 application/json" [ref=e170]:
                - paragraph [ref=e171]: "200"
                - generic [ref=e172]: application/json
              - cell "Generate" [ref=e173]:
                - button "Generate" [ref=e175] [cursor=pointer]
              - cell [ref=e176]
            - row "400 application/json Generate" [ref=e177]:
              - cell [ref=e178]:
                - checkbox [ref=e179]
              - cell [ref=e180]
              - cell "400 application/json" [ref=e181]:
                - paragraph [ref=e182]: "400"
                - generic [ref=e183]: application/json
              - cell "Generate" [ref=e184]:
                - button "Generate" [ref=e186] [cursor=pointer]
              - cell [ref=e187]
        - generic [ref=e189]:
          - list [ref=e190]:
            - listitem [ref=e191] [cursor=pointer]:
              - img "success" [ref=e192]
              - paragraph [ref=e193]: "Success:"
              - generic [ref=e194]: "0"
            - listitem [ref=e195] [cursor=pointer]:
              - img "failed" [ref=e196]
              - paragraph [ref=e197]: "Failed:"
              - generic [ref=e198]: "0"
            - listitem [ref=e199] [cursor=pointer]:
              - img "skipped" [ref=e200]
              - paragraph [ref=e201]: "Skipped:"
              - generic [ref=e202]: "0"
            - listitem [ref=e203] [cursor=pointer]:
              - img "total-tests" [ref=e204]
              - paragraph [ref=e205]: "Total:"
              - generic [ref=e206]: "0"
          - generic [ref=e207]:
            - textbox "Port" [ref=e209]
            - button "Run" [ref=e210] [cursor=pointer]
        - generic [ref=e214]:
          - text: ⚠
          - list [ref=e215]:
            - listitem [ref=e216] [cursor=pointer]:
              - img "success" [ref=e217]
              - paragraph [ref=e218]: "Success:"
              - generic [ref=e219]: "0"
            - listitem [ref=e220] [cursor=pointer]:
              - img "failed" [ref=e221]
              - paragraph [ref=e222]: "Failed:"
              - generic [ref=e223]: "0"
            - listitem [ref=e224] [cursor=pointer]:
              - img "skipped" [ref=e225]
              - paragraph [ref=e226]: "Skipped:"
              - generic [ref=e227]: "0"
            - listitem [ref=e228] [cursor=pointer]:
              - img "excluded" [ref=e229]
              - paragraph [ref=e230]: "Excluded:"
              - generic [ref=e231]: "0"
            - listitem [ref=e232] [cursor=pointer]:
              - img "total-tests" [ref=e233]
              - paragraph [ref=e234]: "Total:"
              - generic [ref=e235]: "0"
          - generic [ref=e236]:
            - generic [ref=e237]:
              - generic [ref=e238]:
                - checkbox [ref=e239]
                - generic [ref=e240]: Generative
              - textbox "Service URL" [ref=e242]: http://localhost:8080
            - button "Run" [ref=e243] [cursor=pointer]
        - generic [ref=e246]:
          - generic [ref=e248]:
            - generic "Switch between preview and editor" [ref=e249]:
              - generic [ref=e250]: Preview
              - button "Toggle editor view" [ref=e251] [cursor=pointer]
              - generic [ref=e253]: Editor
            - button "Test Backward Compatibility" [ref=e254] [cursor=pointer]
            - button "Generate Dictionary" [ref=e255] [cursor=pointer]
          - generic [ref=e258]:
            - generic:
              - img
            - generic [ref=e259]:
              - generic [ref=e263]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e265]:
                  - text: Order BFF
                  - generic [ref=e266]:
                    - generic [ref=e268]: "5.0"
                    - generic [ref=e270]: OAS 3.0
                - paragraph [ref=e273]: Sample Order BFF
                - link "Contact the developer" [ref=e275] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e278]:
                - heading "WIP API still under development" [level=3] [ref=e281] [cursor=pointer]:
                  - generic [ref=e282]: WIP
                  - paragraph [ref=e285]: API still under development
                  - button "Collapse operation" [expanded] [ref=e286]:
                    - img [ref=e287]
                - generic [ref=e290]:
                  - heading "Product Product Related APIs" [level=3] [ref=e291] [cursor=pointer]:
                    - generic [ref=e292]: Product
                    - paragraph [ref=e295]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e296]:
                      - img [ref=e297]
                  - generic [ref=e300]:
                    - generic [ref=e303] [cursor=pointer]:
                      - button "POST /products" [ref=e304]:
                        - generic [ref=e305]: POST
                        - generic [ref=e308]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e311]:
                        - img [ref=e312]
                    - generic [ref=e316] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e317]:
                        - generic [ref=e318]: GET
                        - generic [ref=e321]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e324]:
                        - img [ref=e325]
                - generic [ref=e328]:
                  - heading "Order Order Related APIs" [level=3] [ref=e329] [cursor=pointer]:
                    - generic [ref=e330]: Order
                    - paragraph [ref=e333]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e334]:
                      - img [ref=e335]
                  - generic [ref=e341] [cursor=pointer]:
                    - button "POST /ordres" [ref=e342]:
                      - generic [ref=e343]: POST
                      - generic [ref=e346]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e349]:
                      - img [ref=e350]
                - generic [ref=e353]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e354] [cursor=pointer]:
                    - generic [ref=e355]: Monitor
                    - paragraph [ref=e358]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e359]:
                      - img [ref=e360]
                  - generic [ref=e366] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e367]':
                      - generic [ref=e368]: GET
                      - generic [ref=e372]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e375]':
                      - img [ref=e376]
              - generic [ref=e380]:
                - heading "Schemas" [level=4] [ref=e381] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e382]:
                    - generic [ref=e383]: Schemas
                    - img [ref=e384]
                - generic [ref=e386]:
                  - button "ProductInventory" [ref=e389] [cursor=pointer]:
                    - generic [ref=e391]: ProductInventory
                  - button "Product Type" [ref=e394] [cursor=pointer]:
                    - generic [ref=e396]: Product Type
                  - button "MonitorLink" [ref=e399] [cursor=pointer]:
                    - generic [ref=e401]: MonitorLink
                  - button "Id" [ref=e404] [cursor=pointer]:
                    - generic [ref=e406]: Id
                  - button "Product Details" [ref=e409] [cursor=pointer]:
                    - generic [ref=e411]: Product Details
                  - button "Product" [ref=e414] [cursor=pointer]:
                    - generic [ref=e416]: Product
                  - button "CreatedOn" [ref=e419] [cursor=pointer]:
                    - generic [ref=e421]: CreatedOn
                  - button "Order Details" [ref=e424] [cursor=pointer]:
                    - generic [ref=e426]: Order Details
                  - button "Order" [ref=e429] [cursor=pointer]:
                    - generic [ref=e431]: Order
                  - button "MonitorResponse" [ref=e434] [cursor=pointer]:
                    - generic [ref=e436]: MonitorResponse
                  - button "Request" [ref=e439] [cursor=pointer]:
                    - generic [ref=e441]: Request
                  - button "Response" [ref=e444] [cursor=pointer]:
                    - generic [ref=e446]: Response
                  - button "HeaderItem" [ref=e449] [cursor=pointer]:
                    - generic [ref=e451]: HeaderItem
                  - button "Bad Request" [ref=e454] [cursor=pointer]:
                    - generic [ref=e456]: Bad Request
    - text: Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  97  | 
  98  |       // Determine if this is a tab by checking attributes
  99  |       const [role, dataType, dataActive] = await Promise.all([
  100 |         tabLocator.getAttribute("role"),
  101 |         tabLocator.getAttribute("data-type"),
  102 |         tabLocator.getAttribute("data-active"),
  103 |       ]);
  104 |       const isTab =
  105 |         role === "tab" ||
  106 |         dataType === "spec" ||
  107 |         dataType === "example-generation" ||
  108 |         dataType === "example";
  109 | 
  110 |       if (isTab) {
  111 |         if (dataActive !== "true") {
  112 |           await tabLocator.click({ force: true });
  113 |         }
  114 |       } else {
  115 |         await tabLocator.click({ force: true });
  116 |       }
  117 | 
  118 |       await this.waitForTabContentReady(dataType);
  119 |       await takeAndAttachScreenshot(this.page, screenshotName);
  120 |       return tabLocator;
  121 |     });
  122 |   }
  123 | 
  124 |   private async waitForTabContentReady(dataType: string | null): Promise<void> {
  125 |     const timeout = 15000;
  126 | 
  127 |     if (dataType === "test") {
  128 |       await this.waitForAnyVisible(
  129 |         [
  130 |           '.tab-pane[data-type="test"][data-active="true"] table#test',
  131 |           '[data-type="test"] table#test',
  132 |           "table#test",
  133 |           '[data-type="test"] .header ol.counts',
  134 |         ],
  135 |         timeout,
  136 |       );
  137 |       await this.waitForTableStructure("table#test");
  138 |       return;
  139 |     }
  140 | 
  141 |     if (dataType === "mock") {
  142 |       await this.waitForAnyVisible(
  143 |         [
  144 |           '.tab-pane[data-type="mock"][data-active="true"] table#mock',
  145 |           '[data-type="mock"] table#mock',
  146 |           "table#mock",
  147 |           '[data-type="mock"] .header ol.counts',
  148 |         ],
  149 |         timeout,
  150 |       );
  151 |       await this.waitForTableStructure("table#mock");
  152 |       return;
  153 |     }
  154 | 
  155 |     if (dataType === "example") {
  156 |       await this.waitForAnyVisible(
  157 |         [
  158 |           '.screen[data-active] .example[data-protocol="openapi"] table.examples-protocol-table',
  159 |           '.screen[data-active] .example[data-protocol="openapi"] .examples-empty',
  160 |           '.screen[data-active] .example[data-protocol="openapi"] #examples',
  161 |           ".screen[data-active] table.examples-protocol-table",
  162 |           ".screen[data-active] #valid-examples-table",
  163 |           ".screen[data-active] #invalid-examples-table",
  164 |           ".screen[data-active] table",
  165 |         ],
  166 |         timeout,
  167 |       );
  168 |       return;
  169 |     }
  170 | 
  171 |     if (dataType === "spec") {
  172 |       await this.waitForAnyVisible(
  173 |         [
  174 |           ".cm-content",
  175 |           ".cm-editor",
  176 |           ".CodeMirror",
  177 |           "textarea",
  178 |           "#editor-view-toggle-btn",
  179 |           ".editor-view-toggle",
  180 |           ".swagger-ui",
  181 |           ".swagger-container",
  182 |         ],
  183 |         timeout,
  184 |       );
  185 |       return;
  186 |     }
  187 | 
  188 |     await this.page
  189 |       .waitForLoadState("networkidle", { timeout: 3000 })
  190 |       .catch(() => {});
  191 |   }
  192 | 
  193 |   private async waitForAnyVisible(
  194 |     selectors: string[],
  195 |     timeout: number,
  196 |   ): Promise<void> {
> 197 |     await expect
      |     ^ Error: Waiting for visible selector from: .tab-pane[data-type="mock"][data-active="true"] table#mock, [data-type="mock"] table#mock, table#mock, [data-type="mock"] .header ol.counts
  198 |       .poll(
  199 |         async () => {
  200 |           for (const selector of selectors) {
  201 |             const locator = this.page.locator(selector);
  202 |             const count = await locator.count();
  203 |             for (let i = 0; i < count; i++) {
  204 |               if (
  205 |                 await locator
  206 |                   .nth(i)
  207 |                   .isVisible()
  208 |                   .catch(() => false)
  209 |               ) {
  210 |                 return true;
  211 |               }
  212 |             }
  213 |           }
  214 |           return false;
  215 |         },
  216 |         {
  217 |           timeout,
  218 |           intervals: [200, 400, 800],
  219 |           message: `Waiting for visible selector from: ${selectors.join(", ")}`,
  220 |         },
  221 |       )
  222 |       .toBeTruthy();
  223 |   }
  224 | 
  225 |   private async waitForTableStructure(tableSelector: string): Promise<void> {
  226 |     const table = this.page.locator(tableSelector).first();
  227 |     await table.waitFor({ state: "visible", timeout: 15000 });
  228 | 
  229 |     await expect
  230 |       .poll(
  231 |         async () => {
  232 |           const [tbodyCount, rowCount, cellCount, generated] =
  233 |             await Promise.all([
  234 |               table.locator("tbody").count(),
  235 |               table.locator("tbody tr").count(),
  236 |               table.locator("tbody td").count(),
  237 |               table.getAttribute("data-generated"),
  238 |             ]);
  239 | 
  240 |           return (
  241 |             tbodyCount > 0 ||
  242 |             rowCount > 0 ||
  243 |             cellCount > 0 ||
  244 |             generated !== null
  245 |           );
  246 |         },
  247 |         {
  248 |           timeout: 5000,
  249 |           intervals: [150, 300, 600],
  250 |           message: `Waiting for table structure to load: ${tableSelector}`,
  251 |         },
  252 |       )
  253 |       .toBeTruthy();
  254 |   }
  255 | }
  256 | 
```