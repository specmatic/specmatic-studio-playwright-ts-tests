# AsyncAPI Examples Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 8 | 4 | 1 | 0 | 0 | 3 |

## Unexpected Failures

- **specs/async/examples/inline-examples-readonly-v2.spec.ts**: specs/async/examples/inline-examples-readonly-v2.spec.ts › AsyncAPI 2.x inline examples › lists all inline examples in the examples table
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-async-examples-inlin-2fa90-mples-in-the-examples-table-chromium/test-failed-1.png`
  - Error Preview:
````
Error: expect(locator).toBeVisible() failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-async/inline-examples-readonly-v2.yaml")') }).first().locator('div.example[data-protocol="async"]').locator('td.examples-name-cell').filter({ hasText: /(^|\s)NewOrder(?=\s|$)/ }).filter({ hasText: /(^|\s)Inline(\s|$)/ }).locator('..').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
````

## Expected Failures

_None_
