# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/async/examples/inline-examples-readonly-v2.spec.ts >> AsyncAPI 2.x inline examples >> lists all inline examples in the examples table
- Location: specs/async/examples/inline-examples-readonly-v2.spec.ts:12:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-async/inline-examples-readonly-v2.yaml")') }).first().locator('div.example[data-protocol="async"]').locator('td.examples-name-cell').filter({ hasText: /(^|\s)NewOrder(?=\s|$)/ }).filter({ hasText: /(^|\s)Inline(\s|$)/ }).locator('..').first()
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-async/inline-examples-readonly-v2.yaml")') }).first().locator('div.example[data-protocol="async"]').locator('td.examples-name-cell').filter({ hasText: /(^|\s)NewOrder(?=\s|$)/ }).filter({ hasText: /(^|\s)Inline(\s|$)/ }).locator('..').first()

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run ⚠ Run Run Suite Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - text: inline-examples-readonly-v2.yaml
                - generic [ref=e31]:
                  - text: Filename
                  - textbox [disabled]
                  - text: inline-examples-readonly-v2
              - button "Rename inline-examples-readonly-v2.yaml"
          - text: "File path: ./test-async/inline-examples-readonly-v2.yaml"
        - list [ref=e33]:
          - listitem [ref=e34] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Async examples
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run async mock
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Run async tests
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e38]:
        - generic [ref=e39]:
          - text: Run Run Run Run Run Run Run
          - generic [ref=e41]:
            - generic [ref=e42]:
              - button "← Go Back" [ref=e43] [cursor=pointer]
              - list
            - list
        - generic [ref=e45]:
          - list [ref=e46]:
            - listitem [ref=e47] [cursor=pointer]:
              - img "success" [ref=e48]
              - paragraph [ref=e49]: "Success:"
              - generic [ref=e50]: "0"
            - listitem [ref=e51] [cursor=pointer]:
              - img "failed" [ref=e52]
              - paragraph [ref=e53]: "Failed:"
              - generic [ref=e54]: "0"
            - listitem [ref=e55] [cursor=pointer]:
              - img "skipped" [ref=e56]
              - paragraph [ref=e57]: "Skipped:"
              - generic [ref=e58]: "0"
            - listitem [ref=e59] [cursor=pointer]:
              - img "total-tests" [ref=e60]
              - paragraph [ref=e61]: "Total:"
              - generic [ref=e62]: "0"
          - generic [ref=e63]:
            - generic [ref=e64]:
              - checkbox "Enable In-Memory Broker" [checked] [ref=e65]
              - generic [ref=e66]: Enable In-Memory Broker
            - combobox [ref=e68]:
              - option "Kafka" [selected]
              - option "JMS"
            - textbox "Port" [ref=e70]
            - button "AsyncAPI servers info" [ref=e71] [cursor=pointer]: i
            - button "Run" [ref=e72] [cursor=pointer]
        - generic [ref=e76]:
          - list [ref=e77]:
            - listitem [ref=e78] [cursor=pointer]:
              - img "success" [ref=e79]
              - paragraph [ref=e80]: "Success:"
              - generic [ref=e81]: "0"
            - listitem [ref=e82] [cursor=pointer]:
              - img "failed" [ref=e83]
              - paragraph [ref=e84]: "Failed:"
              - generic [ref=e85]: "0"
            - listitem [ref=e86] [cursor=pointer]:
              - img "skipped" [ref=e87]
              - paragraph [ref=e88]: "Skipped:"
              - generic [ref=e89]: "0"
            - listitem [ref=e90] [cursor=pointer]:
              - img "total-tests" [ref=e91]
              - paragraph [ref=e92]: "Total:"
              - generic [ref=e93]: "0"
          - generic [ref=e94]:
            - button "AsyncAPI servers info" [ref=e95] [cursor=pointer]: i
            - button "Run" [ref=e96] [cursor=pointer]
    - text: Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run
  - contentinfo
```

# Test source

```ts
  390 |     const escapedName = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  391 |     let nameCell = this.examplesRoot
  392 |       .locator("td.examples-name-cell")
  393 |       .filter({ hasText: new RegExp(`(^|\\s)${escapedName}(?=\\s|$)`) });
  394 | 
  395 |     if (origin) {
  396 |       nameCell = nameCell.filter({ hasText: new RegExp(`(^|\\s)${origin}(\\s|$)`) });
  397 |     }
  398 | 
  399 |     return nameCell.locator("xpath=..");
  400 |   }
  401 | 
  402 |   private conversionDialog(): Locator {
  403 |     return this.page.locator(".example-conversion-overlay").first();
  404 |   }
  405 | 
  406 |   private conversionRow(name: string): Locator {
  407 |     const displayName = name.replace(/\.json$/, "");
  408 |     const escapedName = displayName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  409 |     const asyncDisplayName = displayName.replace(/(^|-)([a-z])/g, (_, __, letter) => letter.toUpperCase());
  410 |     const escapedAsyncDisplayName = asyncDisplayName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  411 |     return this.conversionDialog()
  412 |       .locator("[data-example-row]")
  413 |       .filter({
  414 |         has: this.page
  415 |           .locator("[data-example-name]")
  416 |           .filter({ hasText: new RegExp(`^(?:${escapedName}|${escapedAsyncDisplayName})$`) }),
  417 |       })
  418 |       .first();
  419 |   }
  420 | 
  421 |   async assertExternalExampleCount(name: string, expectedCount: number): Promise<void> {
  422 |     await test.step(`Verify ${expectedCount} external rows for '${name}'`, async () => {
  423 |       await this.waitForExamplesIFrame();
  424 |       await expect(this.getExampleRows(name, "External")).toHaveCount(expectedCount, { timeout: 10000 });
  425 |     });
  426 |   }
  427 | 
  428 |   async selectExampleForConversion(name: string, origin: "Inline" | "External"): Promise<void> {
  429 |     await test.step(`Select ${origin.toLowerCase()} example '${name}' for conversion`, async () => {
  430 |       await this.waitForExamplesIFrame();
  431 |       const row = this.getExampleRows(name, origin).first();
  432 |       await expect(row).toBeVisible({ timeout: 10000 });
  433 |       await this.setCheckboxChecked(row.locator('input[type="checkbox"]').first(), true, `${origin} example '${name}' checkbox`);
  434 |     });
  435 |   }
  436 | 
  437 |   async openExampleConversionDialog(action: "import" | "export"): Promise<void> {
  438 |     await test.step(`Open example ${action} confirmation dialog`, async () => {
  439 |       const root = await this.waitForExamplesIFrame();
  440 |       const button = root.locator(`button[data-action="${action}"]`).first();
  441 |       await expect(button).toBeVisible({ timeout: 5000 });
  442 |       await expect(button).toBeEnabled({ timeout: 5000 });
  443 |       await button.click();
  444 |       await expect(this.conversionDialog()).toBeVisible({ timeout: 5000 });
  445 |       await expect(this.conversionDialog().locator("[data-example-row]").first()).toBeVisible({ timeout: 5000 });
  446 |     });
  447 |   }
  448 | 
  449 |   async assertExampleConversionRow(name: string, severity: "error" | "warning" | "success", reason: string | RegExp): Promise<void> {
  450 |     await test.step(`Verify ${severity} conversion state for '${name}'`, async () => {
  451 |       const row = this.conversionRow(name);
  452 |       await expect(row).toBeVisible({ timeout: 5000 });
  453 |       await expect(row).toHaveClass(new RegExp(`example-conversion-dialog__row--${severity}`));
  454 |       await expect(row.locator("[data-example-issues]")).toContainText(reason);
  455 |     });
  456 |   }
  457 | 
  458 |   async assertExampleConversionModes(name: string, modes: ExampleConversionMode[]): Promise<void> {
  459 |     await test.step(`Verify conversion modes for '${name}'`, async () => {
  460 |       const select = this.conversionRow(name).locator("select[data-example-mode]");
  461 |       await expect(select).toBeVisible({ timeout: 5000 });
  462 |       await expect(select.locator("option")).toHaveCount(modes.length);
  463 |       expect(await select.locator("option").evaluateAll((options) => options.map((option) => (option as HTMLOptionElement).value))).toEqual(modes);
  464 |     });
  465 |   }
  466 | 
  467 |   async chooseExampleConversionMode(name: string, mode: ExampleConversionMode): Promise<void> {
  468 |     await test.step(`Choose ${mode} for converted example '${name}'`, async () => {
  469 |       await this.conversionRow(name).locator("select[data-example-mode]").selectOption(mode);
  470 |     });
  471 |   }
  472 | 
  473 |   async confirmExampleConversion(): Promise<void> {
  474 |     await test.step("Confirm example conversion", async () => {
  475 |       const dialog = this.conversionDialog();
  476 |       await dialog.locator('[data-dialog-action="continue"]').click();
  477 |       await expect(dialog).toBeHidden({ timeout: 15000 });
  478 |       const { alert } = await this.getAlertContainerFrameAndLocator();
  479 |       await expect(alert).toBeVisible({ timeout: 15000 });
  480 |       await alert.locator(".examples-alert-close").click();
  481 |       await expect(alert).toBeHidden({ timeout: 5000 });
  482 |       await this.waitForExamplesIFrame();
  483 |     });
  484 |   }
  485 | 
  486 |   async assertInlineExamplesListed(names: string[]): Promise<void> {
  487 |     await test.step(`Verify inline examples are listed: ${names.join(", ")}`, async () => {
  488 |       await this.waitForExamplesIFrame();
  489 |       for (const name of names) {
> 490 |         await expect(this.getInlineRows(name).first()).toBeVisible({ timeout: 10000 });
      |                                                        ^ Error: expect(locator).toBeVisible() failed
  491 |       }
  492 |     });
  493 |   }
  494 | 
  495 |   async assertInlineExampleCount(name: string, expectedCount: number): Promise<void> {
  496 |     await test.step(`Verify ${expectedCount} inline rows for '${name}'`, async () => {
  497 |       await this.waitForExamplesIFrame();
  498 |       await expect(this.getInlineRows(name)).toHaveCount(expectedCount, {
  499 |         timeout: 10000,
  500 |       });
  501 |     });
  502 |   }
  503 | 
  504 |   async openInlineExample(name: string, context?: string): Promise<void> {
  505 |     await test.step(`Open inline example '${name}'`, async () => {
  506 |       await this.waitForExamplesIFrame();
  507 |       const rows = this.getInlineRows(name, context);
  508 |       await expect(rows).toHaveCount(1, { timeout: 10000 });
  509 | 
  510 |       const row = rows.first();
  511 |       const detailsButton = row.locator('button[data-row-action="details"]');
  512 |       await expect(detailsButton).toBeVisible({ timeout: 5000 });
  513 | 
  514 |       await detailsButton.click();
  515 |       await this.waitForDetailsViewToLoad();
  516 |     });
  517 |   }
  518 | 
  519 |   async assertInlineDetailsEditable(expectedContent: string[], expectedLocation: string): Promise<void> {
  520 |     await test.step("Verify inline example details are editable", async () => {
  521 |       const root = await this.waitForExamplesIFrame();
  522 |       const editor = root.locator("code-editor");
  523 | 
  524 |       await expect(editor).toBeVisible({ timeout: 8000 });
  525 |       await expect
  526 |         .poll(() => editor.evaluate((element) => (element as any).readOnly))
  527 |         .toBe(false);
  528 | 
  529 |       await expect(editor.locator(".cm-content")).toHaveAttribute("contenteditable", "true");
  530 |       const content = await this.getEditorContent();
  531 | 
  532 |       for (const fragment of expectedContent) expect(content).toContain(fragment);
  533 |       await expect(root.locator(".examples-detail-file-path")).toContainText(expectedLocation);
  534 | 
  535 |       await expect(
  536 |         root.locator("inline-filename-rename.examples-details__filename-rename"),
  537 |       ).toBeVisible();
  538 | 
  539 |       await expect(
  540 |         root.locator('button[data-details-action="validate"]'),
  541 |       ).toBeVisible();
  542 |     });
  543 |   }
  544 | 
  545 |   async assertInlineFixActionVisible(): Promise<void> {
  546 |     await test.step("Verify inline example auto-fix action is available", async () => {
  547 |       const root = await this.waitForExamplesIFrame();
  548 |       const fixButton = root.locator('button[data-details-action="fix"]');
  549 |       await expect(fixButton).toBeVisible();
  550 |       await expect(fixButton).toBeEnabled();
  551 |     });
  552 |   }
  553 | 
  554 |   async assertInlineFixActionHidden(): Promise<void> {
  555 |     await test.step("Verify inline example auto-fix action is hidden", async () => {
  556 |       const root = await this.waitForExamplesIFrame();
  557 |       await expect(root.locator('button[data-details-action="fix"]')).toHaveCount(0);
  558 |     });
  559 |   }
  560 | 
  561 |   async assertInlineValidationDetails(
  562 |     expectedStatus: "Valid Example" | "Invalid Example",
  563 |     expectErrorHighlight = false,
  564 |   ): Promise<void> {
  565 |     await test.step(`Verify inline validation details show '${expectedStatus}'`, async () => {
  566 |       const root = await this.waitForExamplesIFrame();
  567 |       await expect(root.locator(".examples-detail-summary .expand-info > .pill")).toHaveText(expectedStatus);
  568 | 
  569 |       if (expectedStatus === "Invalid Example") {
  570 |         await expect(root.locator(".examples-detail-issues.error")).toBeVisible();
  571 |       }
  572 | 
  573 |       if (expectErrorHighlight) {
  574 |         await expect(root.locator(".specmatic-lintRange--error")).not.toHaveCount(0);
  575 |       }
  576 |     });
  577 |   }
  578 | 
  579 |   async validateInlineExample(
  580 |     name: string,
  581 |     context?: string,
  582 |     expectedValidationClass = "green",
  583 |   ): Promise<void> {
  584 |     await test.step(`Validate inline example '${name}'`, async () => {
  585 |       const root = await this.waitForExamplesIFrame();
  586 |       const goBackButton = root.locator("#back");
  587 |       if (await goBackButton.isVisible().catch(() => false)) {
  588 |         await this.goBackFromExample();
  589 |       }
  590 | 
```