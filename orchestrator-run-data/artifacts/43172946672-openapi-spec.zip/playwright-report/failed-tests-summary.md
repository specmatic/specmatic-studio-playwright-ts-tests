# OpenAPI Spec Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 9 | 7 | 1 | 0 | 1 | 0 |

## Unexpected Failures

- **specs/openapi/update-service-spec/invalid-spec-save.spec.ts**: specs/openapi/update-service-spec/invalid-spec-save.spec.ts › InValid Spec save and Error Dialog Display › Save Invalid Spec and Assert Error
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-update-servi-38f07-valid-Spec-and-Assert-Error-chromium/test-failed-1.png`
  - Error Preview:
````
Error: expect(received).toMatch(expected)

Expected pattern: /could not parse contract|implicit keys need to be on a single line/i
Received string:  ""
````

## Expected Failures

- **specs/openapi/update-service-spec/fix-spec-typo.spec.ts**: specs/openapi/update-service-spec/fix-spec-typo.spec.ts › Fix Spec Typo - Conditional Update › Fix /ordres typo to /orders when it exists
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-update-servi-97a1f-po-to-orders-when-it-exists-chromium/test-finished-1.png`
  - Error Preview:
````
Error: expect(received).toBe(expected) // Object.is equality

Expected: "Changes are backward compatible"
Received: "49 passed of 49 scenarios"
````
