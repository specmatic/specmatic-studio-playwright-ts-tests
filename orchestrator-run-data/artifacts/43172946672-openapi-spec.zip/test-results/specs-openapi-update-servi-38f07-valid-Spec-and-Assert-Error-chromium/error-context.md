# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/update-service-spec/invalid-spec-save.spec.ts >> InValid Spec save and Error Dialog Display >> Save Invalid Spec and Assert Error
- Location: specs/openapi/update-service-spec/invalid-spec-save.spec.ts:9:7

# Error details

```
Error: expect(received).toMatch(expected)

Expected pattern: /could not parse contract|implicit keys need to be on a single line/i
Received string:  ""
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_save_invalid_spec.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_save_invalid_spec.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/spec-editing/product_search_bff_v5_save_invalid_spec.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - table [ref=e43]:
          - rowgroup [ref=e44]:
            - row "S. No Path Method Request Response Examples Action" [ref=e45]:
              - columnheader [ref=e46]:
                - checkbox [ref=e48]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e49]:
            - row "/products POST application/json 201 application/json Generate" [ref=e50]:
              - cell [ref=e51]:
                - checkbox [ref=e52]
              - cell [ref=e53]
              - cell "/products" [ref=e54]
              - cell "POST" [ref=e55]:
                - paragraph [ref=e56]: POST
              - cell "application/json" [ref=e57]:
                - paragraph [ref=e58]: application/json
              - cell "201 application/json" [ref=e59]:
                - paragraph [ref=e60]: "201"
                - generic [ref=e61]: application/json
              - cell "Generate" [ref=e62]:
                - button "Generate" [ref=e64] [cursor=pointer]
              - cell [ref=e65]
            - row "202 Generate" [ref=e66]:
              - cell [ref=e67]:
                - checkbox [ref=e68]
              - cell [ref=e69]
              - cell "202" [ref=e70]:
                - paragraph [ref=e71]: "202"
              - cell "Generate" [ref=e72]:
                - button "Generate" [ref=e74] [cursor=pointer]
              - cell [ref=e75]
            - row "400 application/json Generate" [ref=e76]:
              - cell [ref=e77]:
                - checkbox [ref=e78]
              - cell [ref=e79]
              - cell "400 application/json" [ref=e80]:
                - paragraph [ref=e81]: "400"
                - generic [ref=e82]: application/json
              - cell "Generate" [ref=e83]:
                - button "Generate" [ref=e85] [cursor=pointer]
              - cell [ref=e86]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e87]:
              - cell [ref=e88]:
                - checkbox [ref=e89]
              - cell [ref=e90]
              - cell "/findAvailableProducts" [ref=e91]
              - cell "GET" [ref=e92]:
                - paragraph [ref=e93]: GET
              - cell "NA" [ref=e94]:
                - paragraph [ref=e95]: NA
              - cell "200 application/json" [ref=e96]:
                - paragraph [ref=e97]: "200"
                - generic [ref=e98]: application/json
              - cell "Generate" [ref=e99]:
                - button "Generate" [ref=e101] [cursor=pointer]
              - cell [ref=e102]
            - row "429 Generate" [ref=e103]:
              - cell [ref=e104]:
                - checkbox [ref=e105]
              - cell [ref=e106]
              - cell "429" [ref=e107]:
                - paragraph [ref=e108]: "429"
              - cell "Generate" [ref=e109]:
                - button "Generate" [ref=e111] [cursor=pointer]
              - cell [ref=e112]
            - row "400 application/json Generate" [ref=e113]:
              - cell [ref=e114]:
                - checkbox [ref=e115]
              - cell [ref=e116]
              - cell "400 application/json" [ref=e117]:
                - paragraph [ref=e118]: "400"
                - generic [ref=e119]: application/json
              - cell "Generate" [ref=e120]:
                - button "Generate" [ref=e122] [cursor=pointer]
              - cell [ref=e123]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e124]:
              - cell [ref=e125]:
                - checkbox [ref=e126]
              - cell [ref=e127]
              - cell "/ordres" [ref=e128]
              - cell "POST" [ref=e129]:
                - paragraph [ref=e130]: POST
              - cell "application/json" [ref=e131]:
                - paragraph [ref=e132]: application/json
              - cell "201 application/json" [ref=e133]:
                - paragraph [ref=e134]: "201"
                - generic [ref=e135]: application/json
              - cell "Generate" [ref=e136]:
                - button "Generate" [ref=e138] [cursor=pointer]
              - cell [ref=e139]
            - row "202 Generate" [ref=e140]:
              - cell [ref=e141]:
                - checkbox [ref=e142]
              - cell [ref=e143]
              - cell "202" [ref=e144]:
                - paragraph [ref=e145]: "202"
              - cell "Generate" [ref=e146]:
                - button "Generate" [ref=e148] [cursor=pointer]
              - cell [ref=e149]
            - row "400 application/json Generate" [ref=e150]:
              - cell [ref=e151]:
                - checkbox [ref=e152]
              - cell [ref=e153]
              - cell "400 application/json" [ref=e154]:
                - paragraph [ref=e155]: "400"
                - generic [ref=e156]: application/json
              - cell "Generate" [ref=e157]:
                - button "Generate" [ref=e159] [cursor=pointer]
              - cell [ref=e160]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e161]':
              - cell [ref=e162]:
                - checkbox [ref=e163]
              - cell [ref=e164]
              - 'cell "/monitor/{id}" [ref=e165]'
              - cell "GET" [ref=e166]:
                - paragraph [ref=e167]: GET
              - cell "NA" [ref=e168]:
                - paragraph [ref=e169]: NA
              - cell "200 application/json" [ref=e170]:
                - paragraph [ref=e171]: "200"
                - generic [ref=e172]: application/json
              - cell "Generate" [ref=e173]:
                - button "Generate" [ref=e175] [cursor=pointer]
              - cell [ref=e176]
            - row "400 application/json Generate" [ref=e177]:
              - cell [ref=e178]:
                - checkbox [ref=e179]
              - cell [ref=e180]
              - cell "400 application/json" [ref=e181]:
                - paragraph [ref=e182]: "400"
                - generic [ref=e183]: application/json
              - cell "Generate" [ref=e184]:
                - button "Generate" [ref=e186] [cursor=pointer]
              - cell [ref=e187]
        - generic [ref=e189]:
          - list [ref=e190]:
            - listitem [ref=e191] [cursor=pointer]:
              - img "success" [ref=e192]
              - paragraph [ref=e193]: "Success:"
              - generic [ref=e194]: "0"
            - listitem [ref=e195] [cursor=pointer]:
              - img "failed" [ref=e196]
              - paragraph [ref=e197]: "Failed:"
              - generic [ref=e198]: "0"
            - listitem [ref=e199] [cursor=pointer]:
              - img "skipped" [ref=e200]
              - paragraph [ref=e201]: "Skipped:"
              - generic [ref=e202]: "0"
            - listitem [ref=e203] [cursor=pointer]:
              - img "total-tests" [ref=e204]
              - paragraph [ref=e205]: "Total:"
              - generic [ref=e206]: "0"
          - generic [ref=e207]:
            - textbox "Port" [ref=e209]
            - button "Run" [ref=e210] [cursor=pointer]
        - generic [ref=e214]:
          - text: ⚠
          - list [ref=e215]:
            - listitem [ref=e216] [cursor=pointer]:
              - img "success" [ref=e217]
              - paragraph [ref=e218]: "Success:"
              - generic [ref=e219]: "0"
            - listitem [ref=e220] [cursor=pointer]:
              - img "failed" [ref=e221]
              - paragraph [ref=e222]: "Failed:"
              - generic [ref=e223]: "0"
            - listitem [ref=e224] [cursor=pointer]:
              - img "skipped" [ref=e225]
              - paragraph [ref=e226]: "Skipped:"
              - generic [ref=e227]: "0"
            - listitem [ref=e228] [cursor=pointer]:
              - img "wip" [ref=e229]
              - paragraph [ref=e230]: "Wip:"
              - generic [ref=e231]: "0"
            - listitem [ref=e232] [cursor=pointer]:
              - img "excluded" [ref=e233]
              - paragraph [ref=e234]: "Excluded:"
              - generic [ref=e235]: "0"
            - listitem [ref=e236] [cursor=pointer]:
              - img "total-tests" [ref=e237]
              - paragraph [ref=e238]: "Total:"
              - generic [ref=e239]: "0"
          - generic [ref=e240]:
            - generic [ref=e241]:
              - generic [ref=e242]:
                - checkbox [ref=e243]
                - generic [ref=e244]: Generative
              - textbox "Service URL" [ref=e246]: http://localhost:8080
            - button "Run" [ref=e247] [cursor=pointer]
        - generic [ref=e250]:
          - generic [ref=e252]:
            - generic "Switch between preview and editor" [ref=e253]:
              - generic [ref=e254]: Preview
              - button "Toggle editor view" [pressed] [ref=e255] [cursor=pointer]
              - generic [ref=e257]: Editor
            - button "Test Backward Compatibility" [ref=e258] [cursor=pointer]
            - button "Save" [ref=e259] [cursor=pointer]
          - button "Expand Validation found 1 error" [expanded] [active] [ref=e262] [cursor=pointer]:
            - img "Expand" [ref=e263]
            - generic [ref=e264]: Validation found 1 error
          - generic [ref=e270]:
            - generic [ref=e271]:
              - generic [ref=e272]:
                - generic [ref=e273]: "1"
                - generic [ref=e274]: "2"
                - generic [ref=e275]: "3"
                - generic [ref=e276]: "4"
                - generic [ref=e277]: "5"
                - generic [ref=e278]: "6"
                - generic [ref=e279]: "7"
                - generic [ref=e280]: "8"
                - generic [ref=e281]: "9"
                - generic [ref=e282]: "10"
                - generic [ref=e283]: "11"
                - generic [ref=e284]: "12"
                - generic [ref=e285]: "13"
                - generic [ref=e286]: "14"
                - generic [ref=e287]: "15"
                - generic [ref=e288]: "16"
                - generic [ref=e289]: "17"
                - generic [ref=e290]: "18"
                - generic [ref=e291]: "19"
                - generic [ref=e292]: "20"
                - generic [ref=e293]: "21"
                - generic [ref=e294]: "22"
                - generic [ref=e295]: "23"
                - generic [ref=e296]: "24"
                - generic [ref=e297]: "25"
                - generic [ref=e298]: "26"
                - generic [ref=e299]: "27"
                - generic [ref=e300]: "28"
                - generic [ref=e301]: "29"
                - generic [ref=e302]: "30"
                - generic [ref=e303]: "31"
                - generic [ref=e304]: "32"
                - generic [ref=e305]: "33"
                - generic [ref=e306]: "34"
                - generic [ref=e307]: "35"
                - generic [ref=e308]: "36"
                - generic [ref=e309]: "37"
                - generic [ref=e310]: "38"
                - generic [ref=e311]: "39"
                - generic [ref=e312]: "40"
                - generic [ref=e313]: "41"
                - generic [ref=e314]: "42"
                - generic [ref=e315]: "43"
                - generic [ref=e316]: "44"
                - generic [ref=e317]: "45"
                - generic [ref=e318]: "46"
                - generic [ref=e319]: "47"
                - generic [ref=e320]: "48"
                - generic [ref=e321]: "49"
                - generic [ref=e322]: "50"
                - generic [ref=e323]: "51"
                - generic [ref=e324]: "52"
                - generic [ref=e325]: "53"
                - generic [ref=e326]: "54"
                - generic [ref=e327]: "55"
                - generic [ref=e328]: "56"
                - generic [ref=e329]: "57"
                - generic [ref=e330]: "58"
                - generic [ref=e331]: "59"
                - generic [ref=e332]: "60"
                - generic [ref=e333]: "61"
                - generic [ref=e334]: "62"
                - generic [ref=e335]: "63"
                - generic [ref=e336]: "64"
                - generic [ref=e337]: "65"
                - generic [ref=e338]: "66"
                - generic [ref=e339]: "67"
                - generic [ref=e340]: "68"
                - generic [ref=e341]: "69"
                - generic [ref=e342]: "70"
                - generic [ref=e343]: "71"
                - generic [ref=e344]: "72"
                - generic [ref=e345]: "73"
                - generic [ref=e346]: "74"
                - generic [ref=e347]: "75"
                - generic [ref=e348]: "76"
                - generic [ref=e349]: "77"
                - generic [ref=e350]: "78"
                - generic [ref=e351]: "79"
                - generic [ref=e352]: "80"
                - generic [ref=e353]: "81"
                - generic [ref=e354]: "82"
              - generic [ref=e355]:
                - generic [ref=e357]: ⌄
                - generic [ref=e358]: ⌄
                - generic [ref=e359]: ⌄
                - generic [ref=e360]: ⌄
                - generic [ref=e361]: ⌄
                - generic [ref=e362]: ⌄
                - generic [ref=e363]: ⌄
                - generic [ref=e364]: ⌄
                - generic [ref=e365]: ⌄
                - generic [ref=e366]: ⌄
                - generic [ref=e367]: ⌄
                - generic [ref=e368]: ⌄
                - generic [ref=e369]: ⌄
                - generic [ref=e370]: ⌄
                - generic [ref=e371]: ⌄
                - generic [ref=e372]: ⌄
                - generic [ref=e373]: ⌄
                - generic [ref=e374]: ⌄
                - generic [ref=e375]: ⌄
                - generic [ref=e376]: ⌄
                - generic [ref=e377]: ⌄
                - generic [ref=e378]: ⌄
                - generic [ref=e379]: ⌄
                - generic [ref=e380]: ⌄
                - generic [ref=e381]: ⌄
                - generic [ref=e382]: ⌄
                - generic [ref=e383]: ⌄
                - generic [ref=e384]: ⌄
                - generic [ref=e385]: ⌄
                - generic [ref=e386]: ⌄
                - generic [ref=e387]: ⌄
                - generic [ref=e388]: ⌄
                - generic [ref=e389]: ⌄
                - generic [ref=e390]: ⌄
                - generic [ref=e391]: ⌄
                - generic [ref=e392]: ⌄
                - generic [ref=e393]: ⌄
                - generic [ref=e394]: ⌄
                - generic [ref=e395]: ⌄
                - generic [ref=e396]: ⌄
                - generic [ref=e397]: ⌄
            - textbox [ref=e401]:
              - generic [ref=e402]: openapi 3.0.0
              - generic [ref=e403]: "info:"
              - generic [ref=e404]: "title: Order BFF"
              - generic [ref=e405]: "description: Sample Order BFF"
              - generic [ref=e406]: "version: '5.0'"
              - generic [ref=e407]: "contact:"
              - generic [ref=e408]: "email: devs@specmatic.io"
              - generic [ref=e409]: "servers:"
              - generic [ref=e410]: "- url: http://localhost:8080"
              - generic [ref=e411]: "tags:"
              - generic [ref=e412]: "- name: WIP"
              - generic [ref=e413]: "description: API still under development"
              - generic [ref=e414]: "- name: Product"
              - generic [ref=e415]: "description: Product Related APIs"
              - generic [ref=e416]: "- name: Order"
              - generic [ref=e417]: "description: Order Related APIs"
              - generic [ref=e418]: "- name: Monitor"
              - generic [ref=e419]: "description: Monitor Related APIs"
              - generic [ref=e420]: "paths:"
              - generic [ref=e421]: "/products:"
              - generic [ref=e422]: "summary: Create a new product"
              - generic [ref=e423]: "post:"
              - generic [ref=e424]: "description: Create a new product"
              - generic [ref=e425]: "operationId: createProduct"
              - generic [ref=e426]: "tags:"
              - generic [ref=e427]: "- Product"
              - generic [ref=e428]: "requestBody:"
              - generic [ref=e429]: "content:"
              - generic [ref=e430]: "application/json:"
              - generic [ref=e431]: "schema:"
              - generic [ref=e432]: "$ref: '#/components/schemas/ProductBase'"
              - generic [ref=e433]: "responses:"
              - generic [ref=e434]: "'201':"
              - generic [ref=e435]: "description: Product created"
              - generic [ref=e436]: "content:"
              - generic [ref=e437]: "application/json:"
              - generic [ref=e438]: "schema:"
              - generic [ref=e439]: "$ref: '#/components/schemas/Id'"
              - generic [ref=e440]: "'202':"
              - generic [ref=e441]: "description: Product Accepted"
              - generic [ref=e442]: "headers:"
              - generic [ref=e443]: "Link:"
              - generic [ref=e444]: "schema:"
              - generic [ref=e445]: "$ref: '#/components/schemas/MonitorLink'"
              - generic [ref=e446]: "'400':"
              - generic [ref=e447]: "description: Bad Request"
              - generic [ref=e448]: "content:"
              - generic [ref=e449]: "application/json:"
              - generic [ref=e450]: "schema:"
              - generic [ref=e451]: "$ref: '#/components/schemas/BadRequest'"
              - generic [ref=e452]: "/findAvailableProducts:"
              - generic [ref=e453]: "parameters:"
              - generic [ref=e454]: "- schema:"
              - generic [ref=e455]: "$ref : '#/components/schemas/ProductType'"
              - generic [ref=e456]: "name: type"
              - generic [ref=e457]: "in: query"
              - generic [ref=e458]: "required: false"
              - generic [ref=e459]: "- name: pageSize"
              - generic [ref=e460]: "in: header"
              - generic [ref=e461]: "schema:"
              - generic [ref=e462]: "type: integer"
              - generic [ref=e463]: "required: true"
              - generic [ref=e464]: "- name: from-date"
              - generic [ref=e465]: "in: query"
              - generic [ref=e466]: "required: true"
              - generic [ref=e467]: "schema:"
              - generic [ref=e468]: "type: string"
              - generic [ref=e469]: "format: date"
              - generic [ref=e470]: "- name: to-date"
              - generic [ref=e471]: "in: query"
              - generic [ref=e472]: "required: true"
              - generic [ref=e473]: "schema:"
              - generic [ref=e474]: "type: string"
              - generic [ref=e475]: "format: date"
              - generic [ref=e476]: "get:"
              - generic [ref=e477]: "description: Find available products"
              - generic [ref=e478]: "operationId: findAvailableProducts"
              - generic [ref=e479]: "tags:"
              - generic [ref=e480]: "- Product"
              - generic [ref=e481]: "responses:"
              - generic [ref=e482]: "'200':"
              - generic [ref=e483]: "description: OK"
    - text: Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  1  | import { test, expect } from "../../../utils/eyesFixture";
  2  | import { PRODUCT_SEARCH_BFF_SPEC_SAVE_INVALID_SPEC } from "../../specNames";
  3  | import {
  4  |   ServiceSpecConfigPage,
  5  |   Edit,
  6  | } from "../../../page-objects/service-spec-config-page";
  7  | 
  8  | test.describe("InValid Spec save and Error Dialog Display", () => {
  9  |   test(
  10 |     "Save Invalid Spec and Assert Error",
  11 |     { tag: ["@spec", "@invalidSpecChange", "@eyes"] },
  12 |     async ({ page, eyes }, testInfo) => {
  13 |       const configPage = new ServiceSpecConfigPage(
  14 |         page,
  15 |         testInfo,
  16 |         eyes,
  17 |         PRODUCT_SEARCH_BFF_SPEC_SAVE_INVALID_SPEC,
  18 |       );
  19 |       await test.step(`Go to Spec page for Service Spec: '${PRODUCT_SEARCH_BFF_SPEC_SAVE_INVALID_SPEC}'`, async () => {
  20 |         await configPage.gotoHomeAndOpenSidebar();
  21 |         await configPage.sideBar.selectSpec(
  22 |           PRODUCT_SEARCH_BFF_SPEC_SAVE_INVALID_SPEC,
  23 |         );
  24 |         await configPage.openSpecTab();
  25 |       });
  26 | 
  27 |       await test.step("Edit Spec and Save", async () => {
  28 |         const invalidEdit: Edit[] = [
  29 |           {
  30 |             current: { mode: "keyOnly", key: "openapi" },
  31 |             changeTo: "openapi 3.0.0",
  32 |           },
  33 |         ];
  34 | 
  35 |         await test.step("Introduce syntax error and save", async () => {
  36 |           await configPage.editSpec(invalidEdit);
  37 |           await configPage.clickSaveOpenApi();
  38 |         });
  39 | 
  40 |         await test.step("Assert 'Failed to save' dialog", async () => {
  41 |           await expect(configPage.alertMsg).toBeVisible();
  42 |           const alertText = await configPage.getAlertText();
  43 |           await configPage.dismissAlert();
  44 |           expect(alertText).toContain("Failed to save");
  45 |         });
  46 | 
  47 |         await test.step("Assert validation error details", async () => {
  48 |           await expect(configPage.validationErrorBtn).toBeVisible();
  49 |           const errorDetail = await configPage.expandAndGetValidationError();
  50 | 
> 51 |           expect(errorDetail).toMatch(
     |                               ^ Error: expect(received).toMatch(expected)
  52 |             /could not parse contract|implicit keys need to be on a single line/i,
  53 |           );
  54 |         });
  55 |       });
  56 |     },
  57 |   );
  58 | });
  59 | 
```