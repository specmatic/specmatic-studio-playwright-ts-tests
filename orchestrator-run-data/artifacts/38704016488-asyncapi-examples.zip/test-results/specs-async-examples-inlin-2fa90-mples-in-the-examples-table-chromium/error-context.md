# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/async/examples/inline-examples-readonly-v2.spec.ts >> AsyncAPI 2.x inline examples >> lists all inline examples in the examples table
- Location: specs/async/examples/inline-examples-readonly-v2.spec.ts:12:7

# Error details

```
Error: Waiting for visible selector from: .screen[data-active] .example[data-protocol="openapi"] table.examples-protocol-table, .screen[data-active] .example[data-protocol="openapi"] .examples-empty, .screen[data-active] .example[data-protocol="openapi"] #examples, .screen[data-active] table.examples-protocol-table, .screen[data-active] #valid-examples-table, .screen[data-active] #invalid-examples-table, .screen[data-active] table

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - text: Studio
    - link "Guide icon Tutorial" [ref=e6] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e7]
      - text: Tutorial
  - generic [ref=e10]:
    - heading [level=5] [ref=e12]: Reset Account
    - generic [ref=e14]: "WARNING: Your account will be restored to the state in which it was originally created. All modifications, imported specs and examples will be lost after the reset. Do you want to continue?"
    - generic [ref=e15]:
      - button [ref=e16] [cursor=pointer]: Cancel
      - button [ref=e17] [cursor=pointer]: Yes, Reset Account
  - generic [ref=e20]:
    - button "Record Specification" [ref=e21] [cursor=pointer]:
      - img "Record" [ref=e22]
    - button "Author Workflow" [ref=e23] [cursor=pointer]:
      - img "Workflow" [ref=e24]
  - button "Toggle sidebar" [ref=e26] [cursor=pointer]:
    - generic [ref=e27]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e28] [cursor=pointer]:
      - img "Activity" [ref=e29]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e30]:
    - text: (0) (0) (0) (0) Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run ⚠ Run Run Suite Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run
    - generic [ref=e31]:
      - generic [ref=e32]:
        - generic [ref=e33]:
          - paragraph [ref=e34]:
            - generic [ref=e37]:
              - generic [ref=e38]:
                - generic "inline-examples-readonly-v2.yaml" [ref=e39]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename inline-examples-readonly-v2.yaml" [ref=e40] [cursor=pointer]
          - text: "File path: ./test-async/inline-examples-readonly-v2.yaml"
        - list [ref=e43]:
          - listitem [ref=e44] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Async examples
          - listitem [ref=e45] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run async mock
          - listitem [ref=e46] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Run async tests
          - listitem [ref=e47] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e48]:
        - generic [ref=e49]:
          - text: Run Run Run Run Run Run Run
          - generic [ref=e51]:
            - generic [ref=e52]:
              - button "← Go Back" [ref=e53] [cursor=pointer]
              - list
            - list
        - generic [ref=e55]:
          - list [ref=e56]:
            - listitem [ref=e57] [cursor=pointer]:
              - img "success" [ref=e58]
              - paragraph [ref=e59]: "Success:"
              - generic [ref=e60]: "0"
            - listitem [ref=e61] [cursor=pointer]:
              - img "failed" [ref=e62]
              - paragraph [ref=e63]: "Failed:"
              - generic [ref=e64]: "0"
            - listitem [ref=e65] [cursor=pointer]:
              - img "skipped" [ref=e66]
              - paragraph [ref=e67]: "Skipped:"
              - generic [ref=e68]: "0"
            - listitem [ref=e69] [cursor=pointer]:
              - img "total-tests" [ref=e70]
              - paragraph [ref=e71]: "Total:"
              - generic [ref=e72]: "0"
          - generic [ref=e73]:
            - generic [ref=e74]:
              - checkbox "Enable In-Memory Broker" [checked] [ref=e75]
              - text: Enable In-Memory Broker
            - combobox [ref=e77]:
              - option "Kafka" [selected]
              - option "JMS"
            - textbox "Port" [ref=e79]
            - button "AsyncAPI servers info" [ref=e80] [cursor=pointer]: i
            - button "Run" [ref=e81] [cursor=pointer]
        - generic [ref=e85]:
          - list [ref=e86]:
            - listitem [ref=e87] [cursor=pointer]:
              - img "success" [ref=e88]
              - paragraph [ref=e89]: "Success:"
              - generic [ref=e90]: "0"
            - listitem [ref=e91] [cursor=pointer]:
              - img "failed" [ref=e92]
              - paragraph [ref=e93]: "Failed:"
              - generic [ref=e94]: "0"
            - listitem [ref=e95] [cursor=pointer]:
              - img "skipped" [ref=e96]
              - paragraph [ref=e97]: "Skipped:"
              - generic [ref=e98]: "0"
            - listitem [ref=e99] [cursor=pointer]:
              - img "total-tests" [ref=e100]
              - paragraph [ref=e101]: "Total:"
              - generic [ref=e102]: "0"
          - generic [ref=e103]:
            - button "AsyncAPI servers info" [ref=e104] [cursor=pointer]: i
            - button "Run" [ref=e105] [cursor=pointer]
    - text: Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run Run
  - generic [ref=e110]:
    - heading [level=5] [ref=e112]: Upgrade Specmatic Config
    - paragraph [ref=e114]: Current config is not on the latest version, Do you want to upgrade before exporting workflow?
    - generic [ref=e115]:
      - button [ref=e116] [cursor=pointer]: Keep current version
      - button [ref=e117] [cursor=pointer]: Upgrade to latest
  - generic [ref=e120]:
    - heading [level=5] [ref=e122]: AsyncAPI tests required
    - generic [ref=e123]:
      - paragraph [ref=e124]: "AsyncAPI tests require a `servers` section so Specmatic knows how to connect to your broker."
      - paragraph [ref=e125]: If the section is missing, defaults may be assumed and your tests may not target the intended server.
      - paragraph [ref=e126]:
        - text: "Reference:"
        - link [ref=e127] [cursor=pointer]:
          - /url: https://www.asyncapi.com/docs/reference/specification/v3.0.0#serversObject
          - text: AsyncAPI servers object
      - paragraph [ref=e128]:
        - text: "Sample spec:"
        - link [ref=e129] [cursor=pointer]:
          - /url: https://github.com/specmatic/specmatic-order-contracts/blob/main/io/specmatic/examples/store/asyncapi/3_0_0/sqs_kafka/order-service-sqs-kafka.yaml
          - text: Order service AsyncAPI
    - button [ref=e131] [cursor=pointer]: Close
  - contentinfo
```

# Test source

```ts
  97  | 
  98  |       // Determine if this is a tab by checking attributes
  99  |       const [role, dataType, dataActive] = await Promise.all([
  100 |         tabLocator.getAttribute("role"),
  101 |         tabLocator.getAttribute("data-type"),
  102 |         tabLocator.getAttribute("data-active"),
  103 |       ]);
  104 |       const isTab =
  105 |         role === "tab" ||
  106 |         dataType === "spec" ||
  107 |         dataType === "example-generation" ||
  108 |         dataType === "example";
  109 | 
  110 |       if (isTab) {
  111 |         if (dataActive !== "true") {
  112 |           await tabLocator.click({ force: true });
  113 |         }
  114 |       } else {
  115 |         await tabLocator.click({ force: true });
  116 |       }
  117 | 
  118 |       await this.waitForTabContentReady(dataType);
  119 |       await takeAndAttachScreenshot(this.page, screenshotName);
  120 |       return tabLocator;
  121 |     });
  122 |   }
  123 | 
  124 |   private async waitForTabContentReady(dataType: string | null): Promise<void> {
  125 |     const timeout = 15000;
  126 | 
  127 |     if (dataType === "test") {
  128 |       await this.waitForAnyVisible(
  129 |         [
  130 |           '.tab-pane[data-type="test"][data-active="true"] table#test',
  131 |           '[data-type="test"] table#test',
  132 |           "table#test",
  133 |           '[data-type="test"] .header ol.counts',
  134 |         ],
  135 |         timeout,
  136 |       );
  137 |       await this.waitForTableStructure("table#test");
  138 |       return;
  139 |     }
  140 | 
  141 |     if (dataType === "mock") {
  142 |       await this.waitForAnyVisible(
  143 |         [
  144 |           '.tab-pane[data-type="mock"][data-active="true"] table#mock',
  145 |           '[data-type="mock"] table#mock',
  146 |           "table#mock",
  147 |           '[data-type="mock"] .header ol.counts',
  148 |         ],
  149 |         timeout,
  150 |       );
  151 |       await this.waitForTableStructure("table#mock");
  152 |       return;
  153 |     }
  154 | 
  155 |     if (dataType === "example") {
  156 |       await this.waitForAnyVisible(
  157 |         [
  158 |           '.screen[data-active] .example[data-protocol="openapi"] table.examples-protocol-table',
  159 |           '.screen[data-active] .example[data-protocol="openapi"] .examples-empty',
  160 |           '.screen[data-active] .example[data-protocol="openapi"] #examples',
  161 |           ".screen[data-active] table.examples-protocol-table",
  162 |           ".screen[data-active] #valid-examples-table",
  163 |           ".screen[data-active] #invalid-examples-table",
  164 |           ".screen[data-active] table",
  165 |         ],
  166 |         timeout,
  167 |       );
  168 |       return;
  169 |     }
  170 | 
  171 |     if (dataType === "spec") {
  172 |       await this.waitForAnyVisible(
  173 |         [
  174 |           ".cm-content",
  175 |           ".cm-editor",
  176 |           ".CodeMirror",
  177 |           "textarea",
  178 |           "#editor-view-toggle-btn",
  179 |           ".editor-view-toggle",
  180 |           ".swagger-ui",
  181 |           ".swagger-container",
  182 |         ],
  183 |         timeout,
  184 |       );
  185 |       return;
  186 |     }
  187 | 
  188 |     await this.page
  189 |       .waitForLoadState("networkidle", { timeout: 3000 })
  190 |       .catch(() => {});
  191 |   }
  192 | 
  193 |   private async waitForAnyVisible(
  194 |     selectors: string[],
  195 |     timeout: number,
  196 |   ): Promise<void> {
> 197 |     await expect
      |     ^ Error: Waiting for visible selector from: .screen[data-active] .example[data-protocol="openapi"] table.examples-protocol-table, .screen[data-active] .example[data-protocol="openapi"] .examples-empty, .screen[data-active] .example[data-protocol="openapi"] #examples, .screen[data-active] table.examples-protocol-table, .screen[data-active] #valid-examples-table, .screen[data-active] #invalid-examples-table, .screen[data-active] table
  198 |       .poll(
  199 |         async () => {
  200 |           for (const selector of selectors) {
  201 |             const locator = this.page.locator(selector);
  202 |             const count = await locator.count();
  203 |             for (let i = 0; i < count; i++) {
  204 |               if (
  205 |                 await locator
  206 |                   .nth(i)
  207 |                   .isVisible()
  208 |                   .catch(() => false)
  209 |               ) {
  210 |                 return true;
  211 |               }
  212 |             }
  213 |           }
  214 |           return false;
  215 |         },
  216 |         {
  217 |           timeout,
  218 |           intervals: [200, 400, 800],
  219 |           message: `Waiting for visible selector from: ${selectors.join(", ")}`,
  220 |         },
  221 |       )
  222 |       .toBeTruthy();
  223 |   }
  224 | 
  225 |   private async waitForTableStructure(tableSelector: string): Promise<void> {
  226 |     const table = this.page.locator(tableSelector).first();
  227 |     await table.waitFor({ state: "visible", timeout: 15000 });
  228 | 
  229 |     await expect
  230 |       .poll(
  231 |         async () => {
  232 |           const [tbodyCount, rowCount, cellCount, generated] =
  233 |             await Promise.all([
  234 |               table.locator("tbody").count(),
  235 |               table.locator("tbody tr").count(),
  236 |               table.locator("tbody td").count(),
  237 |               table.getAttribute("data-generated"),
  238 |             ]);
  239 | 
  240 |           return (
  241 |             tbodyCount > 0 ||
  242 |             rowCount > 0 ||
  243 |             cellCount > 0 ||
  244 |             generated !== null
  245 |           );
  246 |         },
  247 |         {
  248 |           timeout: 5000,
  249 |           intervals: [150, 300, 600],
  250 |           message: `Waiting for table structure to load: ${tableSelector}`,
  251 |         },
  252 |       )
  253 |       .toBeTruthy();
  254 |   }
  255 | }
  256 | 
```