# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/soap/run-mock-server/run-soap-mock-server.spec.ts >> SOAP API Mocking >> Run Mock Server for SOAP Inventory Spec
- Location: specs/soap/run-mock-server/run-soap-mock-server.spec.ts:25:7

# Error details

```
Error: expect(locator).toHaveText(expected) failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-soap/mock/inventory_mock.wsdl")') }).first().locator('.info-message-box')
Expected pattern: /https?:\/\//
Received string:  ""
Timeout: 10000ms

Call log:
  - Expect "toHaveText" with timeout 10000ms
  - waiting for locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-soap/mock/inventory_mock.wsdl")') }).first().locator('.info-message-box')
    14 × locator resolved to <div class="info-message-box"></div>
       - unexpected value ""

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "inventory_mock.wsdl" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename inventory_mock.wsdl" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-soap/mock/inventory_mock.wsdl"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run Soap mock
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e38]:
        - generic [ref=e40]:
          - generic [ref=e41]:
            - list [ref=e42]:
              - listitem:
                - img "success"
                - paragraph: "Success:"
                - generic: "0"
              - listitem:
                - img "failed"
                - paragraph: "Failed:"
                - generic: "0"
              - listitem:
                - img "skipped"
                - paragraph: "Skipped:"
                - generic: "0"
              - listitem:
                - img "total-tests"
                - paragraph: "Total:"
                - generic: "0"
            - generic [ref=e43]:
              - textbox "Port" [ref=e45]
              - button "Run" [active] [ref=e46] [cursor=pointer]
          - table [ref=e49]:
            - rowgroup [ref=e50]:
              - row "Coverage Port (1) SoapAction (3) Remark Result" [ref=e51]:
                - columnheader "Coverage" [ref=e52]
                - columnheader "Port (1)"
                - columnheader "SoapAction (3)"
                - columnheader "Remark"
                - columnheader "Result"
            - rowgroup [ref=e53]:
              - row "0% /ws addInventory" [ref=e54]:
                - cell "0%"
                - cell "/ws"
                - cell "addInventory"
                - cell [ref=e55] [cursor=pointer]
                - cell [ref=e56] [cursor=pointer]: 0 0 0 0 0 0
              - row "0% getInventory" [ref=e57]:
                - cell "0%"
                - cell "getInventory"
                - cell [ref=e58] [cursor=pointer]
                - cell [ref=e59] [cursor=pointer]: 0 0 0 0 0 0
              - row "0% reduceInventory" [ref=e60]:
                - cell "0%"
                - cell "reduceInventory"
                - cell [ref=e61] [cursor=pointer]
                - cell [ref=e62] [cursor=pointer]: 0 0 0 0 0 0
        - generic [ref=e64]:
          - list [ref=e65]:
            - listitem [ref=e66] [cursor=pointer]:
              - img "success" [ref=e67]
              - paragraph [ref=e68]: "Success:"
              - generic [ref=e69]: "0"
            - listitem [ref=e70] [cursor=pointer]:
              - img "failed" [ref=e71]
              - paragraph [ref=e72]: "Failed:"
              - generic [ref=e73]: "0"
            - listitem [ref=e74] [cursor=pointer]:
              - img "skipped" [ref=e75]
              - paragraph [ref=e76]: "Skipped:"
              - generic [ref=e77]: "0"
            - listitem [ref=e78] [cursor=pointer]:
              - img "total-tests" [ref=e79]
              - paragraph [ref=e80]: "Total:"
              - generic [ref=e81]: "0"
          - generic [ref=e82]:
            - generic [ref=e83]:
              - generic [ref=e84]:
                - checkbox [ref=e85]
                - generic [ref=e86]: Generative
              - textbox "Service URL" [ref=e88]: http://localhost:8080
            - button "Run" [ref=e89] [cursor=pointer]
  - contentinfo
```

# Test source

```ts
  101 |     this.mockTableHeaderByKey = (key: string) =>
  102 |       this.mockTableHead.locator(`th[data-key="${key}"]`);
  103 | 
  104 |     this.contractTableResultSpan = (row: Locator, key: string) =>
  105 |       row.locator(`span[data-key="${key}"]`);
  106 | 
  107 |     this.mockTableResultSpan = (row: Locator, key: string) =>
  108 |       row.locator(`span[data-key="${key}"]`);
  109 | 
  110 |     this.drillDownHeaderForIndex = (drillDown: Locator) =>
  111 |       drillDown.locator(".header");
  112 | 
  113 |     this.drillDownSuccessPillForIndex = (drillDown: Locator) =>
  114 |       drillDown.locator(".header .meta .pill.green:has-text('Success')");
  115 | 
  116 |     this.drillDownRequestBlock = (drillDown: Locator) =>
  117 |       drillDown.locator(".req-res-block.req-res-block--request");
  118 | 
  119 |     this.drillDownResponseBlock = (drillDown: Locator) =>
  120 |       drillDown.locator(".req-res-block.req-res-block--response");
  121 | 
  122 |     this.mockTableRemarkCell = (path: string) =>
  123 |       this.mockTable
  124 |         .locator(
  125 |           `tbody tr:has(td[data-key="path"][data-value="${path}"]:has-text("${path}")) td[data-key="remark"]`,
  126 |         )
  127 |         .first();
  128 | 
  129 |     this.drillDownScenarioTitles =
  130 |       this.drillDownElements.locator("> .header > .title");
  131 | 
  132 |     // Initialize helper functions for filter operations
  133 |     this.mockCountHeaderByType = (type: string) =>
  134 |       this.mockCountsSection.locator(`li[data-type="${type}"]`).first();
  135 | 
  136 |     this.mockTableResultRowsByType = (type: string) =>
  137 |       this.mockTable.locator(
  138 |         `tbody tr:has(td[data-key="result"] span[data-key="${type}"][data-value]:not([data-value="0"]))`,
  139 |       );
  140 | 
  141 |     this.drillDownBackButton = this.specSection
  142 |       .locator(".header")
  143 |       .getByRole("button", { name: "Go Back" })
  144 |       .first();
  145 | 
  146 |     this.alertContainer = page.locator("#alert-container");
  147 |     this.alertMessage = this.alertContainer.locator(".alert-msg.error");
  148 | 
  149 |     this.sidebarProcessBar = (specName: string) =>
  150 |       page.locator(
  151 |         `#accordion-group-MOCK .process-bar[data-spec-path*="${specName}"]`,
  152 |       );
  153 |   }
  154 | 
  155 |   private async openRunMockTab() {
  156 |     return this.openApiTabPage.openRunMockServerTab();
  157 |   }
  158 | 
  159 |   async openRunMockServerTab(specName: string) {
  160 |     await this.gotoHome();
  161 |     await this.sideBar.selectSpec(specName);
  162 |     return this.openApiTabPage.openRunMockServerTab();
  163 |   }
  164 | 
  165 |   async fillMockPort(port?: number) {
  166 |     await this.mockPort.clear();
  167 |     if (port) {
  168 |       await this.mockPort.fill(port.toString());
  169 |       await takeAndAttachScreenshot(this.page, "entered Mock port");
  170 |     }
  171 |   }
  172 | 
  173 |   async startMockServer() {
  174 |     const isRunning = await this.mockToggleButton.getAttribute("data-running");
  175 |     if (isRunning === "false") {
  176 |       await takeAndAttachScreenshot(this.page, "starting-mock-server");
  177 |       await this.mockToggleButton.click();
  178 |       await takeAndAttachScreenshot(
  179 |         this.page,
  180 |         "started-mock-server",
  181 |         this.eyes,
  182 |       );
  183 |     }
  184 |   }
  185 | 
  186 |   async stopMockServer() {
  187 |     const isRunning = await this.mockToggleButton.getAttribute("data-running");
  188 | 
  189 |     if (isRunning === "true") {
  190 |       await this.mockToggleButton.click();
  191 | 
  192 |       await takeAndAttachScreenshot(
  193 |         this.page,
  194 |         "mock-server-stopped",
  195 |         this.eyes,
  196 |       );
  197 |     }
  198 |   }
  199 | 
  200 |   async getMockURL(): Promise<string> {
> 201 |     await expect(this.infoMessageBox).toHaveText(/https?:\/\//, {
      |                                       ^ Error: expect(locator).toHaveText(expected) failed
  202 |       timeout: 10000,
  203 |     });
  204 | 
  205 |     const fullText = await this.infoMessageBox.innerText();
  206 | 
  207 |     const urlMatch = fullText.match(/https?:\/\/[^\s]+/);
  208 | 
  209 |     if (!urlMatch) {
  210 |       throw new Error(`Failed to extract URL from text: "${fullText}"`);
  211 |     }
  212 | 
  213 |     const rawUrl = urlMatch[0];
  214 | 
  215 |     await takeAndAttachScreenshot(this.page, "mock-url-extraction");
  216 | 
  217 |     return rawUrl;
  218 |   }
  219 | 
  220 |   async assertAsyncMockStarted(
  221 |     expectedText: string | RegExp = /Kafka mock broker/i,
  222 |   ): Promise<void> {
  223 |     await expect(this.infoMessageBox).toBeVisible({ timeout: 30000 });
  224 |     await expect(this.infoMessageBox).toContainText(expectedText, {
  225 |       timeout: 30000,
  226 |     });
  227 |     await takeAndAttachScreenshot(
  228 |       this.page,
  229 |       "async-mock-started-verified",
  230 |       this.eyes,
  231 |     );
  232 |   }
  233 | 
  234 |   async clickContractTestsTab() {
  235 |     await this.contractTestBtn.click();
  236 |     await takeAndAttachScreenshot(this.page, "navigated-to-contract-tests");
  237 |   }
  238 | 
  239 |   async goBackToMockServerTab() {
  240 |     await this.specSection.waitFor({ state: "visible", timeout: 30000 });
  241 |     await this.runMockServerTab.waitFor({ state: "visible", timeout: 30000 });
  242 |     await this.openRunMockTab();
  243 |     await this.mockCountsSection
  244 |       .first()
  245 |       .waitFor({ state: "visible", timeout: 30000 });
  246 |     await takeAndAttachScreenshot(this.page, "navigated-back-to-mock-tab");
  247 |   }
  248 | 
  249 |   async enterServiceBaseURL(serviceUrl: string) {
  250 |     await expect(this.serviceUrlInput).toBeVisible({ timeout: 4000 });
  251 |     await this.serviceUrlInput.fill(serviceUrl);
  252 |     await takeAndAttachScreenshot(this.page, "service-url-entered");
  253 |   }
  254 | 
  255 |   async getMockTableResults() {
  256 |     const rows = await this.mockTableResults.all();
  257 | 
  258 |     const totals = {
  259 |       success: 0,
  260 |       failed: 0,
  261 |       error: 0,
  262 |       notcovered: 0,
  263 |       skipped: 0,
  264 |       total: 0,
  265 |     };
  266 |     for (const row of rows) {
  267 |       const s = await this.mockTableResultSpan(row, "success").getAttribute(
  268 |         "data-value",
  269 |       );
  270 |       totals.success += parseInt(s || "0", 10);
  271 |     }
  272 |     return totals;
  273 |   }
  274 | 
  275 |   async getContractTableResults() {
  276 |     const rows = await this.contractTableResults.all();
  277 | 
  278 |     const totals = { success: 0, failed: 0, total: 0, notcovered: 0 };
  279 |     for (const row of rows) {
  280 |       const [s, f, t, n] = await Promise.all([
  281 |         this.contractTableResultSpan(row, "success").getAttribute("data-value"),
  282 |         this.contractTableResultSpan(row, "failed").getAttribute("data-value"),
  283 |         this.contractTableResultSpan(row, "total").getAttribute("data-value"),
  284 |         this.contractTableResultSpan(row, "notcovered").getAttribute(
  285 |           "data-value",
  286 |         ),
  287 |       ]);
  288 |       totals.success += parseInt(s || "0", 10);
  289 |       totals.failed += parseInt(f || "0", 10);
  290 |       totals.total += parseInt(t || "0", 10);
  291 |       totals.notcovered += parseInt(n || "0", 10);
  292 |     }
  293 |     return totals;
  294 |   }
  295 | 
  296 |   async getMockSummaryHeaderValue(
  297 |     type: "success" | "failed" | "notcovered" | "excluded" | "total",
  298 |   ): Promise<number> {
  299 |     const countElement = this.mockCountByType(type);
  300 | 
  301 |     await countElement.waitFor({ state: "visible", timeout: 10000 });
```