# SOAP Mock Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 1 | 0 | 1 | 0 | 0 | 0 |

## Unexpected Failures

- **specs/soap/run-mock-server/run-soap-mock-server.spec.ts**: specs/soap/run-mock-server/run-soap-mock-server.spec.ts › SOAP API Mocking › Run Mock Server for SOAP Inventory Spec
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-soap-run-mock-server-ecafa-ver-for-SOAP-Inventory-Spec-chromium/test-failed-1.png`
  - Error Preview:
````
Error: expect(locator).toHaveText(expected) failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-soap/mock/inventory_mock.wsdl")') }).first().locator('.info-message-box')
Expected pattern: /https?:\/\//
Received string:  ""
Timeout: 10000ms

Call log:
````

## Expected Failures

_None_
