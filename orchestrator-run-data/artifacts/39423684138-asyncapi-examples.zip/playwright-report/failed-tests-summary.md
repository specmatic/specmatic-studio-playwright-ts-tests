# AsyncAPI Examples Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 8 | 4 | 1 | 0 | 0 | 3 |

## Unexpected Failures

- **specs/async/examples/inline-examples-readonly-v2.spec.ts**: specs/async/examples/inline-examples-readonly-v2.spec.ts › AsyncAPI 2.x inline examples › lists all inline examples in the examples table
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-async-examples-inlin-2fa90-mples-in-the-examples-table-chromium/test-failed-1.png`
  - Error Preview:
````
Error: Waiting for visible selector from: .screen[data-active] .example[data-protocol="openapi"] table.examples-protocol-table, .screen[data-active] .example[data-protocol="openapi"] .examples-empty, .screen[data-active] .example[data-protocol="openapi"] #examples, .screen[data-active] table.examples-protocol-table, .screen[data-active] #valid-examples-table, .screen[data-active] #invalid-examples-table, .screen[data-active] table

expect(received).toBeTruthy()

Received: false

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
````

## Expected Failures

_None_
