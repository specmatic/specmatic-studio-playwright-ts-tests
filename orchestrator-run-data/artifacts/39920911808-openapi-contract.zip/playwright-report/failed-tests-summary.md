# OpenAPI Contract Playwright Summary

| Total | Passed | Failed | Errors | Expected Failures | Skipped |
|-------|--------|--------|--------|-------------------|---------|
| 10 | 3 | 1 | 0 | 6 | 0 |

## Unexpected Failures

- **specs/openapi/execute-contract-tests/execute-contract-tests-filter-hover-coverage.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-filter-hover-coverage.spec.ts › API Contract Testing - Filter Hover and Coverage › Verify response hover message and coverage stability for success and failed filters
  - Status: failed
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-f2d95--success-and-failed-filters-chromium/test-failed-1.png`
  - Error Preview:
````
Error: Coverage should remain unchanged after rerun with failed filter

expect(received).toBe(expected) // Object.is equality

Expected: 36
Received: 45

Call Log:
````

## Expected Failures

- **specs/openapi/execute-contract-tests/execute-contract-tests-excluded.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-excluded.spec.ts › API Contract testing with test exclusion and inclusion › Exclude specific tests and verify excluded tests are not executed
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-e9acf-uded-tests-are-not-executed-chromium/test-finished-1.png`
  - Error Preview:
````
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /exclude/i })
Expected: visible
Error: strict mode violation: getByRole('button', { name: /exclude/i }) resolved to 2 elements:
    1) <button type="button" class="ifr__action ifr__action--edit" aria-label="Rename product_search_bff_v5_contract_tests_excluded.yaml">…</button> aka getByRole('button', { name: 'Rename' })
    2) <button class="filter" data-active="true">…</button> aka getByRole('button', { name: 'exclude Exclude' })

````

- **specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts › Generative Test Suite - Include/Exclude Combinations › Execute generative tests
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-c367e-ns-Execute-generative-tests-chromium/test-finished-1.png`
  - Error Preview:
````
Error: Business Check: Header counts must match expected values

expect(received).toStrictEqual(expected) // deep equality

- Expected  - 4
+ Received  + 4

  Object {
````

- **specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts › Generative Test Suite - Include/Exclude Combinations › Execute generative tests with specific row excluded
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-71aab--with-specific-row-excluded-chromium/test-finished-1.png`
  - Error Preview:
````
Error: Business Check: Header counts must match expected values

expect(received).toStrictEqual(expected) // deep equality

- Expected  - 4
+ Received  + 4

  Object {
````

- **specs/openapi/execute-contract-tests/execute-contract-tests-main.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-main.spec.ts › API Contract Testing › Run contract tests for openapi spec product_search_bff_v5.yaml with default settings
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-3a034--yaml-with-default-settings-chromium/test-finished-1.png`
  - Error Preview:
````
Error: Business Check: Header counts must match expected values

expect(received).toStrictEqual(expected) // deep equality

- Expected  - 3
+ Received  + 3

  Object {
````

- **specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts › API Contract Testing - Negative Scenarios › Verify error for invalid service URL
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-a4749-ror-for-invalid-service-URL-chromium/test-finished-1.png`
  - Error Preview:
````
Error: expect(locator).toContainText(expected) failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_negative.yaml")') }).first().locator('#prereq-error-alert').locator('#prereq-error-summary').filter({ visible: true })
Expected substring: "Tests could not run due to specification/example errors and governance criteria were not satisfied"
Received string:    "Failed to satisfy the governance criteria"
Timeout: 5000ms

Call log:
````

- **specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts**: specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts › API Contract Testing - Negative Scenarios › Verify error for invalid port
  - Status: failed (expected failure)
  - Screenshot: `/home/runner/work/specmatic-studio-playwright-ts-tests/specmatic-studio-playwright-ts-tests/test-results/specs-openapi-execute-cont-852d0-rify-error-for-invalid-port-chromium/test-finished-1.png`
  - Error Preview:
````
Error: expect(locator).toContainText(expected) failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_negative.yaml")') }).first().locator('#prereq-error-alert').locator('#prereq-error-summary').filter({ visible: true })
Expected substring: "Tests could not run due to specification/example errors and governance criteria were not satisfied"
Received string:    "Failed to satisfy the governance criteria"
Timeout: 5000ms

Call log:
````
