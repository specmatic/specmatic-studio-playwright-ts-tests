# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/execute-contract-tests/execute-contract-tests-main.spec.ts >> API Contract Testing >> Run contract tests for openapi spec product_search_bff_v5.yaml with default settings
- Location: specs/openapi/execute-contract-tests/execute-contract-tests-main.spec.ts:32:7

# Error details

```
Error: Business Check: Header counts must match expected values

expect(received).toStrictEqual(expected) // deep equality

- Expected  - 3
+ Received  + 3

  Object {
    "error": 0,
    "excluded": 0,
-   "failed": 20,
-   "notcovered": 7,
+   "failed": 13,
+   "notcovered": 10,
    "success": 12,
-   "total": 39,
+   "total": 35,
  }
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
      - generic [ref=e21]: "1"
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
            - button "Export as config"
        - generic:
          - generic:
            - button "TEST icon Test" [expanded]:
              - img "TEST icon"
              - text: Test
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: product_search_bff_v5_contract_tests_default.yaml
                  - generic:
                    - generic: Done
  - main [ref=e22]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - paragraph [ref=e26]:
            - generic [ref=e29]:
              - generic [ref=e30]:
                - generic "product_search_bff_v5_contract_tests_default.yaml" [ref=e31]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_contract_tests_default.yaml" [ref=e32] [cursor=pointer]
          - text: "File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_default.yaml"
        - list [ref=e35]:
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e39] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e40]:
        - table [ref=e44]:
          - rowgroup [ref=e45]:
            - row "S. No Path Method Request Response Examples Action" [ref=e46]:
              - columnheader [ref=e47]:
                - checkbox [ref=e49]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e50]:
            - row "/products POST application/json 201 application/json Generate" [ref=e51]:
              - cell [ref=e52]:
                - checkbox [ref=e53]
              - cell [ref=e54]
              - cell "/products" [ref=e55]
              - cell "POST" [ref=e56]:
                - paragraph [ref=e57]: POST
              - cell "application/json" [ref=e58]:
                - paragraph [ref=e59]: application/json
              - cell "201 application/json" [ref=e60]:
                - paragraph [ref=e61]: "201"
                - generic [ref=e62]: application/json
              - cell "Generate" [ref=e63]:
                - button "Generate" [ref=e65] [cursor=pointer]
              - cell [ref=e66]
            - row "202 Generate" [ref=e67]:
              - cell [ref=e68]:
                - checkbox [ref=e69]
              - cell [ref=e70]
              - cell "202" [ref=e71]:
                - paragraph [ref=e72]: "202"
              - cell "Generate" [ref=e73]:
                - button "Generate" [ref=e75] [cursor=pointer]
              - cell [ref=e76]
            - row "400 application/json Generate" [ref=e77]:
              - cell [ref=e78]:
                - checkbox [ref=e79]
              - cell [ref=e80]
              - cell "400 application/json" [ref=e81]:
                - paragraph [ref=e82]: "400"
                - generic [ref=e83]: application/json
              - cell "Generate" [ref=e84]:
                - button "Generate" [ref=e86] [cursor=pointer]
              - cell [ref=e87]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e88]:
              - cell [ref=e89]:
                - checkbox [ref=e90]
              - cell [ref=e91]
              - cell "/findAvailableProducts" [ref=e92]
              - cell "GET" [ref=e93]:
                - paragraph [ref=e94]: GET
              - cell "NA" [ref=e95]:
                - paragraph [ref=e96]: NA
              - cell "200 application/json" [ref=e97]:
                - paragraph [ref=e98]: "200"
                - generic [ref=e99]: application/json
              - cell "Generate" [ref=e100]:
                - button "Generate" [ref=e102] [cursor=pointer]
              - cell [ref=e103]
            - row "429 Generate" [ref=e104]:
              - cell [ref=e105]:
                - checkbox [ref=e106]
              - cell [ref=e107]
              - cell "429" [ref=e108]:
                - paragraph [ref=e109]: "429"
              - cell "Generate" [ref=e110]:
                - button "Generate" [ref=e112] [cursor=pointer]
              - cell [ref=e113]
            - row "400 application/json Generate" [ref=e114]:
              - cell [ref=e115]:
                - checkbox [ref=e116]
              - cell [ref=e117]
              - cell "400 application/json" [ref=e118]:
                - paragraph [ref=e119]: "400"
                - generic [ref=e120]: application/json
              - cell "Generate" [ref=e121]:
                - button "Generate" [ref=e123] [cursor=pointer]
              - cell [ref=e124]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e125]:
              - cell [ref=e126]:
                - checkbox [ref=e127]
              - cell [ref=e128]
              - cell "/ordres" [ref=e129]
              - cell "POST" [ref=e130]:
                - paragraph [ref=e131]: POST
              - cell "application/json" [ref=e132]:
                - paragraph [ref=e133]: application/json
              - cell "201 application/json" [ref=e134]:
                - paragraph [ref=e135]: "201"
                - generic [ref=e136]: application/json
              - cell "Generate" [ref=e137]:
                - button "Generate" [ref=e139] [cursor=pointer]
              - cell [ref=e140]
            - row "202 Generate" [ref=e141]:
              - cell [ref=e142]:
                - checkbox [ref=e143]
              - cell [ref=e144]
              - cell "202" [ref=e145]:
                - paragraph [ref=e146]: "202"
              - cell "Generate" [ref=e147]:
                - button "Generate" [ref=e149] [cursor=pointer]
              - cell [ref=e150]
            - row "400 application/json Generate" [ref=e151]:
              - cell [ref=e152]:
                - checkbox [ref=e153]
              - cell [ref=e154]
              - cell "400 application/json" [ref=e155]:
                - paragraph [ref=e156]: "400"
                - generic [ref=e157]: application/json
              - cell "Generate" [ref=e158]:
                - button "Generate" [ref=e160] [cursor=pointer]
              - cell [ref=e161]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e162]':
              - cell [ref=e163]:
                - checkbox [ref=e164]
              - cell [ref=e165]
              - 'cell "/monitor/{id}" [ref=e166]'
              - cell "GET" [ref=e167]:
                - paragraph [ref=e168]: GET
              - cell "NA" [ref=e169]:
                - paragraph [ref=e170]: NA
              - cell "200 application/json" [ref=e171]:
                - paragraph [ref=e172]: "200"
                - generic [ref=e173]: application/json
              - cell "Generate" [ref=e174]:
                - button "Generate" [ref=e176] [cursor=pointer]
              - cell [ref=e177]
            - row "400 application/json Generate" [ref=e178]:
              - cell [ref=e179]:
                - checkbox [ref=e180]
              - cell [ref=e181]
              - cell "400 application/json" [ref=e182]:
                - paragraph [ref=e183]: "400"
                - generic [ref=e184]: application/json
              - cell "Generate" [ref=e185]:
                - button "Generate" [ref=e187] [cursor=pointer]
              - cell [ref=e188]
        - generic [ref=e190]:
          - list [ref=e191]:
            - listitem [ref=e192] [cursor=pointer]:
              - img "success" [ref=e193]
              - paragraph [ref=e194]: "Success:"
              - generic [ref=e195]: "0"
            - listitem [ref=e196] [cursor=pointer]:
              - img "failed" [ref=e197]
              - paragraph [ref=e198]: "Failed:"
              - generic [ref=e199]: "0"
            - listitem [ref=e200] [cursor=pointer]:
              - img "skipped" [ref=e201]
              - paragraph [ref=e202]: "Skipped:"
              - generic [ref=e203]: "0"
            - listitem [ref=e204] [cursor=pointer]:
              - img "total-tests" [ref=e205]
              - paragraph [ref=e206]: "Total:"
              - generic [ref=e207]: "0"
          - generic [ref=e208]:
            - textbox "Port" [ref=e210]
            - button "Run" [ref=e211] [cursor=pointer]
        - generic [ref=e214]:
          - generic [ref=e215]:
            - text: ⚠
            - list [ref=e216]:
              - listitem [ref=e217] [cursor=pointer]:
                - img "success" [ref=e218]
                - paragraph [ref=e219]: "Success:"
                - generic [ref=e220]: "12"
              - listitem [ref=e221] [cursor=pointer]:
                - img "failed" [ref=e222]
                - paragraph [ref=e223]: "Failed:"
                - generic [ref=e224]: "13"
              - listitem [ref=e225] [cursor=pointer]:
                - img "skipped" [ref=e226]
                - paragraph [ref=e227]: "Skipped:"
                - generic [ref=e228]: "10"
              - listitem:
                - img "excluded"
                - paragraph: "Excluded:"
                - generic: "0"
              - listitem [ref=e229] [cursor=pointer]:
                - img "total-tests" [ref=e230]
                - paragraph [ref=e231]: "Total:"
                - generic [ref=e232]: "35"
            - generic [ref=e233]:
              - generic [ref=e234]:
                - generic [ref=e235]:
                  - checkbox [ref=e236]
                  - generic [ref=e237]: Generative
                - textbox "Service URL" [ref=e239]: http://order-bff:8080
              - button "Run" [ref=e240] [cursor=pointer]
          - group [ref=e241]:
            - generic "error Failed to satisfy the governance criteria" [ref=e242] [cursor=pointer]:
              - img "error" [ref=e243]
              - generic [ref=e244]: Failed to satisfy the governance criteria
          - generic [ref=e245]:
            - table [ref=e246]:
              - rowgroup [ref=e247]:
                - row "Coverage (9% / 9%) ⓘ Path (6) Method (6) Request (6) Response (13) Remark Result" [ref=e248]:
                  - columnheader [ref=e249]:
                    - checkbox [ref=e250]
                  - columnheader "Coverage (9% / 9%) ⓘ" [ref=e251]
                  - columnheader "Path (6)"
                  - columnheader "Method (6)"
                  - columnheader "Request (6)"
                  - columnheader "Response (13)"
                  - columnheader "Remark"
                  - columnheader "Result"
              - rowgroup [ref=e252]:
                - row "33% /products POST application/json 201 application/json covered success 12" [ref=e253]:
                  - cell [ref=e254]:
                    - checkbox [ref=e255]
                  - cell "33%"
                  - cell "/products"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json" [ref=e256] [cursor=pointer]:
                    - text: "201"
                    - generic [ref=e257]: application/json
                  - cell "covered" [ref=e258] [cursor=pointer]:
                    - generic [ref=e261]: covered
                  - cell "success 12" [ref=e262] [cursor=pointer]:
                    - generic [ref=e263]:
                      - img "success" [ref=e264]
                      - text: "12"
                    - text: 0 0 0 12
                - 'row "202 not implemented attempts: 12 matches: 0 failed 12" [ref=e265]':
                  - cell [ref=e266]:
                    - checkbox [ref=e267]
                  - cell "202" [ref=e268] [cursor=pointer]
                  - 'cell "not implemented attempts: 12 matches: 0" [ref=e269] [cursor=pointer]':
                    - generic [ref=e271]:
                      - generic [ref=e272]: not implemented
                      - generic [ref=e274]:
                        - generic [ref=e275]:
                          - text: "attempts:"
                          - strong [ref=e276]: "12"
                        - generic [ref=e277]:
                          - text: "matches:"
                          - strong [ref=e278]: "0"
                  - cell "failed 12" [ref=e279] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e280]:
                      - img "failed" [ref=e281]
                      - text: "12"
                    - text: 0 0 12
                - row "400 application/json Generative Disabled Examples Required" [ref=e282]:
                  - cell [ref=e283]:
                    - checkbox [ref=e284]
                  - cell "400 application/json" [ref=e285] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e286]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e287] [cursor=pointer]:
                    - generic [ref=e291]:
                      - button "Generative Disabled" [ref=e292]:
                        - generic [ref=e293]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e294]:
                        - generic [ref=e295]: Examples Required
                        - img
                  - cell [ref=e296] [cursor=pointer]: 0 0 1 0 1
                - 'row "0% /findAvailableProducts GET NA 200 application/json not implemented attempts: 1 matches: 0 failed 1" [ref=e297]':
                  - cell [ref=e298]:
                    - checkbox [ref=e299]
                  - cell "0%"
                  - cell "/findAvailableProducts"
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e300] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e301]: application/json
                  - 'cell "not implemented attempts: 1 matches: 0" [ref=e302] [cursor=pointer]':
                    - generic [ref=e304]:
                      - generic [ref=e305]: not implemented
                      - generic [ref=e307]:
                        - generic [ref=e308]:
                          - text: "attempts:"
                          - strong [ref=e309]: "1"
                        - generic [ref=e310]:
                          - text: "matches:"
                          - strong [ref=e311]: "0"
                  - cell "failed 1" [ref=e312] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e313]:
                      - img "failed" [ref=e314]
                      - text: "1"
                    - text: 0 0 1
                - row "429 Examples Required" [ref=e315]:
                  - cell [ref=e316]:
                    - checkbox [ref=e317]
                  - cell "429" [ref=e318] [cursor=pointer]
                  - cell "Examples Required" [ref=e319] [cursor=pointer]:
                    - button "Examples Required" [ref=e324]:
                      - generic [ref=e325]: Examples Required
                      - img
                  - cell [ref=e326] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e327]:
                  - cell [ref=e328]:
                    - checkbox [ref=e329]
                  - cell "400 application/json" [ref=e330] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e331]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e332] [cursor=pointer]:
                    - generic [ref=e336]:
                      - button "Generative Disabled" [ref=e337]:
                        - generic [ref=e338]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e339]:
                        - generic [ref=e340]: Examples Required
                        - img
                  - cell [ref=e341] [cursor=pointer]: 0 0 1 0 1
                - row "0% /ordres POST application/json 201 application/json" [ref=e342]:
                  - cell [ref=e343]:
                    - checkbox [ref=e344]
                  - cell "0%"
                  - cell "/ordres"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json" [ref=e345] [cursor=pointer]:
                    - text: "201"
                    - generic [ref=e346]: application/json
                  - cell [ref=e347] [cursor=pointer]
                  - cell [ref=e348] [cursor=pointer]: 0 0 1 0 1
                - row "202" [ref=e349]:
                  - cell [ref=e350]:
                    - checkbox [ref=e351]
                  - cell "202" [ref=e352] [cursor=pointer]
                  - cell [ref=e353] [cursor=pointer]
                  - cell [ref=e354] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e355]:
                  - cell [ref=e356]:
                    - checkbox [ref=e357]
                  - cell "400 application/json" [ref=e358] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e359]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e360] [cursor=pointer]:
                    - generic [ref=e364]:
                      - button "Generative Disabled" [ref=e365]:
                        - generic [ref=e366]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e367]:
                        - generic [ref=e368]: Examples Required
                        - img
                  - cell [ref=e369] [cursor=pointer]: 0 0 1 0 1
                - 'row "0% /monitor/{id} GET NA 200 application/json" [ref=e370]':
                  - cell [ref=e371]:
                    - checkbox [ref=e372]
                  - cell "0%"
                  - 'cell "/monitor/{id}"'
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e373] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e374]: application/json
                  - cell [ref=e375] [cursor=pointer]
                  - cell [ref=e376] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e377]:
                  - cell [ref=e378]:
                    - checkbox [ref=e379]
                  - cell "400 application/json" [ref=e380] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e381]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e382] [cursor=pointer]:
                    - generic [ref=e386]:
                      - button "Generative Disabled" [ref=e387]:
                        - generic [ref=e388]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e389]:
                        - generic [ref=e390]: Examples Required
                        - img
                  - cell [ref=e391] [cursor=pointer]: 0 0 1 0 1
                - row "0% /orders POST NA 0 Missing In Spec" [ref=e392]:
                  - cell [ref=e393]:
                    - checkbox [ref=e394]
                  - cell "0%"
                  - cell "/orders"
                  - cell "POST"
                  - cell "NA"
                  - cell "0" [ref=e395] [cursor=pointer]
                  - cell "Missing In Spec" [ref=e396] [cursor=pointer]:
                    - generic [ref=e399]: Missing In Spec
                  - cell [ref=e400] [cursor=pointer]: 0 0 1 0 1
                - row "0% /health GET NA 0 Missing In Spec" [ref=e401]:
                  - cell [ref=e402]:
                    - checkbox [ref=e403]
                  - cell "0%"
                  - cell "/health"
                  - cell "GET"
                  - cell "NA"
                  - cell "0" [ref=e404] [cursor=pointer]
                  - cell "Missing In Spec" [ref=e405] [cursor=pointer]:
                    - generic [ref=e408]: Missing In Spec
                  - cell [ref=e409] [cursor=pointer]: 0 0 1 0 1
            - generic [ref=e411]:
              - button "← Go Back" [ref=e412] [cursor=pointer]:
                - generic [ref=e413]: ←
                - paragraph [ref=e414]: Go Back
              - list [ref=e415]
        - generic [ref=e417]:
          - generic [ref=e419]:
            - generic "Switch between preview and editor" [ref=e420]:
              - generic [ref=e421]: Preview
              - button "Toggle editor view" [ref=e422] [cursor=pointer]
              - generic [ref=e424]: Editor
            - button "Test Backward Compatibility" [ref=e425] [cursor=pointer]
            - button "Generate Dictionary" [ref=e426] [cursor=pointer]
          - generic [ref=e429]:
            - generic:
              - img
            - generic [ref=e430]:
              - generic [ref=e434]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e436]:
                  - text: Order BFF
                  - generic [ref=e437]:
                    - generic [ref=e439]: "5.0"
                    - generic [ref=e441]: OAS 3.0
                - paragraph [ref=e444]: Sample Order BFF
                - link "Contact the developer" [ref=e446] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e449]:
                - heading "WIP API still under development" [level=3] [ref=e452] [cursor=pointer]:
                  - generic [ref=e453]: WIP
                  - paragraph [ref=e456]: API still under development
                  - button "Collapse operation" [expanded] [ref=e457]:
                    - img [ref=e458]
                - generic [ref=e461]:
                  - heading "Product Product Related APIs" [level=3] [ref=e462] [cursor=pointer]:
                    - generic [ref=e463]: Product
                    - paragraph [ref=e466]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e467]:
                      - img [ref=e468]
                  - generic [ref=e471]:
                    - generic [ref=e474] [cursor=pointer]:
                      - button "POST /products" [ref=e475]:
                        - generic [ref=e476]: POST
                        - generic [ref=e479]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e482]:
                        - img [ref=e483]
                    - generic [ref=e487] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e488]:
                        - generic [ref=e489]: GET
                        - generic [ref=e492]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e495]:
                        - img [ref=e496]
                - generic [ref=e499]:
                  - heading "Order Order Related APIs" [level=3] [ref=e500] [cursor=pointer]:
                    - generic [ref=e501]: Order
                    - paragraph [ref=e504]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e505]:
                      - img [ref=e506]
                  - generic [ref=e512] [cursor=pointer]:
                    - button "POST /ordres" [ref=e513]:
                      - generic [ref=e514]: POST
                      - generic [ref=e517]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e520]:
                      - img [ref=e521]
                - generic [ref=e524]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e525] [cursor=pointer]:
                    - generic [ref=e526]: Monitor
                    - paragraph [ref=e529]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e530]:
                      - img [ref=e531]
                  - generic [ref=e537] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e538]':
                      - generic [ref=e539]: GET
                      - generic [ref=e543]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e546]':
                      - img [ref=e547]
              - generic [ref=e551]:
                - heading "Schemas" [level=4] [ref=e552] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e553]:
                    - generic [ref=e554]: Schemas
                    - img [ref=e555]
                - generic [ref=e557]:
                  - button "ProductInventory" [ref=e560] [cursor=pointer]:
                    - generic [ref=e562]: ProductInventory
                  - button "Product Type" [ref=e565] [cursor=pointer]:
                    - generic [ref=e567]: Product Type
                  - button "MonitorLink" [ref=e570] [cursor=pointer]:
                    - generic [ref=e572]: MonitorLink
                  - button "Id" [ref=e575] [cursor=pointer]:
                    - generic [ref=e577]: Id
                  - button "Product Details" [ref=e580] [cursor=pointer]:
                    - generic [ref=e582]: Product Details
                  - button "Product" [ref=e585] [cursor=pointer]:
                    - generic [ref=e587]: Product
                  - button "CreatedOn" [ref=e590] [cursor=pointer]:
                    - generic [ref=e592]: CreatedOn
                  - button "Order Details" [ref=e595] [cursor=pointer]:
                    - generic [ref=e597]: Order Details
                  - button "Order" [ref=e600] [cursor=pointer]:
                    - generic [ref=e602]: Order
                  - button "MonitorResponse" [ref=e605] [cursor=pointer]:
                    - generic [ref=e607]: MonitorResponse
                  - button "Request" [ref=e610] [cursor=pointer]:
                    - generic [ref=e612]: Request
                  - button "Response" [ref=e615] [cursor=pointer]:
                    - generic [ref=e617]: Response
                  - button "HeaderItem" [ref=e620] [cursor=pointer]:
                    - generic [ref=e622]: HeaderItem
                  - button "Bad Request" [ref=e625] [cursor=pointer]:
                    - generic [ref=e627]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  1  | import { expect, test } from "../../../utils/eyesFixture";
  2  | import { ApiContractPage } from "../../../page-objects/api-contract-page";
  3  | import { PRODUCT_SEARCH_BFF_SPEC } from "../../specNames";
  4  | 
  5  | export async function validateSummaryAndTableCounts(
  6  |   contractPage: ApiContractPage,
  7  |   expected: {
  8  |     success: number;
  9  |     failed: number;
  10 |     total: number;
  11 |     error: number;
  12 |     notcovered: number;
  13 |     excluded: number;
  14 |   },
  15 | ) {
  16 |   await test.step("Verify Summary and Table Counts", async () => {
  17 |     const tableTotals = await contractPage.getAggregateTableResults();
  18 |     const headerTotals = await contractPage.getSummaryHeaderTotals();
  19 | 
  20 |     expect(
  21 |       tableTotals,
  22 |       "Internal Check: Table sum must match Header counts",
  23 |     ).toStrictEqual(headerTotals);
  24 | 
  25 |     expect(
  26 |       headerTotals,
  27 |       "Business Check: Header counts must match expected values",
> 28 |     ).toStrictEqual(expected);
     |       ^ Error: Business Check: Header counts must match expected values
  29 |   });
  30 | }
  31 | 
  32 | export async function toggleFailedTestViewForTableandRaw(
  33 |   contractPage: ApiContractPage,
  34 | ) {
  35 |   const failedCount = await contractPage.getFailedResultsCount(0);
  36 | 
  37 |   await expect(contractPage.failedResultCountSpans.nth(0)).toBeVisible();
  38 | 
  39 |   await contractPage.clickFailedResults(0);
  40 | 
  41 |   await contractPage.verifyFailedScenariosCount(failedCount);
  42 | 
  43 |   await expect(contractPage.drillDownScenarios).toHaveCount(failedCount, {
  44 |     timeout: 10000,
  45 |   });
  46 | 
  47 |   await contractPage.toggleScenarioViews(0);
  48 | 
  49 |   await contractPage.toggleScenarioViews(failedCount - 1);
  50 | }
  51 | 
  52 | export async function verifyAllContractRemarks(contractPage: ApiContractPage) {
  53 |   // TODO: Add verification for the new /inventory endpoint once the spec is updated
  54 | 
  55 |   /* await contractPage.verifyRowRemark(
  56 |     "/products",
  57 |     "POST",
  58 |     "201",
  59 |     "covered"
  60 |   ); 
  61 |   */
  62 | 
  63 |   await contractPage.verifyRowRemark(
  64 |     "/findAvailableProducts",
  65 |     "GET",
  66 |     "200",
  67 |     /covered/i,
  68 |   );
  69 | 
  70 |   await contractPage.verifyRowRemark(
  71 |     "/ordres",
  72 |     "POST",
  73 |     "201",
  74 |     "not implemented",
  75 |   );
  76 | 
  77 |   await contractPage.verifyRowRemark("/health", "GET", "0", "Missing In Spec");
  78 | }
  79 | 
  80 | export async function verifyRightSidebarStatus(
  81 |   contractPage: ApiContractPage,
  82 |   status: "Running" | "Done" | "Failed",
  83 |   specName: string,
  84 | ) {
  85 |   await contractPage.rightSidebar.open();
  86 |   const actualStatus = await contractPage.getSidebarStatusText(specName);
  87 |   expect(actualStatus.toLowerCase()).toBe(status.toLowerCase());
  88 |   await contractPage.rightSidebar.close();
  89 | }
  90 | 
```