# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/execute-contract-tests/execute-contract-tests-excluded.spec.ts >> API Contract testing with test exclusion and inclusion >> Exclude specific tests and verify excluded tests are not executed
- Location: specs/openapi/execute-contract-tests/execute-contract-tests-excluded.spec.ts:35:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /exclude/i })
Expected: visible
Error: strict mode violation: getByRole('button', { name: /exclude/i }) resolved to 2 elements:
    1) <button type="button" class="ifr__action ifr__action--edit" aria-label="Rename product_search_bff_v5_contract_tests_excluded.yaml">…</button> aka getByRole('button', { name: 'Rename' })
    2) <button class="filter" data-active="true">…</button> aka getByRole('button', { name: 'exclude Exclude' })

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('button', { name: /exclude/i })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
        - generic:
          - paragraph: No activity yet
          - paragraph: Your activity will show up here once you run tests, start/stop a mock server, or record a spec.
  - main [ref=e21]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run
    - generic [ref=e22]:
      - generic [ref=e23]:
        - generic [ref=e24]:
          - paragraph [ref=e25]:
            - generic [ref=e28]:
              - generic [ref=e29]:
                - generic "product_search_bff_v5_contract_tests_excluded.yaml" [ref=e30]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_contract_tests_excluded.yaml" [ref=e31] [cursor=pointer]
          - text: "File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_excluded.yaml"
        - list [ref=e34]:
          - listitem [ref=e35] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e39]:
        - table [ref=e43]:
          - rowgroup [ref=e44]:
            - row "S. No Path Method Request Response Examples Action" [ref=e45]:
              - columnheader [ref=e46]:
                - checkbox [ref=e48]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e49]:
            - row "/products POST application/json 201 application/json Generate" [ref=e50]:
              - cell [ref=e51]:
                - checkbox [ref=e52]
              - cell [ref=e53]
              - cell "/products" [ref=e54]
              - cell "POST" [ref=e55]:
                - paragraph [ref=e56]: POST
              - cell "application/json" [ref=e57]:
                - paragraph [ref=e58]: application/json
              - cell "201 application/json" [ref=e59]:
                - paragraph [ref=e60]: "201"
                - generic [ref=e61]: application/json
              - cell "Generate" [ref=e62]:
                - button "Generate" [ref=e64] [cursor=pointer]
              - cell [ref=e65]
            - row "202 Generate" [ref=e66]:
              - cell [ref=e67]:
                - checkbox [ref=e68]
              - cell [ref=e69]
              - cell "202" [ref=e70]:
                - paragraph [ref=e71]: "202"
              - cell "Generate" [ref=e72]:
                - button "Generate" [ref=e74] [cursor=pointer]
              - cell [ref=e75]
            - row "400 application/json Generate" [ref=e76]:
              - cell [ref=e77]:
                - checkbox [ref=e78]
              - cell [ref=e79]
              - cell "400 application/json" [ref=e80]:
                - paragraph [ref=e81]: "400"
                - generic [ref=e82]: application/json
              - cell "Generate" [ref=e83]:
                - button "Generate" [ref=e85] [cursor=pointer]
              - cell [ref=e86]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e87]:
              - cell [ref=e88]:
                - checkbox [ref=e89]
              - cell [ref=e90]
              - cell "/findAvailableProducts" [ref=e91]
              - cell "GET" [ref=e92]:
                - paragraph [ref=e93]: GET
              - cell "NA" [ref=e94]:
                - paragraph [ref=e95]: NA
              - cell "200 application/json" [ref=e96]:
                - paragraph [ref=e97]: "200"
                - generic [ref=e98]: application/json
              - cell "Generate" [ref=e99]:
                - button "Generate" [ref=e101] [cursor=pointer]
              - cell [ref=e102]
            - row "429 Generate" [ref=e103]:
              - cell [ref=e104]:
                - checkbox [ref=e105]
              - cell [ref=e106]
              - cell "429" [ref=e107]:
                - paragraph [ref=e108]: "429"
              - cell "Generate" [ref=e109]:
                - button "Generate" [ref=e111] [cursor=pointer]
              - cell [ref=e112]
            - row "400 application/json Generate" [ref=e113]:
              - cell [ref=e114]:
                - checkbox [ref=e115]
              - cell [ref=e116]
              - cell "400 application/json" [ref=e117]:
                - paragraph [ref=e118]: "400"
                - generic [ref=e119]: application/json
              - cell "Generate" [ref=e120]:
                - button "Generate" [ref=e122] [cursor=pointer]
              - cell [ref=e123]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e124]:
              - cell [ref=e125]:
                - checkbox [ref=e126]
              - cell [ref=e127]
              - cell "/ordres" [ref=e128]
              - cell "POST" [ref=e129]:
                - paragraph [ref=e130]: POST
              - cell "application/json" [ref=e131]:
                - paragraph [ref=e132]: application/json
              - cell "201 application/json" [ref=e133]:
                - paragraph [ref=e134]: "201"
                - generic [ref=e135]: application/json
              - cell "Generate" [ref=e136]:
                - button "Generate" [ref=e138] [cursor=pointer]
              - cell [ref=e139]
            - row "202 Generate" [ref=e140]:
              - cell [ref=e141]:
                - checkbox [ref=e142]
              - cell [ref=e143]
              - cell "202" [ref=e144]:
                - paragraph [ref=e145]: "202"
              - cell "Generate" [ref=e146]:
                - button "Generate" [ref=e148] [cursor=pointer]
              - cell [ref=e149]
            - row "400 application/json Generate" [ref=e150]:
              - cell [ref=e151]:
                - checkbox [ref=e152]
              - cell [ref=e153]
              - cell "400 application/json" [ref=e154]:
                - paragraph [ref=e155]: "400"
                - generic [ref=e156]: application/json
              - cell "Generate" [ref=e157]:
                - button "Generate" [ref=e159] [cursor=pointer]
              - cell [ref=e160]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e161]':
              - cell [ref=e162]:
                - checkbox [ref=e163]
              - cell [ref=e164]
              - 'cell "/monitor/{id}" [ref=e165]'
              - cell "GET" [ref=e166]:
                - paragraph [ref=e167]: GET
              - cell "NA" [ref=e168]:
                - paragraph [ref=e169]: NA
              - cell "200 application/json" [ref=e170]:
                - paragraph [ref=e171]: "200"
                - generic [ref=e172]: application/json
              - cell "Generate" [ref=e173]:
                - button "Generate" [ref=e175] [cursor=pointer]
              - cell [ref=e176]
            - row "400 application/json Generate" [ref=e177]:
              - cell [ref=e178]:
                - checkbox [ref=e179]
              - cell [ref=e180]
              - cell "400 application/json" [ref=e181]:
                - paragraph [ref=e182]: "400"
                - generic [ref=e183]: application/json
              - cell "Generate" [ref=e184]:
                - button "Generate" [ref=e186] [cursor=pointer]
              - cell [ref=e187]
        - generic [ref=e189]:
          - list [ref=e190]:
            - listitem [ref=e191] [cursor=pointer]:
              - img "success" [ref=e192]
              - paragraph [ref=e193]: "Success:"
              - generic [ref=e194]: "0"
            - listitem [ref=e195] [cursor=pointer]:
              - img "failed" [ref=e196]
              - paragraph [ref=e197]: "Failed:"
              - generic [ref=e198]: "0"
            - listitem [ref=e199] [cursor=pointer]:
              - img "skipped" [ref=e200]
              - paragraph [ref=e201]: "Skipped:"
              - generic [ref=e202]: "0"
            - listitem [ref=e203] [cursor=pointer]:
              - img "total-tests" [ref=e204]
              - paragraph [ref=e205]: "Total:"
              - generic [ref=e206]: "0"
          - generic [ref=e207]:
            - textbox "Port" [ref=e209]
            - button "Run" [ref=e210] [cursor=pointer]
        - generic [ref=e213]:
          - generic [ref=e214]:
            - generic [ref=e215]:
              - text: ⚠
              - button "exclude Exclude" [ref=e216] [cursor=pointer]:
                - img "exclude" [ref=e217]
                - generic [ref=e218]: Exclude
            - generic [ref=e219]:
              - generic [ref=e220]:
                - generic [ref=e221]:
                  - checkbox [ref=e222]
                  - generic [ref=e223]: Generative
                - textbox "Service URL" [ref=e225]: http://localhost:8080
              - button "Run" [ref=e226] [cursor=pointer]
          - table [ref=e228]:
            - rowgroup [ref=e229]:
              - row "Coverage Path (4) Method (4) Request (4) Response (11) Remark Result" [ref=e230]:
                - columnheader [ref=e231]:
                  - checkbox [ref=e232]
                - columnheader "Coverage"
                - columnheader "Path (4)"
                - columnheader "Method (4)"
                - columnheader "Request (4)"
                - columnheader "Response (11)"
                - columnheader "Remark"
                - columnheader "Result"
            - rowgroup [ref=e233]:
              - row "0% /products POST application/json 201 application/json" [ref=e234]:
                - cell [ref=e235] [cursor=pointer]:
                  - checkbox [checked] [active] [ref=e236]
                - cell "0%"
                - cell "/products"
                - cell "POST"
                - cell "application/json"
                - cell "201 application/json" [ref=e237] [cursor=pointer]:
                  - text: "201"
                  - generic [ref=e238]: application/json
                - cell [ref=e239] [cursor=pointer]
                - cell [ref=e240] [cursor=pointer]: 0 0 0 0 0
              - row "0% 202" [ref=e241]:
                - cell [ref=e242]:
                  - checkbox [ref=e243]
                - cell "0%"
                - cell "202" [ref=e244] [cursor=pointer]
                - cell [ref=e245] [cursor=pointer]
                - cell [ref=e246] [cursor=pointer]: 0 0 0 0 0
              - row "0% 400 application/json" [ref=e247]:
                - cell [ref=e248]:
                  - checkbox [ref=e249]
                - cell "0%"
                - cell "400 application/json" [ref=e250] [cursor=pointer]:
                  - text: "400"
                  - generic [ref=e251]: application/json
                - cell [ref=e252] [cursor=pointer]
                - cell [ref=e253] [cursor=pointer]: 0 0 0 0 0
              - row "0% /findAvailableProducts GET NA 200 application/json" [ref=e254]:
                - cell [ref=e255]:
                  - checkbox [ref=e256]
                - cell "0%"
                - cell "/findAvailableProducts"
                - cell "GET"
                - cell "NA"
                - cell "200 application/json" [ref=e257] [cursor=pointer]:
                  - text: "200"
                  - generic [ref=e258]: application/json
                - cell [ref=e259] [cursor=pointer]
                - cell [ref=e260] [cursor=pointer]: 0 0 0 0 0
              - row "0% 429" [ref=e261]:
                - cell [ref=e262]:
                  - checkbox [ref=e263]
                - cell "0%"
                - cell "429" [ref=e264] [cursor=pointer]
                - cell [ref=e265] [cursor=pointer]
                - cell [ref=e266] [cursor=pointer]: 0 0 0 0 0
              - row "0% 400 application/json" [ref=e267]:
                - cell [ref=e268]:
                  - checkbox [ref=e269]
                - cell "0%"
                - cell "400 application/json" [ref=e270] [cursor=pointer]:
                  - text: "400"
                  - generic [ref=e271]: application/json
                - cell [ref=e272] [cursor=pointer]
                - cell [ref=e273] [cursor=pointer]: 0 0 0 0 0
              - row "0% /ordres POST application/json 201 application/json" [ref=e274]:
                - cell [ref=e275]:
                  - checkbox [ref=e276]
                - cell "0%"
                - cell "/ordres"
                - cell "POST"
                - cell "application/json"
                - cell "201 application/json" [ref=e277] [cursor=pointer]:
                  - text: "201"
                  - generic [ref=e278]: application/json
                - cell [ref=e279] [cursor=pointer]
                - cell [ref=e280] [cursor=pointer]: 0 0 0 0 0
              - row "0% 202" [ref=e281]:
                - cell [ref=e282]:
                  - checkbox [ref=e283]
                - cell "0%"
                - cell "202" [ref=e284] [cursor=pointer]
                - cell [ref=e285] [cursor=pointer]
                - cell [ref=e286] [cursor=pointer]: 0 0 0 0 0
              - row "0% 400 application/json" [ref=e287]:
                - cell [ref=e288]:
                  - checkbox [ref=e289]
                - cell "0%"
                - cell "400 application/json" [ref=e290] [cursor=pointer]:
                  - text: "400"
                  - generic [ref=e291]: application/json
                - cell [ref=e292] [cursor=pointer]
                - cell [ref=e293] [cursor=pointer]: 0 0 0 0 0
              - 'row "0% /monitor/{id} GET NA 200 application/json" [ref=e294]':
                - cell [ref=e295]:
                  - checkbox [ref=e296]
                - cell "0%"
                - 'cell "/monitor/{id}"'
                - cell "GET"
                - cell "NA"
                - cell "200 application/json" [ref=e297] [cursor=pointer]:
                  - text: "200"
                  - generic [ref=e298]: application/json
                - cell [ref=e299] [cursor=pointer]
                - cell [ref=e300] [cursor=pointer]: 0 0 0 0 0
              - row "0% 400 application/json" [ref=e301]:
                - cell [ref=e302]:
                  - checkbox [ref=e303]
                - cell "0%"
                - cell "400 application/json" [ref=e304] [cursor=pointer]:
                  - text: "400"
                  - generic [ref=e305]: application/json
                - cell [ref=e306] [cursor=pointer]
                - cell [ref=e307] [cursor=pointer]: 0 0 0 0 0
        - generic [ref=e309]:
          - generic [ref=e311]:
            - generic "Switch between preview and editor" [ref=e312]:
              - generic [ref=e313]: Preview
              - button "Toggle editor view" [ref=e314] [cursor=pointer]
              - generic [ref=e316]: Editor
            - button "Test Backward Compatibility" [ref=e317] [cursor=pointer]
            - button "Generate Dictionary" [ref=e318] [cursor=pointer]
          - generic [ref=e321]:
            - generic:
              - img
            - generic [ref=e322]:
              - generic [ref=e326]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e328]:
                  - text: Order BFF
                  - generic [ref=e329]:
                    - generic [ref=e331]: "5.0"
                    - generic [ref=e333]: OAS 3.0
                - paragraph [ref=e336]: Sample Order BFF
                - link "Contact the developer" [ref=e338] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e341]:
                - heading "WIP API still under development" [level=3] [ref=e344] [cursor=pointer]:
                  - generic [ref=e345]: WIP
                  - paragraph [ref=e348]: API still under development
                  - button "Collapse operation" [expanded] [ref=e349]:
                    - img [ref=e350]
                - generic [ref=e353]:
                  - heading "Product Product Related APIs" [level=3] [ref=e354] [cursor=pointer]:
                    - generic [ref=e355]: Product
                    - paragraph [ref=e358]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e359]:
                      - img [ref=e360]
                  - generic [ref=e363]:
                    - generic [ref=e366] [cursor=pointer]:
                      - button "POST /products" [ref=e367]:
                        - generic [ref=e368]: POST
                        - generic [ref=e371]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e374]:
                        - img [ref=e375]
                    - generic [ref=e379] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e380]:
                        - generic [ref=e381]: GET
                        - generic [ref=e384]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e387]:
                        - img [ref=e388]
                - generic [ref=e391]:
                  - heading "Order Order Related APIs" [level=3] [ref=e392] [cursor=pointer]:
                    - generic [ref=e393]: Order
                    - paragraph [ref=e396]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e397]:
                      - img [ref=e398]
                  - generic [ref=e404] [cursor=pointer]:
                    - button "POST /ordres" [ref=e405]:
                      - generic [ref=e406]: POST
                      - generic [ref=e409]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e412]:
                      - img [ref=e413]
                - generic [ref=e416]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e417] [cursor=pointer]:
                    - generic [ref=e418]: Monitor
                    - paragraph [ref=e421]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e422]:
                      - img [ref=e423]
                  - generic [ref=e429] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e430]':
                      - generic [ref=e431]: GET
                      - generic [ref=e435]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e438]':
                      - img [ref=e439]
              - generic [ref=e443]:
                - heading "Schemas" [level=4] [ref=e444] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e445]:
                    - generic [ref=e446]: Schemas
                    - img [ref=e447]
                - generic [ref=e449]:
                  - button "ProductInventory" [ref=e452] [cursor=pointer]:
                    - generic [ref=e454]: ProductInventory
                  - button "Product Type" [ref=e457] [cursor=pointer]:
                    - generic [ref=e459]: Product Type
                  - button "MonitorLink" [ref=e462] [cursor=pointer]:
                    - generic [ref=e464]: MonitorLink
                  - button "Id" [ref=e467] [cursor=pointer]:
                    - generic [ref=e469]: Id
                  - button "Product Details" [ref=e472] [cursor=pointer]:
                    - generic [ref=e474]: Product Details
                  - button "Product" [ref=e477] [cursor=pointer]:
                    - generic [ref=e479]: Product
                  - button "CreatedOn" [ref=e482] [cursor=pointer]:
                    - generic [ref=e484]: CreatedOn
                  - button "Order Details" [ref=e487] [cursor=pointer]:
                    - generic [ref=e489]: Order Details
                  - button "Order" [ref=e492] [cursor=pointer]:
                    - generic [ref=e494]: Order
                  - button "MonitorResponse" [ref=e497] [cursor=pointer]:
                    - generic [ref=e499]: MonitorResponse
                  - button "Request" [ref=e502] [cursor=pointer]:
                    - generic [ref=e504]: Request
                  - button "Response" [ref=e507] [cursor=pointer]:
                    - generic [ref=e509]: Response
                  - button "HeaderItem" [ref=e512] [cursor=pointer]:
                    - generic [ref=e514]: HeaderItem
                  - button "Bad Request" [ref=e517] [cursor=pointer]:
                    - generic [ref=e519]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  831  |     return parseInt(value || "0", 10);
  832  |   }
  833  | 
  834  |   private async getRemarkMetricCount(
  835  |     remarkCell: Locator,
  836  |     metric: "attempts" | "matches",
  837  |   ): Promise<number> {
  838  |     const text = await remarkCell
  839  |       .locator(`strong[data-role="${metric}"]`)
  840  |       .innerText();
  841  |     return parseInt(text.trim() || "0", 10);
  842  |   }
  843  | 
  844  |   async hasRow(
  845  |     path: string,
  846  |     method: string,
  847  |     response: string,
  848  |   ): Promise<boolean> {
  849  |     return (await this.rowLocator(path, method, response).count()) > 0;
  850  |   }
  851  | 
  852  |   async assertRowVisible(path: string, method: string, response: string) {
  853  |     await expect(this.rowLocator(path, method, response)).toBeVisible({
  854  |       timeout: 10000,
  855  |     });
  856  |     await takeAndAttachScreenshot(
  857  |       this.page,
  858  |       `row-visible-${path}-${method}-${response}`.replace(
  859  |         /[^a-zA-Z0-9-]/g,
  860  |         "-",
  861  |       ),
  862  |       this.eyes,
  863  |     );
  864  |   }
  865  | 
  866  |   async assertRowAbsent(path: string, method: string, response: string) {
  867  |     await expect(this.rowLocator(path, method, response)).toHaveCount(0);
  868  |     await takeAndAttachScreenshot(
  869  |       this.page,
  870  |       `row-absent-${path}-${method}-${response}`.replace(/[^a-zA-Z0-9-]/g, "-"),
  871  |       this.eyes,
  872  |     );
  873  |   }
  874  | 
  875  |   async assertSummaryCountsCleared() {
  876  |     const totals = await this.getSummaryHeaderTotals();
  877  |     expect(totals).toStrictEqual({
  878  |       success: 0,
  879  |       failed: 0,
  880  |       notcovered: 0,
  881  |       excluded: 0,
  882  |       total: 0,
  883  |     });
  884  | 
  885  |     await takeAndAttachScreenshot(
  886  |       this.page,
  887  |       "contract-summary-counts-cleared",
  888  |       this.eyes,
  889  |     );
  890  |   }
  891  | 
  892  |   async selectTestForExclusionOrInclusion(
  893  |     path: string,
  894  |     method: string,
  895  |     response: string,
  896  |     { captureVisual = true }: { captureVisual?: boolean } = {},
  897  |   ) {
  898  |     const checkbox = this.exclusionCheckboxLocator(path, method, response);
  899  |     try {
  900  |       await expect(checkbox).toBeVisible({ timeout: 15000 });
  901  |     } catch (e) {
  902  |       await takeAndAttachScreenshot(
  903  |         this.page,
  904  |         `error-checkbox-not-visible-${path}-${method}-${response}`,
  905  |       );
  906  |       // Log the table DOM for debugging
  907  |       const tableHtml = await this.page
  908  |         .locator("table")
  909  |         .first()
  910  |         .innerHTML()
  911  |         .catch(() => "<no table>");
  912  |       console.error(`Table HTML for exclusion: ${tableHtml}`);
  913  |       throw new Error(
  914  |         `Exclusion checkbox not visible for ${path} ${method} ${response}: ${e}`,
  915  |       );
  916  |     }
  917  |     const isChecked = await checkbox.isChecked();
  918  |     if (!isChecked) {
  919  |       await checkbox.click();
  920  |     }
  921  |     if (captureVisual) {
  922  |       await takeAndAttachScreenshot(
  923  |         this.page,
  924  |         "excluded-test-" + `${path}-${method}-${response}`,
  925  |         this.eyes,
  926  |       );
  927  |     }
  928  |   }
  929  | 
  930  |   async clickExcludeButton() {
> 931  |     await expect(this.excludeButton).toBeVisible({ timeout: 10000 });
       |                                      ^ Error: expect(locator).toBeVisible() failed
  932  |     await this.excludeButton.click();
  933  |     await takeAndAttachScreenshot(
  934  |       this.page,
  935  |       "exclude-button-clicked",
  936  |       this.eyes,
  937  |     );
  938  |   }
  939  | 
  940  |   async clickIncludeButton() {
  941  |     await expect(this.includeButton).toBeVisible({
  942  |       timeout: 10000,
  943  |     });
  944  |     await this.includeButton.click();
  945  |     await takeAndAttachScreenshot(
  946  |       this.page,
  947  |       "include-button-clicked",
  948  |       this.eyes,
  949  |     );
  950  |   }
  951  | 
  952  |   async selectAllTestsForExclusion() {
  953  |     await this.headerCheckBox.check();
  954  |     await takeAndAttachScreenshot(this.page, "all-tests-checked", this.eyes);
  955  |   }
  956  | 
  957  |   async selectMultipleTests(
  958  |     testList: { path: string; method: string; response: string }[],
  959  |   ) {
  960  |     for (const testItem of testList) {
  961  |       await this.selectTestForExclusionOrInclusion(
  962  |         testItem.path,
  963  |         testItem.method,
  964  |         testItem.response,
  965  |         { captureVisual: false },
  966  |       );
  967  |     }
  968  |     await takeAndAttachScreenshot(
  969  |       this.page,
  970  |       `multiple-tests-selected-${testList.length}`,
  971  |       this.eyes,
  972  |     );
  973  |   }
  974  | 
  975  |   async getMixedOperationErrorText(): Promise<string> {
  976  |     await this.mixedOperationErrorContainer.waitFor({
  977  |       state: "visible",
  978  |       timeout: 5000,
  979  |     });
  980  |     const errorText = await this.mixedOperationErrorContainer.innerText();
  981  | 
  982  |     await takeAndAttachScreenshot(
  983  |       this.page,
  984  |       "mixed-operation-error-captured",
  985  |       this.eyes,
  986  |     );
  987  | 
  988  |     return errorText;
  989  |   }
  990  | 
  991  |   /**
  992  |    * Retrieves the 'data-total' attribute value for a specific header key
  993  |    * @param key 'path' | 'method' | 'response'
  994  |    */
  995  |   async getTableHeaderCount(key: string): Promise<number> {
  996  |     await takeAndAttachScreenshot(this.page, `header-count-${key}`);
  997  | 
  998  |     const enabledCount =
  999  |       await this.tableHeader(key).getAttribute("data-enabled");
  1000 | 
  1001 |     return parseInt(enabledCount || "0", 10);
  1002 |   }
  1003 | 
  1004 |   /**
  1005 |    * Scrapes the table and returns the count of unique values in a specific column
  1006 |    * @param columnIndex 0-based index
  1007 |    */
  1008 |   async getUniqueValuesInColumn(columnIndex: number): Promise<number> {
  1009 |     const rows = this.tableRows;
  1010 |     const count = await rows.count();
  1011 |     const uniqueValues = new Set();
  1012 | 
  1013 |     for (let i = 0; i < count; i++) {
  1014 |       const cellText = await rows
  1015 |         .nth(i)
  1016 |         .locator("td")
  1017 |         .nth(columnIndex)
  1018 |         .innerText();
  1019 |       uniqueValues.add(cellText.trim());
  1020 |     }
  1021 | 
  1022 |     return uniqueValues.size;
  1023 |   }
  1024 | 
  1025 |   async getUniqueValuesForKey(columnKey: string): Promise<number> {
  1026 |     const cells = this.page.locator(
  1027 |       `table#test tbody tr td[data-key="${columnKey}"]`,
  1028 |     );
  1029 |     const values = await cells.evaluateAll((elements) =>
  1030 |       elements
  1031 |         .map(
```