# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts >> API Contract Testing - Negative Scenarios >> Verify error for invalid service URL
- Location: specs/openapi/execute-contract-tests/execute-contract-tests-negative.spec.ts:22:7

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_negative.yaml")') }).first().locator('#prereq-error-alert').locator('#prereq-error-summary').filter({ visible: true })
Expected substring: "Tests could not run due to specification/example errors and governance criteria were not satisfied"
Received string:    "Failed to satisfy the governance criteria"
Timeout: 5000ms

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('.screen').filter({ has: locator('.info span[data-path]:has-text("File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_negative.yaml")') }).first().locator('#prereq-error-alert').locator('#prereq-error-summary').filter({ visible: true })
    9 × locator resolved to <span id="prereq-error-summary">Failed to satisfy the governance criteria</span>
      - unexpected value "Failed to satisfy the governance criteria"

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
      - generic [ref=e21]: "1"
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
            - button "Export as config"
        - generic:
          - generic:
            - button "TEST icon Test" [expanded]:
              - img "TEST icon"
              - text: Test
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: product_search_bff_v5_contract_tests_negative.yaml
                  - generic:
                    - generic: Done
  - main [ref=e22]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - paragraph [ref=e26]:
            - generic [ref=e29]:
              - generic [ref=e30]:
                - generic "product_search_bff_v5_contract_tests_negative.yaml" [ref=e31]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_contract_tests_negative.yaml" [ref=e32] [cursor=pointer]
          - text: "File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_negative.yaml"
        - list [ref=e35]:
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e39] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e40]:
        - table [ref=e44]:
          - rowgroup [ref=e45]:
            - row "S. No Path Method Request Response Examples Action" [ref=e46]:
              - columnheader [ref=e47]:
                - checkbox [ref=e49]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e50]:
            - row "/products POST application/json 201 application/json Generate" [ref=e51]:
              - cell [ref=e52]:
                - checkbox [ref=e53]
              - cell [ref=e54]
              - cell "/products" [ref=e55]
              - cell "POST" [ref=e56]:
                - paragraph [ref=e57]: POST
              - cell "application/json" [ref=e58]:
                - paragraph [ref=e59]: application/json
              - cell "201 application/json" [ref=e60]:
                - paragraph [ref=e61]: "201"
                - generic [ref=e62]: application/json
              - cell "Generate" [ref=e63]:
                - button "Generate" [ref=e65] [cursor=pointer]
              - cell [ref=e66]
            - row "202 Generate" [ref=e67]:
              - cell [ref=e68]:
                - checkbox [ref=e69]
              - cell [ref=e70]
              - cell "202" [ref=e71]:
                - paragraph [ref=e72]: "202"
              - cell "Generate" [ref=e73]:
                - button "Generate" [ref=e75] [cursor=pointer]
              - cell [ref=e76]
            - row "400 application/json Generate" [ref=e77]:
              - cell [ref=e78]:
                - checkbox [ref=e79]
              - cell [ref=e80]
              - cell "400 application/json" [ref=e81]:
                - paragraph [ref=e82]: "400"
                - generic [ref=e83]: application/json
              - cell "Generate" [ref=e84]:
                - button "Generate" [ref=e86] [cursor=pointer]
              - cell [ref=e87]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e88]:
              - cell [ref=e89]:
                - checkbox [ref=e90]
              - cell [ref=e91]
              - cell "/findAvailableProducts" [ref=e92]
              - cell "GET" [ref=e93]:
                - paragraph [ref=e94]: GET
              - cell "NA" [ref=e95]:
                - paragraph [ref=e96]: NA
              - cell "200 application/json" [ref=e97]:
                - paragraph [ref=e98]: "200"
                - generic [ref=e99]: application/json
              - cell "Generate" [ref=e100]:
                - button "Generate" [ref=e102] [cursor=pointer]
              - cell [ref=e103]
            - row "429 Generate" [ref=e104]:
              - cell [ref=e105]:
                - checkbox [ref=e106]
              - cell [ref=e107]
              - cell "429" [ref=e108]:
                - paragraph [ref=e109]: "429"
              - cell "Generate" [ref=e110]:
                - button "Generate" [ref=e112] [cursor=pointer]
              - cell [ref=e113]
            - row "400 application/json Generate" [ref=e114]:
              - cell [ref=e115]:
                - checkbox [ref=e116]
              - cell [ref=e117]
              - cell "400 application/json" [ref=e118]:
                - paragraph [ref=e119]: "400"
                - generic [ref=e120]: application/json
              - cell "Generate" [ref=e121]:
                - button "Generate" [ref=e123] [cursor=pointer]
              - cell [ref=e124]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e125]:
              - cell [ref=e126]:
                - checkbox [ref=e127]
              - cell [ref=e128]
              - cell "/ordres" [ref=e129]
              - cell "POST" [ref=e130]:
                - paragraph [ref=e131]: POST
              - cell "application/json" [ref=e132]:
                - paragraph [ref=e133]: application/json
              - cell "201 application/json" [ref=e134]:
                - paragraph [ref=e135]: "201"
                - generic [ref=e136]: application/json
              - cell "Generate" [ref=e137]:
                - button "Generate" [ref=e139] [cursor=pointer]
              - cell [ref=e140]
            - row "202 Generate" [ref=e141]:
              - cell [ref=e142]:
                - checkbox [ref=e143]
              - cell [ref=e144]
              - cell "202" [ref=e145]:
                - paragraph [ref=e146]: "202"
              - cell "Generate" [ref=e147]:
                - button "Generate" [ref=e149] [cursor=pointer]
              - cell [ref=e150]
            - row "400 application/json Generate" [ref=e151]:
              - cell [ref=e152]:
                - checkbox [ref=e153]
              - cell [ref=e154]
              - cell "400 application/json" [ref=e155]:
                - paragraph [ref=e156]: "400"
                - generic [ref=e157]: application/json
              - cell "Generate" [ref=e158]:
                - button "Generate" [ref=e160] [cursor=pointer]
              - cell [ref=e161]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e162]':
              - cell [ref=e163]:
                - checkbox [ref=e164]
              - cell [ref=e165]
              - 'cell "/monitor/{id}" [ref=e166]'
              - cell "GET" [ref=e167]:
                - paragraph [ref=e168]: GET
              - cell "NA" [ref=e169]:
                - paragraph [ref=e170]: NA
              - cell "200 application/json" [ref=e171]:
                - paragraph [ref=e172]: "200"
                - generic [ref=e173]: application/json
              - cell "Generate" [ref=e174]:
                - button "Generate" [ref=e176] [cursor=pointer]
              - cell [ref=e177]
            - row "400 application/json Generate" [ref=e178]:
              - cell [ref=e179]:
                - checkbox [ref=e180]
              - cell [ref=e181]
              - cell "400 application/json" [ref=e182]:
                - paragraph [ref=e183]: "400"
                - generic [ref=e184]: application/json
              - cell "Generate" [ref=e185]:
                - button "Generate" [ref=e187] [cursor=pointer]
              - cell [ref=e188]
        - generic [ref=e190]:
          - list [ref=e191]:
            - listitem [ref=e192] [cursor=pointer]:
              - img "success" [ref=e193]
              - paragraph [ref=e194]: "Success:"
              - generic [ref=e195]: "0"
            - listitem [ref=e196] [cursor=pointer]:
              - img "failed" [ref=e197]
              - paragraph [ref=e198]: "Failed:"
              - generic [ref=e199]: "0"
            - listitem [ref=e200] [cursor=pointer]:
              - img "skipped" [ref=e201]
              - paragraph [ref=e202]: "Skipped:"
              - generic [ref=e203]: "0"
            - listitem [ref=e204] [cursor=pointer]:
              - img "total-tests" [ref=e205]
              - paragraph [ref=e206]: "Total:"
              - generic [ref=e207]: "0"
          - generic [ref=e208]:
            - textbox "Port" [ref=e210]
            - button "Run" [ref=e211] [cursor=pointer]
        - generic [ref=e214]:
          - generic [ref=e215]:
            - text: ⚠
            - list [ref=e216]:
              - listitem:
                - img "success"
                - paragraph: "Success:"
                - generic: "0"
              - listitem [ref=e217] [cursor=pointer]:
                - img "failed" [ref=e218]
                - paragraph [ref=e219]: "Failed:"
                - generic [ref=e220]: "1"
              - listitem [ref=e221] [cursor=pointer]:
                - img "skipped" [ref=e222]
                - paragraph [ref=e223]: "Skipped:"
                - generic [ref=e224]: "10"
              - listitem:
                - img "excluded"
                - paragraph: "Excluded:"
                - generic: "0"
              - listitem [ref=e225] [cursor=pointer]:
                - img "total-tests" [ref=e226]
                - paragraph [ref=e227]: "Total:"
                - generic [ref=e228]: "11"
            - generic [ref=e229]:
              - generic [ref=e230]:
                - generic [ref=e231]:
                  - checkbox [ref=e232]
                  - generic [ref=e233]: Generative
                - textbox "Service URL" [ref=e235]: http://localhost:3124
              - button "Run" [active] [ref=e236] [cursor=pointer]
          - group [ref=e237]:
            - generic "error Failed to satisfy the governance criteria" [ref=e238] [cursor=pointer]:
              - img "error" [ref=e239]
              - generic [ref=e240]: Failed to satisfy the governance criteria
          - generic [ref=e241]:
            - table [ref=e242]:
              - rowgroup [ref=e243]:
                - row "Coverage (0% / 0%) ⓘ Path (4) Method (4) Request (4) Response (11) Remark Result" [ref=e244]:
                  - columnheader [ref=e245]:
                    - checkbox [ref=e246]
                  - columnheader "Coverage (0% / 0%) ⓘ" [ref=e247]
                  - columnheader "Path (4)"
                  - columnheader "Method (4)"
                  - columnheader "Request (4)"
                  - columnheader "Response (11)"
                  - columnheader "Remark"
                  - columnheader "Result"
              - rowgroup [ref=e248]:
                - 'row "0% /products POST application/json 201 application/json not implemented attempts: 1 matches: 0 failed 1" [ref=e249]':
                  - cell [ref=e250]:
                    - checkbox [ref=e251]
                  - cell "0%"
                  - cell "/products"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json" [ref=e252] [cursor=pointer]:
                    - text: "201"
                    - generic [ref=e253]: application/json
                  - 'cell "not implemented attempts: 1 matches: 0" [ref=e254] [cursor=pointer]':
                    - generic [ref=e256]:
                      - generic [ref=e257]: not implemented
                      - generic [ref=e259]:
                        - generic [ref=e260]:
                          - text: "attempts:"
                          - strong [ref=e261]: "1"
                        - generic [ref=e262]:
                          - text: "matches:"
                          - strong [ref=e263]: "0"
                  - cell "failed 1" [ref=e264] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e265]:
                      - img "failed" [ref=e266]
                      - text: "1"
                    - text: 0 0 1
                - row "202" [ref=e267]:
                  - cell [ref=e268]:
                    - checkbox [ref=e269]
                  - cell "202" [ref=e270] [cursor=pointer]
                  - cell [ref=e271] [cursor=pointer]
                  - cell [ref=e272] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e273]:
                  - cell [ref=e274]:
                    - checkbox [ref=e275]
                  - cell "400 application/json" [ref=e276] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e277]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e278] [cursor=pointer]:
                    - generic [ref=e282]:
                      - button "Generative Disabled" [ref=e283]:
                        - generic [ref=e284]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e285]:
                        - generic [ref=e286]: Examples Required
                        - img
                  - cell [ref=e287] [cursor=pointer]: 0 0 1 0 1
                - row "0% /findAvailableProducts GET NA 200 application/json" [ref=e288]:
                  - cell [ref=e289]:
                    - checkbox [ref=e290]
                  - cell "0%"
                  - cell "/findAvailableProducts"
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e291] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e292]: application/json
                  - cell [ref=e293] [cursor=pointer]
                  - cell [ref=e294] [cursor=pointer]: 0 0 1 0 1
                - row "429 Examples Required" [ref=e295]:
                  - cell [ref=e296]:
                    - checkbox [ref=e297]
                  - cell "429" [ref=e298] [cursor=pointer]
                  - cell "Examples Required" [ref=e299] [cursor=pointer]:
                    - button "Examples Required" [ref=e304]:
                      - generic [ref=e305]: Examples Required
                      - img
                  - cell [ref=e306] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e307]:
                  - cell [ref=e308]:
                    - checkbox [ref=e309]
                  - cell "400 application/json" [ref=e310] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e311]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e312] [cursor=pointer]:
                    - generic [ref=e316]:
                      - button "Generative Disabled" [ref=e317]:
                        - generic [ref=e318]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e319]:
                        - generic [ref=e320]: Examples Required
                        - img
                  - cell [ref=e321] [cursor=pointer]: 0 0 1 0 1
                - row "0% /ordres POST application/json 201 application/json" [ref=e322]:
                  - cell [ref=e323]:
                    - checkbox [ref=e324]
                  - cell "0%"
                  - cell "/ordres"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json" [ref=e325] [cursor=pointer]:
                    - text: "201"
                    - generic [ref=e326]: application/json
                  - cell [ref=e327] [cursor=pointer]
                  - cell [ref=e328] [cursor=pointer]: 0 0 1 0 1
                - row "202" [ref=e329]:
                  - cell [ref=e330]:
                    - checkbox [ref=e331]
                  - cell "202" [ref=e332] [cursor=pointer]
                  - cell [ref=e333] [cursor=pointer]
                  - cell [ref=e334] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e335]:
                  - cell [ref=e336]:
                    - checkbox [ref=e337]
                  - cell "400 application/json" [ref=e338] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e339]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e340] [cursor=pointer]:
                    - generic [ref=e344]:
                      - button "Generative Disabled" [ref=e345]:
                        - generic [ref=e346]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e347]:
                        - generic [ref=e348]: Examples Required
                        - img
                  - cell [ref=e349] [cursor=pointer]: 0 0 1 0 1
                - 'row "0% /monitor/{id} GET NA 200 application/json" [ref=e350]':
                  - cell [ref=e351]:
                    - checkbox [ref=e352]
                  - cell "0%"
                  - 'cell "/monitor/{id}"'
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e353] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e354]: application/json
                  - cell [ref=e355] [cursor=pointer]
                  - cell [ref=e356] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json Generative Disabled Examples Required" [ref=e357]:
                  - cell [ref=e358]:
                    - checkbox [ref=e359]
                  - cell "400 application/json" [ref=e360] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e361]: application/json
                  - cell "Generative Disabled Examples Required" [ref=e362] [cursor=pointer]:
                    - generic [ref=e366]:
                      - button "Generative Disabled" [ref=e367]:
                        - generic [ref=e368]: Generative Disabled
                        - img
                      - button "Examples Required" [ref=e369]:
                        - generic [ref=e370]: Examples Required
                        - img
                  - cell [ref=e371] [cursor=pointer]: 0 0 1 0 1
            - generic [ref=e373]:
              - button "← Go Back" [ref=e374] [cursor=pointer]:
                - generic [ref=e375]: ←
                - paragraph [ref=e376]: Go Back
              - list [ref=e377]
        - generic [ref=e379]:
          - generic [ref=e381]:
            - generic "Switch between preview and editor" [ref=e382]:
              - generic [ref=e383]: Preview
              - button "Toggle editor view" [ref=e384] [cursor=pointer]
              - generic [ref=e386]: Editor
            - button "Test Backward Compatibility" [ref=e387] [cursor=pointer]
            - button "Generate Dictionary" [ref=e388] [cursor=pointer]
          - generic [ref=e391]:
            - generic:
              - img
            - generic [ref=e392]:
              - generic [ref=e396]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e398]:
                  - text: Order BFF
                  - generic [ref=e399]:
                    - generic [ref=e401]: "5.0"
                    - generic [ref=e403]: OAS 3.0
                - paragraph [ref=e406]: Sample Order BFF
                - link "Contact the developer" [ref=e408] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e411]:
                - heading "WIP API still under development" [level=3] [ref=e414] [cursor=pointer]:
                  - generic [ref=e415]: WIP
                  - paragraph [ref=e418]: API still under development
                  - button "Collapse operation" [expanded] [ref=e419]:
                    - img [ref=e420]
                - generic [ref=e423]:
                  - heading "Product Product Related APIs" [level=3] [ref=e424] [cursor=pointer]:
                    - generic [ref=e425]: Product
                    - paragraph [ref=e428]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e429]:
                      - img [ref=e430]
                  - generic [ref=e433]:
                    - generic [ref=e436] [cursor=pointer]:
                      - button "POST /products" [ref=e437]:
                        - generic [ref=e438]: POST
                        - generic [ref=e441]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e444]:
                        - img [ref=e445]
                    - generic [ref=e449] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e450]:
                        - generic [ref=e451]: GET
                        - generic [ref=e454]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e457]:
                        - img [ref=e458]
                - generic [ref=e461]:
                  - heading "Order Order Related APIs" [level=3] [ref=e462] [cursor=pointer]:
                    - generic [ref=e463]: Order
                    - paragraph [ref=e466]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e467]:
                      - img [ref=e468]
                  - generic [ref=e474] [cursor=pointer]:
                    - button "POST /ordres" [ref=e475]:
                      - generic [ref=e476]: POST
                      - generic [ref=e479]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e482]:
                      - img [ref=e483]
                - generic [ref=e486]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e487] [cursor=pointer]:
                    - generic [ref=e488]: Monitor
                    - paragraph [ref=e491]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e492]:
                      - img [ref=e493]
                  - generic [ref=e499] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e500]':
                      - generic [ref=e501]: GET
                      - generic [ref=e505]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e508]':
                      - img [ref=e509]
              - generic [ref=e513]:
                - heading "Schemas" [level=4] [ref=e514] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e515]:
                    - generic [ref=e516]: Schemas
                    - img [ref=e517]
                - generic [ref=e519]:
                  - button "ProductInventory" [ref=e522] [cursor=pointer]:
                    - generic [ref=e524]: ProductInventory
                  - button "Product Type" [ref=e527] [cursor=pointer]:
                    - generic [ref=e529]: Product Type
                  - button "MonitorLink" [ref=e532] [cursor=pointer]:
                    - generic [ref=e534]: MonitorLink
                  - button "Id" [ref=e537] [cursor=pointer]:
                    - generic [ref=e539]: Id
                  - button "Product Details" [ref=e542] [cursor=pointer]:
                    - generic [ref=e544]: Product Details
                  - button "Product" [ref=e547] [cursor=pointer]:
                    - generic [ref=e549]: Product
                  - button "CreatedOn" [ref=e552] [cursor=pointer]:
                    - generic [ref=e554]: CreatedOn
                  - button "Order Details" [ref=e557] [cursor=pointer]:
                    - generic [ref=e559]: Order Details
                  - button "Order" [ref=e562] [cursor=pointer]:
                    - generic [ref=e564]: Order
                  - button "MonitorResponse" [ref=e567] [cursor=pointer]:
                    - generic [ref=e569]: MonitorResponse
                  - button "Request" [ref=e572] [cursor=pointer]:
                    - generic [ref=e574]: Request
                  - button "Response" [ref=e577] [cursor=pointer]:
                    - generic [ref=e579]: Response
                  - button "HeaderItem" [ref=e582] [cursor=pointer]:
                    - generic [ref=e584]: HeaderItem
                  - button "Bad Request" [ref=e587] [cursor=pointer]:
                    - generic [ref=e589]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  1357 |       excluded: values[3],
  1358 |       total: values[4],
  1359 |     };
  1360 |   }
  1361 | 
  1362 |   async getSoapSummaryHeaderTotals() {
  1363 |     await takeAndAttachScreenshot(
  1364 |       this.page,
  1365 |       "calculating SOAP summary header results",
  1366 |     );
  1367 | 
  1368 |     const getSpanValue = async (span: Locator): Promise<number> => {
  1369 |       try {
  1370 |         await span.waitFor({ state: "visible", timeout: 5000 });
  1371 |         const value = await span.getAttribute("data-value");
  1372 |         return parseInt(value || "0", 10);
  1373 |       } catch (e) {
  1374 |         const text = await span.innerText().catch(() => "0");
  1375 |         return parseInt(text || "0", 10);
  1376 |       }
  1377 |     };
  1378 | 
  1379 |     const [success, failed, notcovered, total] = await Promise.all([
  1380 |       getSpanValue(this.successCountSpan),
  1381 |       getSpanValue(this.failedCountSpan),
  1382 |       getSpanValue(this.notcoveredCountSpan),
  1383 |       getSpanValue(this.totalSpan),
  1384 |     ]);
  1385 | 
  1386 |     return {
  1387 |       success,
  1388 |       failed,
  1389 |       notcovered,
  1390 |       total,
  1391 |     };
  1392 |   }
  1393 | 
  1394 |   async getFailedResultsCount(index: number): Promise<number> {
  1395 |     const span = this._failedResultCountSpans.nth(index);
  1396 |     const value = await span.getAttribute("data-value");
  1397 |     return parseInt(value || "0", 10);
  1398 |   }
  1399 | 
  1400 |   async clickFailedResults(index: number): Promise<void> {
  1401 |     const span = this._failedResultCountSpans.nth(index);
  1402 |     await span.click();
  1403 |     await takeAndAttachScreenshot(this.page, "Clicked Failed Scenarios");
  1404 |   }
  1405 | 
  1406 |   async verifyFailedScenariosCount(expectedCount: number) {
  1407 |     await expect(this.resultsContainer).toBeVisible({ timeout: 10000 });
  1408 | 
  1409 |     await takeAndAttachScreenshot(
  1410 |       this.page,
  1411 |       `Expected Failed Scenario Count ${expectedCount}`,
  1412 |     );
  1413 |   }
  1414 | 
  1415 |   async toggleScenarioViews(scenarioIndex: number = 0) {
  1416 |     const scenario = this._drillDownScenarios.nth(scenarioIndex);
  1417 |     const header = scenario.locator(".header");
  1418 | 
  1419 |     if ((await header.getAttribute("aria-expanded")) === "false") {
  1420 |       await header.click();
  1421 |     }
  1422 | 
  1423 |     const rawBtn = scenario.locator("button.dd-viewBtn--details");
  1424 |     const tableBtn = scenario.locator("button.dd-viewBtn--errors");
  1425 |     const preDetails = scenario.locator("pre.detailsPre");
  1426 | 
  1427 |     await rawBtn.click();
  1428 |     await expect(preDetails).toBeVisible();
  1429 |     await expect(rawBtn).toHaveAttribute("aria-pressed", "true");
  1430 | 
  1431 |     await takeAndAttachScreenshot(
  1432 |       this.page,
  1433 |       "toggled-scenario-raw-view",
  1434 |       this.eyes,
  1435 |     );
  1436 | 
  1437 |     await tableBtn.click();
  1438 |     await expect(preDetails).toBeHidden();
  1439 |     await expect(scenario.locator("table.rulesTable")).toBeVisible();
  1440 | 
  1441 |     await takeAndAttachScreenshot(
  1442 |       this.page,
  1443 |       "toggled-scenario-table-view",
  1444 |       this.eyes,
  1445 |     );
  1446 |   }
  1447 | 
  1448 |   async verifyPrereqErrorVisible(expectedSummary: string | RegExp) {
  1449 |     const summary = this.getPrereqErrorSummary();
  1450 | 
  1451 |     await expect(summary).toBeAttached({ timeout: 15000 });
  1452 |     await takeAndAttachScreenshot(
  1453 |       this.page,
  1454 |       "prereq-error-verified",
  1455 |       this.eyes,
  1456 |     );
> 1457 |     await expect(summary).toContainText(expectedSummary);
       |                           ^ Error: expect(locator).toContainText(expected) failed
  1458 |   }
  1459 | 
  1460 |   async applyHeaderFilterAndGetExpectedCount(
  1461 |     filterType: string,
  1462 |   ): Promise<number | null> {
  1463 |     const header = this.headerByType(filterType);
  1464 | 
  1465 |     await expect(header, `Header "${filterType}" not found`).toBeVisible();
  1466 | 
  1467 |     const classAttr = (await header.getAttribute("class")) || "";
  1468 |     if (classAttr.includes("disabled")) {
  1469 |       console.info(`Filter "${filterType}" is disabled — skipping`);
  1470 |       return null;
  1471 |     }
  1472 | 
  1473 |     const expectedCount = await this.getHeaderCount(filterType);
  1474 | 
  1475 |     await header.click({ force: true });
  1476 | 
  1477 |     await expect(header).toHaveAttribute("data-active", "true", {
  1478 |       timeout: 10000,
  1479 |     });
  1480 | 
  1481 |     await takeAndAttachScreenshot(
  1482 |       this.page,
  1483 |       `filter-applied-for-${filterType}-tests`,
  1484 |       this.eyes,
  1485 |     );
  1486 | 
  1487 |     return expectedCount;
  1488 |   }
  1489 | 
  1490 |   async getHeaderCount(filterType: string): Promise<number> {
  1491 |     const header = await this.summaryCount(filterType);
  1492 | 
  1493 |     return parseInt((await header.getAttribute("data-value")) || "0", 10);
  1494 |   }
  1495 | 
  1496 |   async getTableCountByResult(filterType: string): Promise<number> {
  1497 |     const resultSpans = this.tableResultSpansByType(filterType);
  1498 | 
  1499 |     const count = await resultSpans.count();
  1500 |     let total = 0;
  1501 | 
  1502 |     for (let i = 0; i < count; i++) {
  1503 |       const value = await resultSpans.nth(i).getAttribute("data-value");
  1504 |       total += value ? Number(value) : 0;
  1505 |     }
  1506 | 
  1507 |     return total;
  1508 |   }
  1509 | 
  1510 |   async getFilterTypes(): Promise<string[]> {
  1511 |     const count = await this.filterListItems.count();
  1512 |     const filterTypes = new Set<string>();
  1513 | 
  1514 |     for (let i = 0; i < count; i++) {
  1515 |       const filterType = await this.filterListItems
  1516 |         .nth(i)
  1517 |         .getAttribute("data-type");
  1518 | 
  1519 |       if (filterType) {
  1520 |         filterTypes.add(filterType);
  1521 |       }
  1522 |     }
  1523 | 
  1524 |     return Array.from(filterTypes);
  1525 |   }
  1526 | 
  1527 |   async openContractTestTabForSpec(
  1528 |     testInfo: import("@playwright/test").TestInfo,
  1529 |     eyes: any,
  1530 |     specName: string,
  1531 |   ) {
  1532 |     await test.step(`Go to Example Generation page for Service Spec: '${specName}'`, async () => {
  1533 |       console.log(
  1534 |         `Opening Example Generation page for Service Spec: '${specName}'`,
  1535 |       );
  1536 |       await this.gotoHome();
  1537 |       await this.sideBar.selectSpec(specName);
  1538 |       await this.openExecuteContractTestsTab();
  1539 |     });
  1540 |   }
  1541 | 
  1542 |   async openContractTestTabViaSidebar(specName: string) {
  1543 |     await test.step(`Select '${specName}' via sidebar and open Contract Tests tab`, async () => {
  1544 |       await this.sideBar.selectSpec(specName);
  1545 |       await this.page.waitForTimeout(3000);
  1546 |       await this.openExecuteContractTestsTab();
  1547 |     });
  1548 |   }
  1549 | 
  1550 |   // Getters for accessing private locators from tests
  1551 |   get failedResultCountSpans(): Locator {
  1552 |     return this._failedResultCountSpans;
  1553 |   }
  1554 | 
  1555 |   get drillDownScenarios(): Locator {
  1556 |     return this._drillDownScenarios;
  1557 |   }
```