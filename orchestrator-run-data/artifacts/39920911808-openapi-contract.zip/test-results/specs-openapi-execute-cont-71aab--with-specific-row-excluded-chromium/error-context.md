# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts >> Generative Test Suite - Include/Exclude Combinations >> Execute generative tests with specific row excluded
- Location: specs/openapi/execute-contract-tests/execute-contract-tests-generative.spec.ts:60:9

# Error details

```
Error: Business Check: Header counts must match expected values

expect(received).toStrictEqual(expected) // deep equality

- Expected  - 4
+ Received  + 4

  Object {
    "error": 0,
    "excluded": 1,
-   "failed": 35,
-   "notcovered": 2,
-   "success": 176,
-   "total": 214,
+   "failed": 14,
+   "notcovered": 10,
+   "success": 0,
+   "total": 25,
  }
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
      - generic [ref=e21]: "1"
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
            - button "Export as config"
        - generic:
          - generic:
            - button "TEST icon Test" [expanded]:
              - img "TEST icon"
              - text: Test
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: product_search_bff_v5_contract_tests_generative.yaml
                  - generic:
                    - generic: Done
  - main [ref=e22]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - paragraph [ref=e26]:
            - generic [ref=e29]:
              - generic [ref=e30]:
                - generic "product_search_bff_v5_contract_tests_generative.yaml" [ref=e31]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_contract_tests_generative.yaml" [ref=e32] [cursor=pointer]
          - text: "File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_generative.yaml"
        - list [ref=e35]:
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e39] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e40]:
        - table [ref=e44]:
          - rowgroup [ref=e45]:
            - row "S. No Path Method Request Response Examples Action" [ref=e46]:
              - columnheader [ref=e47]:
                - checkbox [ref=e49]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e50]:
            - row "/products POST application/json 201 application/json Generate" [ref=e51]:
              - cell [ref=e52]:
                - checkbox [ref=e53]
              - cell [ref=e54]
              - cell "/products" [ref=e55]
              - cell "POST" [ref=e56]:
                - paragraph [ref=e57]: POST
              - cell "application/json" [ref=e58]:
                - paragraph [ref=e59]: application/json
              - cell "201 application/json" [ref=e60]:
                - paragraph [ref=e61]: "201"
                - generic [ref=e62]: application/json
              - cell "Generate" [ref=e63]:
                - button "Generate" [ref=e65] [cursor=pointer]
              - cell [ref=e66]
            - row "202 Generate" [ref=e67]:
              - cell [ref=e68]:
                - checkbox [ref=e69]
              - cell [ref=e70]
              - cell "202" [ref=e71]:
                - paragraph [ref=e72]: "202"
              - cell "Generate" [ref=e73]:
                - button "Generate" [ref=e75] [cursor=pointer]
              - cell [ref=e76]
            - row "400 application/json Generate" [ref=e77]:
              - cell [ref=e78]:
                - checkbox [ref=e79]
              - cell [ref=e80]
              - cell "400 application/json" [ref=e81]:
                - paragraph [ref=e82]: "400"
                - generic [ref=e83]: application/json
              - cell "Generate" [ref=e84]:
                - button "Generate" [ref=e86] [cursor=pointer]
              - cell [ref=e87]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e88]:
              - cell [ref=e89]:
                - checkbox [ref=e90]
              - cell [ref=e91]
              - cell "/findAvailableProducts" [ref=e92]
              - cell "GET" [ref=e93]:
                - paragraph [ref=e94]: GET
              - cell "NA" [ref=e95]:
                - paragraph [ref=e96]: NA
              - cell "200 application/json" [ref=e97]:
                - paragraph [ref=e98]: "200"
                - generic [ref=e99]: application/json
              - cell "Generate" [ref=e100]:
                - button "Generate" [ref=e102] [cursor=pointer]
              - cell [ref=e103]
            - row "429 Generate" [ref=e104]:
              - cell [ref=e105]:
                - checkbox [ref=e106]
              - cell [ref=e107]
              - cell "429" [ref=e108]:
                - paragraph [ref=e109]: "429"
              - cell "Generate" [ref=e110]:
                - button "Generate" [ref=e112] [cursor=pointer]
              - cell [ref=e113]
            - row "400 application/json Generate" [ref=e114]:
              - cell [ref=e115]:
                - checkbox [ref=e116]
              - cell [ref=e117]
              - cell "400 application/json" [ref=e118]:
                - paragraph [ref=e119]: "400"
                - generic [ref=e120]: application/json
              - cell "Generate" [ref=e121]:
                - button "Generate" [ref=e123] [cursor=pointer]
              - cell [ref=e124]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e125]:
              - cell [ref=e126]:
                - checkbox [ref=e127]
              - cell [ref=e128]
              - cell "/ordres" [ref=e129]
              - cell "POST" [ref=e130]:
                - paragraph [ref=e131]: POST
              - cell "application/json" [ref=e132]:
                - paragraph [ref=e133]: application/json
              - cell "201 application/json" [ref=e134]:
                - paragraph [ref=e135]: "201"
                - generic [ref=e136]: application/json
              - cell "Generate" [ref=e137]:
                - button "Generate" [ref=e139] [cursor=pointer]
              - cell [ref=e140]
            - row "202 Generate" [ref=e141]:
              - cell [ref=e142]:
                - checkbox [ref=e143]
              - cell [ref=e144]
              - cell "202" [ref=e145]:
                - paragraph [ref=e146]: "202"
              - cell "Generate" [ref=e147]:
                - button "Generate" [ref=e149] [cursor=pointer]
              - cell [ref=e150]
            - row "400 application/json Generate" [ref=e151]:
              - cell [ref=e152]:
                - checkbox [ref=e153]
              - cell [ref=e154]
              - cell "400 application/json" [ref=e155]:
                - paragraph [ref=e156]: "400"
                - generic [ref=e157]: application/json
              - cell "Generate" [ref=e158]:
                - button "Generate" [ref=e160] [cursor=pointer]
              - cell [ref=e161]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e162]':
              - cell [ref=e163]:
                - checkbox [ref=e164]
              - cell [ref=e165]
              - 'cell "/monitor/{id}" [ref=e166]'
              - cell "GET" [ref=e167]:
                - paragraph [ref=e168]: GET
              - cell "NA" [ref=e169]:
                - paragraph [ref=e170]: NA
              - cell "200 application/json" [ref=e171]:
                - paragraph [ref=e172]: "200"
                - generic [ref=e173]: application/json
              - cell "Generate" [ref=e174]:
                - button "Generate" [ref=e176] [cursor=pointer]
              - cell [ref=e177]
            - row "400 application/json Generate" [ref=e178]:
              - cell [ref=e179]:
                - checkbox [ref=e180]
              - cell [ref=e181]
              - cell "400 application/json" [ref=e182]:
                - paragraph [ref=e183]: "400"
                - generic [ref=e184]: application/json
              - cell "Generate" [ref=e185]:
                - button "Generate" [ref=e187] [cursor=pointer]
              - cell [ref=e188]
        - generic [ref=e190]:
          - list [ref=e191]:
            - listitem [ref=e192] [cursor=pointer]:
              - img "success" [ref=e193]
              - paragraph [ref=e194]: "Success:"
              - generic [ref=e195]: "0"
            - listitem [ref=e196] [cursor=pointer]:
              - img "failed" [ref=e197]
              - paragraph [ref=e198]: "Failed:"
              - generic [ref=e199]: "0"
            - listitem [ref=e200] [cursor=pointer]:
              - img "skipped" [ref=e201]
              - paragraph [ref=e202]: "Skipped:"
              - generic [ref=e203]: "0"
            - listitem [ref=e204] [cursor=pointer]:
              - img "total-tests" [ref=e205]
              - paragraph [ref=e206]: "Total:"
              - generic [ref=e207]: "0"
          - generic [ref=e208]:
            - textbox "Port" [ref=e210]
            - button "Run" [ref=e211] [cursor=pointer]
        - generic [ref=e214]:
          - generic [ref=e215]:
            - text: ⚠
            - list [ref=e216]:
              - listitem:
                - img "success"
                - paragraph: "Success:"
                - generic: "0"
              - listitem [ref=e217] [cursor=pointer]:
                - img "failed" [ref=e218]
                - paragraph [ref=e219]: "Failed:"
                - generic [ref=e220]: "14"
              - listitem [ref=e221] [cursor=pointer]:
                - img "skipped" [ref=e222]
                - paragraph [ref=e223]: "Skipped:"
                - generic [ref=e224]: "10"
              - listitem [ref=e225] [cursor=pointer]:
                - img "excluded" [ref=e226]
                - paragraph [ref=e227]: "Excluded:"
                - generic [ref=e228]: "1"
              - listitem [ref=e229] [cursor=pointer]:
                - img "total-tests" [ref=e230]
                - paragraph [ref=e231]: "Total:"
                - generic [ref=e232]: "25"
            - generic [ref=e233]:
              - generic [ref=e234]:
                - generic [ref=e235]:
                  - checkbox [checked] [ref=e236]
                  - generic [ref=e237]: Generative
                - textbox "Service URL" [ref=e239]: http://order-bff:8080
              - button "Run" [ref=e240] [cursor=pointer]
          - group [ref=e241]:
            - generic "error Failed to satisfy the governance criteria" [ref=e242] [cursor=pointer]:
              - img "error" [ref=e243]
              - generic [ref=e244]: Failed to satisfy the governance criteria
          - generic [ref=e245]:
            - table [ref=e246]:
              - rowgroup [ref=e247]:
                - row "Coverage (0% / 0%) ⓘ Path (6) Method (6) Request (6) Response (12/13) ⓘ Remark Result" [ref=e248]:
                  - columnheader [ref=e249]:
                    - checkbox [ref=e250]
                  - columnheader "Coverage (0% / 0%) ⓘ" [ref=e251]
                  - columnheader "Path (6)"
                  - columnheader "Method (6)"
                  - columnheader "Request (6)"
                  - columnheader "Response (12/13) ⓘ" [ref=e252]
                  - columnheader "Remark"
                  - columnheader "Result"
              - rowgroup [ref=e253]:
                - row "0% /products POST application/json 201 application/json Excluded":
                  - cell [ref=e254]:
                    - checkbox [ref=e255]
                  - cell "0%"
                  - cell "/products"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json":
                    - text: "201"
                    - generic: application/json
                  - cell "Excluded":
                    - generic:
                      - generic:
                        - generic: Excluded
                  - cell: 0 0 0 1 1
                - 'row "202 not implemented attempts: 13 matches: 0 1 undeclaredResponse failed 13" [ref=e256]':
                  - cell [ref=e257]:
                    - checkbox [ref=e258]
                  - cell "202" [ref=e259] [cursor=pointer]
                  - 'cell "not implemented attempts: 13 matches: 0 1 undeclaredResponse" [ref=e260] [cursor=pointer]':
                    - generic [ref=e262]:
                      - generic [ref=e263]: not implemented
                      - generic [ref=e265]:
                        - generic [ref=e266]:
                          - text: "attempts:"
                          - strong [ref=e267]: "13"
                        - generic [ref=e268]:
                          - text: "matches:"
                          - strong [ref=e269]: "0"
                      - generic [ref=e271]: 1 undeclaredResponse
                  - cell "failed 13" [ref=e272] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e273]:
                      - img "failed" [ref=e274]
                      - text: "13"
                    - text: 0 0 13
                - row "400 application/json" [ref=e275]:
                  - cell [ref=e276]:
                    - checkbox [ref=e277]
                  - cell "400 application/json" [ref=e278] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e279]: application/json
                  - cell [ref=e280] [cursor=pointer]
                  - cell [ref=e281] [cursor=pointer]: 0 0 1 0 1
                - 'row "0% /findAvailableProducts GET NA 200 application/json not implemented attempts: 1 matches: 0 failed 1" [ref=e282]':
                  - cell [ref=e283]:
                    - checkbox [ref=e284]
                  - cell "0%"
                  - cell "/findAvailableProducts"
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e285] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e286]: application/json
                  - 'cell "not implemented attempts: 1 matches: 0" [ref=e287] [cursor=pointer]':
                    - generic [ref=e289]:
                      - generic [ref=e290]: not implemented
                      - generic [ref=e292]:
                        - generic [ref=e293]:
                          - text: "attempts:"
                          - strong [ref=e294]: "1"
                        - generic [ref=e295]:
                          - text: "matches:"
                          - strong [ref=e296]: "0"
                  - cell "failed 1" [ref=e297] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e298]:
                      - img "failed" [ref=e299]
                      - text: "1"
                    - text: 0 0 1
                - row "429 Examples Required" [ref=e300]:
                  - cell [ref=e301]:
                    - checkbox [ref=e302]
                  - cell "429" [ref=e303] [cursor=pointer]
                  - cell "Examples Required" [ref=e304] [cursor=pointer]:
                    - button "Examples Required" [ref=e309]:
                      - generic [ref=e310]: Examples Required
                      - img
                  - cell [ref=e311] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json" [ref=e312]:
                  - cell [ref=e313]:
                    - checkbox [ref=e314]
                  - cell "400 application/json" [ref=e315] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e316]: application/json
                  - cell [ref=e317] [cursor=pointer]
                  - cell [ref=e318] [cursor=pointer]: 0 0 1 0 1
                - row "0% /ordres POST application/json 201 application/json" [ref=e319]:
                  - cell [ref=e320]:
                    - checkbox [ref=e321]
                  - cell "0%"
                  - cell "/ordres"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json" [ref=e322] [cursor=pointer]:
                    - text: "201"
                    - generic [ref=e323]: application/json
                  - cell [ref=e324] [cursor=pointer]
                  - cell [ref=e325] [cursor=pointer]: 0 0 1 0 1
                - row "202" [ref=e326]:
                  - cell [ref=e327]:
                    - checkbox [ref=e328]
                  - cell "202" [ref=e329] [cursor=pointer]
                  - cell [ref=e330] [cursor=pointer]
                  - cell [ref=e331] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json" [ref=e332]:
                  - cell [ref=e333]:
                    - checkbox [ref=e334]
                  - cell "400 application/json" [ref=e335] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e336]: application/json
                  - cell [ref=e337] [cursor=pointer]
                  - cell [ref=e338] [cursor=pointer]: 0 0 1 0 1
                - 'row "0% /monitor/{id} GET NA 200 application/json" [ref=e339]':
                  - cell [ref=e340]:
                    - checkbox [ref=e341]
                  - cell "0%"
                  - 'cell "/monitor/{id}"'
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json" [ref=e342] [cursor=pointer]:
                    - text: "200"
                    - generic [ref=e343]: application/json
                  - cell [ref=e344] [cursor=pointer]
                  - cell [ref=e345] [cursor=pointer]: 0 0 1 0 1
                - row "400 application/json" [ref=e346]:
                  - cell [ref=e347]:
                    - checkbox [ref=e348]
                  - cell "400 application/json" [ref=e349] [cursor=pointer]:
                    - text: "400"
                    - generic [ref=e350]: application/json
                  - cell [ref=e351] [cursor=pointer]
                  - cell [ref=e352] [cursor=pointer]: 0 0 1 0 1
                - row "0% /orders POST NA 0 Missing In Spec" [ref=e353]:
                  - cell [ref=e354]:
                    - checkbox [ref=e355]
                  - cell "0%"
                  - cell "/orders"
                  - cell "POST"
                  - cell "NA"
                  - cell "0" [ref=e356] [cursor=pointer]
                  - cell "Missing In Spec" [ref=e357] [cursor=pointer]:
                    - generic [ref=e360]: Missing In Spec
                  - cell [ref=e361] [cursor=pointer]: 0 0 1 0 1
                - row "0% /health GET NA 0 Missing In Spec" [ref=e362]:
                  - cell [ref=e363]:
                    - checkbox [ref=e364]
                  - cell "0%"
                  - cell "/health"
                  - cell "GET"
                  - cell "NA"
                  - cell "0" [ref=e365] [cursor=pointer]
                  - cell "Missing In Spec" [ref=e366] [cursor=pointer]:
                    - generic [ref=e369]: Missing In Spec
                  - cell [ref=e370] [cursor=pointer]: 0 0 1 0 1
            - generic [ref=e372]:
              - button "← Go Back" [ref=e373] [cursor=pointer]:
                - generic [ref=e374]: ←
                - paragraph [ref=e375]: Go Back
              - list [ref=e376]
        - generic [ref=e378]:
          - generic [ref=e380]:
            - generic "Switch between preview and editor" [ref=e381]:
              - generic [ref=e382]: Preview
              - button "Toggle editor view" [ref=e383] [cursor=pointer]
              - generic [ref=e385]: Editor
            - button "Test Backward Compatibility" [ref=e386] [cursor=pointer]
            - button "Generate Dictionary" [ref=e387] [cursor=pointer]
          - generic [ref=e390]:
            - generic:
              - img
            - generic [ref=e391]:
              - generic [ref=e395]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e397]:
                  - text: Order BFF
                  - generic [ref=e398]:
                    - generic [ref=e400]: "5.0"
                    - generic [ref=e402]: OAS 3.0
                - paragraph [ref=e405]: Sample Order BFF
                - link "Contact the developer" [ref=e407] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e410]:
                - heading "WIP API still under development" [level=3] [ref=e413] [cursor=pointer]:
                  - generic [ref=e414]: WIP
                  - paragraph [ref=e417]: API still under development
                  - button "Collapse operation" [expanded] [ref=e418]:
                    - img [ref=e419]
                - generic [ref=e422]:
                  - heading "Product Product Related APIs" [level=3] [ref=e423] [cursor=pointer]:
                    - generic [ref=e424]: Product
                    - paragraph [ref=e427]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e428]:
                      - img [ref=e429]
                  - generic [ref=e432]:
                    - generic [ref=e435] [cursor=pointer]:
                      - button "POST /products" [ref=e436]:
                        - generic [ref=e437]: POST
                        - generic [ref=e440]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e443]:
                        - img [ref=e444]
                    - generic [ref=e448] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e449]:
                        - generic [ref=e450]: GET
                        - generic [ref=e453]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e456]:
                        - img [ref=e457]
                - generic [ref=e460]:
                  - heading "Order Order Related APIs" [level=3] [ref=e461] [cursor=pointer]:
                    - generic [ref=e462]: Order
                    - paragraph [ref=e465]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e466]:
                      - img [ref=e467]
                  - generic [ref=e473] [cursor=pointer]:
                    - button "POST /ordres" [ref=e474]:
                      - generic [ref=e475]: POST
                      - generic [ref=e478]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e481]:
                      - img [ref=e482]
                - generic [ref=e485]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e486] [cursor=pointer]:
                    - generic [ref=e487]: Monitor
                    - paragraph [ref=e490]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e491]:
                      - img [ref=e492]
                  - generic [ref=e498] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e499]':
                      - generic [ref=e500]: GET
                      - generic [ref=e504]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e507]':
                      - img [ref=e508]
              - generic [ref=e512]:
                - heading "Schemas" [level=4] [ref=e513] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e514]:
                    - generic [ref=e515]: Schemas
                    - img [ref=e516]
                - generic [ref=e518]:
                  - button "ProductInventory" [ref=e521] [cursor=pointer]:
                    - generic [ref=e523]: ProductInventory
                  - button "Product Type" [ref=e526] [cursor=pointer]:
                    - generic [ref=e528]: Product Type
                  - button "MonitorLink" [ref=e531] [cursor=pointer]:
                    - generic [ref=e533]: MonitorLink
                  - button "Id" [ref=e536] [cursor=pointer]:
                    - generic [ref=e538]: Id
                  - button "Product Details" [ref=e541] [cursor=pointer]:
                    - generic [ref=e543]: Product Details
                  - button "Product" [ref=e546] [cursor=pointer]:
                    - generic [ref=e548]: Product
                  - button "CreatedOn" [ref=e551] [cursor=pointer]:
                    - generic [ref=e553]: CreatedOn
                  - button "Order Details" [ref=e556] [cursor=pointer]:
                    - generic [ref=e558]: Order Details
                  - button "Order" [ref=e561] [cursor=pointer]:
                    - generic [ref=e563]: Order
                  - button "MonitorResponse" [ref=e566] [cursor=pointer]:
                    - generic [ref=e568]: MonitorResponse
                  - button "Request" [ref=e571] [cursor=pointer]:
                    - generic [ref=e573]: Request
                  - button "Response" [ref=e576] [cursor=pointer]:
                    - generic [ref=e578]: Response
                  - button "HeaderItem" [ref=e581] [cursor=pointer]:
                    - generic [ref=e583]: HeaderItem
                  - button "Bad Request" [ref=e586] [cursor=pointer]:
                    - generic [ref=e588]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  1  | import { expect, test } from "../../../utils/eyesFixture";
  2  | import { ApiContractPage } from "../../../page-objects/api-contract-page";
  3  | import { PRODUCT_SEARCH_BFF_SPEC } from "../../specNames";
  4  | 
  5  | export async function validateSummaryAndTableCounts(
  6  |   contractPage: ApiContractPage,
  7  |   expected: {
  8  |     success: number;
  9  |     failed: number;
  10 |     total: number;
  11 |     error: number;
  12 |     notcovered: number;
  13 |     excluded: number;
  14 |   },
  15 | ) {
  16 |   await test.step("Verify Summary and Table Counts", async () => {
  17 |     const tableTotals = await contractPage.getAggregateTableResults();
  18 |     const headerTotals = await contractPage.getSummaryHeaderTotals();
  19 | 
  20 |     expect(
  21 |       tableTotals,
  22 |       "Internal Check: Table sum must match Header counts",
  23 |     ).toStrictEqual(headerTotals);
  24 | 
  25 |     expect(
  26 |       headerTotals,
  27 |       "Business Check: Header counts must match expected values",
> 28 |     ).toStrictEqual(expected);
     |       ^ Error: Business Check: Header counts must match expected values
  29 |   });
  30 | }
  31 | 
  32 | export async function toggleFailedTestViewForTableandRaw(
  33 |   contractPage: ApiContractPage,
  34 | ) {
  35 |   const failedCount = await contractPage.getFailedResultsCount(0);
  36 | 
  37 |   await expect(contractPage.failedResultCountSpans.nth(0)).toBeVisible();
  38 | 
  39 |   await contractPage.clickFailedResults(0);
  40 | 
  41 |   await contractPage.verifyFailedScenariosCount(failedCount);
  42 | 
  43 |   await expect(contractPage.drillDownScenarios).toHaveCount(failedCount, {
  44 |     timeout: 10000,
  45 |   });
  46 | 
  47 |   await contractPage.toggleScenarioViews(0);
  48 | 
  49 |   await contractPage.toggleScenarioViews(failedCount - 1);
  50 | }
  51 | 
  52 | export async function verifyAllContractRemarks(contractPage: ApiContractPage) {
  53 |   // TODO: Add verification for the new /inventory endpoint once the spec is updated
  54 | 
  55 |   /* await contractPage.verifyRowRemark(
  56 |     "/products",
  57 |     "POST",
  58 |     "201",
  59 |     "covered"
  60 |   ); 
  61 |   */
  62 | 
  63 |   await contractPage.verifyRowRemark(
  64 |     "/findAvailableProducts",
  65 |     "GET",
  66 |     "200",
  67 |     /covered/i,
  68 |   );
  69 | 
  70 |   await contractPage.verifyRowRemark(
  71 |     "/ordres",
  72 |     "POST",
  73 |     "201",
  74 |     "not implemented",
  75 |   );
  76 | 
  77 |   await contractPage.verifyRowRemark("/health", "GET", "0", "Missing In Spec");
  78 | }
  79 | 
  80 | export async function verifyRightSidebarStatus(
  81 |   contractPage: ApiContractPage,
  82 |   status: "Running" | "Done" | "Failed",
  83 |   specName: string,
  84 | ) {
  85 |   await contractPage.rightSidebar.open();
  86 |   const actualStatus = await contractPage.getSidebarStatusText(specName);
  87 |   expect(actualStatus.toLowerCase()).toBe(status.toLowerCase());
  88 |   await contractPage.rightSidebar.close();
  89 | }
  90 | 
```