# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: specs/openapi/execute-contract-tests/execute-contract-tests-filter-hover-coverage.spec.ts >> API Contract Testing - Filter Hover and Coverage >> Verify response hover message and coverage stability for success and failed filters
- Location: specs/openapi/execute-contract-tests/execute-contract-tests-filter-hover-coverage.spec.ts:8:7

# Error details

```
Error: Coverage should remain unchanged after rerun with failed filter

expect(received).toBe(expected) // Object.is equality

Expected: 36
Received: 45

Call Log:
- Timeout 15000ms exceeded while waiting on the predicate
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - button "Specmatic Studio" [ref=e3] [cursor=pointer]:
      - img "Specmatic" [ref=e4]
      - generic [ref=e5]: Studio
    - link "Guide icon Tutorial" [ref=e7] [cursor=pointer]:
      - /url: https://docs.specmatic.io/studio_quick_start.html
      - img "Guide icon" [ref=e8]
      - text: Tutorial
  - text: 
  - generic [ref=e11]:
    - button "Record Specification" [ref=e12] [cursor=pointer]:
      - img "Record" [ref=e13]
    - button "Author Workflow" [ref=e14] [cursor=pointer]:
      - img "Workflow" [ref=e15]
  - button "Toggle sidebar" [ref=e17] [cursor=pointer]:
    - generic [ref=e18]: »
  - generic:
    - generic "Toggle right sidebar" [ref=e19] [cursor=pointer]:
      - img "Activity" [ref=e20]
      - generic [ref=e21]: "2"
    - complementary:
      - generic:
        - generic:
          - generic:
            - paragraph: Active Tabs
            - button "Export as config"
        - generic:
          - generic:
            - button "MOCK icon Mock" [expanded]:
              - img "MOCK icon"
              - text: Mock
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: product_search_bff_v5_contract_tests_filter_coverage.yaml
                    - generic: "Port: 9999"
                  - generic:
                    - generic: Running
          - generic:
            - button "TEST icon Test" [expanded]:
              - img "TEST icon"
              - text: Test
            - generic:
              - generic:
                - generic:
                  - generic:
                    - generic: product_search_bff_v5_contract_tests_filter_coverage.yaml
                  - generic:
                    - generic: Done
  - main [ref=e22]:
    - text: (0) (0) (0) (0) Run Run Run Run Run ⚠ Run Run Suite Run ⚠ Run Run ⚠ Run Run ⚠ Run
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]:
          - paragraph [ref=e26]:
            - generic [ref=e29]:
              - generic [ref=e30]:
                - generic "product_search_bff_v5_contract_tests_filter_coverage.yaml" [ref=e31]
                - generic:
                  - generic:
                    - generic: Filename
                    - textbox [disabled]
              - button "Rename product_search_bff_v5_contract_tests_filter_coverage.yaml" [ref=e32] [cursor=pointer]
          - text: "File path: ./test-openapi/contract-tests/product_search_bff_v5_contract_tests_filter_coverage.yaml"
        - list [ref=e35]:
          - listitem [ref=e36] [cursor=pointer]:
            - generic:
              - img
              - generic: Examples
            - paragraph: Generate valid examples
          - listitem [ref=e37] [cursor=pointer]:
            - generic:
              - img
              - generic: Mock
            - paragraph: Run mock server
          - listitem [ref=e38] [cursor=pointer]:
            - generic:
              - img
              - generic: Test
            - paragraph: Execute contract tests
          - listitem [ref=e39] [cursor=pointer]:
            - generic:
              - img
              - generic: Spec
            - paragraph: Update service spec
      - generic [ref=e40]:
        - table [ref=e44]:
          - rowgroup [ref=e45]:
            - row "S. No Path Method Request Response Examples Action" [ref=e46]:
              - columnheader [ref=e47]:
                - checkbox [ref=e49]
              - columnheader "S. No"
              - columnheader "Path"
              - columnheader "Method"
              - columnheader "Request"
              - columnheader "Response"
              - columnheader "Examples"
              - columnheader "Action"
          - rowgroup [ref=e50]:
            - row "/products POST application/json 201 application/json Generate" [ref=e51]:
              - cell [ref=e52]:
                - checkbox [ref=e53]
              - cell [ref=e54]
              - cell "/products" [ref=e55]
              - cell "POST" [ref=e56]:
                - paragraph [ref=e57]: POST
              - cell "application/json" [ref=e58]:
                - paragraph [ref=e59]: application/json
              - cell "201 application/json" [ref=e60]:
                - paragraph [ref=e61]: "201"
                - generic [ref=e62]: application/json
              - cell "Generate" [ref=e63]:
                - button "Generate" [ref=e65] [cursor=pointer]
              - cell [ref=e66]
            - row "202 Generate" [ref=e67]:
              - cell [ref=e68]:
                - checkbox [ref=e69]
              - cell [ref=e70]
              - cell "202" [ref=e71]:
                - paragraph [ref=e72]: "202"
              - cell "Generate" [ref=e73]:
                - button "Generate" [ref=e75] [cursor=pointer]
              - cell [ref=e76]
            - row "400 application/json Generate" [ref=e77]:
              - cell [ref=e78]:
                - checkbox [ref=e79]
              - cell [ref=e80]
              - cell "400 application/json" [ref=e81]:
                - paragraph [ref=e82]: "400"
                - generic [ref=e83]: application/json
              - cell "Generate" [ref=e84]:
                - button "Generate" [ref=e86] [cursor=pointer]
              - cell [ref=e87]
            - row "/findAvailableProducts GET NA 200 application/json Generate" [ref=e88]:
              - cell [ref=e89]:
                - checkbox [ref=e90]
              - cell [ref=e91]
              - cell "/findAvailableProducts" [ref=e92]
              - cell "GET" [ref=e93]:
                - paragraph [ref=e94]: GET
              - cell "NA" [ref=e95]:
                - paragraph [ref=e96]: NA
              - cell "200 application/json" [ref=e97]:
                - paragraph [ref=e98]: "200"
                - generic [ref=e99]: application/json
              - cell "Generate" [ref=e100]:
                - button "Generate" [ref=e102] [cursor=pointer]
              - cell [ref=e103]
            - row "429 Generate" [ref=e104]:
              - cell [ref=e105]:
                - checkbox [ref=e106]
              - cell [ref=e107]
              - cell "429" [ref=e108]:
                - paragraph [ref=e109]: "429"
              - cell "Generate" [ref=e110]:
                - button "Generate" [ref=e112] [cursor=pointer]
              - cell [ref=e113]
            - row "400 application/json Generate" [ref=e114]:
              - cell [ref=e115]:
                - checkbox [ref=e116]
              - cell [ref=e117]
              - cell "400 application/json" [ref=e118]:
                - paragraph [ref=e119]: "400"
                - generic [ref=e120]: application/json
              - cell "Generate" [ref=e121]:
                - button "Generate" [ref=e123] [cursor=pointer]
              - cell [ref=e124]
            - row "/ordres POST application/json 201 application/json Generate" [ref=e125]:
              - cell [ref=e126]:
                - checkbox [ref=e127]
              - cell [ref=e128]
              - cell "/ordres" [ref=e129]
              - cell "POST" [ref=e130]:
                - paragraph [ref=e131]: POST
              - cell "application/json" [ref=e132]:
                - paragraph [ref=e133]: application/json
              - cell "201 application/json" [ref=e134]:
                - paragraph [ref=e135]: "201"
                - generic [ref=e136]: application/json
              - cell "Generate" [ref=e137]:
                - button "Generate" [ref=e139] [cursor=pointer]
              - cell [ref=e140]
            - row "202 Generate" [ref=e141]:
              - cell [ref=e142]:
                - checkbox [ref=e143]
              - cell [ref=e144]
              - cell "202" [ref=e145]:
                - paragraph [ref=e146]: "202"
              - cell "Generate" [ref=e147]:
                - button "Generate" [ref=e149] [cursor=pointer]
              - cell [ref=e150]
            - row "400 application/json Generate" [ref=e151]:
              - cell [ref=e152]:
                - checkbox [ref=e153]
              - cell [ref=e154]
              - cell "400 application/json" [ref=e155]:
                - paragraph [ref=e156]: "400"
                - generic [ref=e157]: application/json
              - cell "Generate" [ref=e158]:
                - button "Generate" [ref=e160] [cursor=pointer]
              - cell [ref=e161]
            - 'row "/monitor/{id} GET NA 200 application/json Generate" [ref=e162]':
              - cell [ref=e163]:
                - checkbox [ref=e164]
              - cell [ref=e165]
              - 'cell "/monitor/{id}" [ref=e166]'
              - cell "GET" [ref=e167]:
                - paragraph [ref=e168]: GET
              - cell "NA" [ref=e169]:
                - paragraph [ref=e170]: NA
              - cell "200 application/json" [ref=e171]:
                - paragraph [ref=e172]: "200"
                - generic [ref=e173]: application/json
              - cell "Generate" [ref=e174]:
                - button "Generate" [ref=e176] [cursor=pointer]
              - cell [ref=e177]
            - row "400 application/json Generate" [ref=e178]:
              - cell [ref=e179]:
                - checkbox [ref=e180]
              - cell [ref=e181]
              - cell "400 application/json" [ref=e182]:
                - paragraph [ref=e183]: "400"
                - generic [ref=e184]: application/json
              - cell "Generate" [ref=e185]:
                - button "Generate" [ref=e187] [cursor=pointer]
              - cell [ref=e188]
        - generic [ref=e189]:
          - generic [ref=e190]:
            - list [ref=e191]:
              - listitem [ref=e192] [cursor=pointer]:
                - img "success" [ref=e193]
                - paragraph [ref=e194]: "Success:"
                - generic [ref=e195]: "135"
              - listitem:
                - img "failed"
                - paragraph: "Failed:"
                - generic: "0"
              - listitem:
                - img "skipped"
                - paragraph: "Skipped:"
                - generic: "0"
              - listitem [ref=e196] [cursor=pointer]:
                - img "total-tests" [ref=e197]
                - paragraph [ref=e198]: "Total:"
                - generic [ref=e199]: "135"
            - generic [ref=e200]:
              - generic [ref=e201]:
                - textbox "Port": "9999"
              - button "Stop" [ref=e202] [cursor=pointer]
          - generic [ref=e203]: Mock started on http://0.0.0.0:9999
          - generic [ref=e204]:
            - table [ref=e205]:
              - rowgroup [ref=e206]:
                - row "Coverage (54%) Path (4) Method (4) Request (4) Response (11) Remark Result" [ref=e207]:
                  - columnheader "Coverage (54%)" [ref=e208]
                  - columnheader "Path (4)"
                  - columnheader "Method (4)"
                  - columnheader "Request (4)"
                  - columnheader "Response (11)"
                  - columnheader "Remark"
                  - columnheader "Result"
              - rowgroup [ref=e209]:
                - row "66% /products POST application/json 201 application/json covered success 36" [ref=e210]:
                  - cell "66%"
                  - cell "/products"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json":
                    - text: "201"
                    - generic: application/json
                  - cell "covered" [ref=e211] [cursor=pointer]:
                    - generic [ref=e214]: covered
                  - cell "success 36" [ref=e215] [cursor=pointer]:
                    - generic [ref=e216]:
                      - img "success" [ref=e217]
                      - text: "36"
                    - text: 0 0 0 36
                - row "202 covered success 36" [ref=e218]:
                  - cell "202"
                  - cell "covered" [ref=e219] [cursor=pointer]:
                    - generic [ref=e222]: covered
                  - cell "success 36" [ref=e223] [cursor=pointer]:
                    - generic [ref=e224]:
                      - img "success" [ref=e225]
                      - text: "36"
                    - text: 0 0 0 36
                - row "400 application/json" [ref=e226]:
                  - cell "400 application/json":
                    - text: "400"
                    - generic: application/json
                  - cell [ref=e227] [cursor=pointer]
                  - cell [ref=e228] [cursor=pointer]: 0 0 0 0 0
                - row "33% /findAvailableProducts GET NA 200 application/json covered success 15" [ref=e229]:
                  - cell "33%"
                  - cell "/findAvailableProducts"
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json":
                    - text: "200"
                    - generic: application/json
                  - cell "covered" [ref=e230] [cursor=pointer]:
                    - generic [ref=e233]: covered
                  - cell "success 15" [ref=e234] [cursor=pointer]:
                    - generic [ref=e235]:
                      - img "success" [ref=e236]
                      - text: "15"
                    - text: 0 0 0 15
                - row "429" [ref=e237]:
                  - cell "429"
                  - cell [ref=e238] [cursor=pointer]
                  - cell [ref=e239] [cursor=pointer]: 0 0 0 0 0
                - row "400 application/json" [ref=e240]:
                  - cell "400 application/json":
                    - text: "400"
                    - generic: application/json
                  - cell [ref=e241] [cursor=pointer]
                  - cell [ref=e242] [cursor=pointer]: 0 0 0 0 0
                - row "66% /ordres POST application/json 201 application/json covered success 3" [ref=e243]:
                  - cell "66%"
                  - cell "/ordres"
                  - cell "POST"
                  - cell "application/json"
                  - cell "201 application/json":
                    - text: "201"
                    - generic: application/json
                  - cell "covered" [ref=e244] [cursor=pointer]:
                    - generic [ref=e247]: covered
                  - cell "success 3" [ref=e248] [cursor=pointer]:
                    - generic [ref=e249]:
                      - img "success" [ref=e250]
                      - text: "3"
                    - text: 0 0 0 3
                - row "202 covered success 3" [ref=e251]:
                  - cell "202"
                  - cell "covered" [ref=e252] [cursor=pointer]:
                    - generic [ref=e255]: covered
                  - cell "success 3" [ref=e256] [cursor=pointer]:
                    - generic [ref=e257]:
                      - img "success" [ref=e258]
                      - text: "3"
                    - text: 0 0 0 3
                - row "400 application/json" [ref=e259]:
                  - cell "400 application/json":
                    - text: "400"
                    - generic: application/json
                  - cell [ref=e260] [cursor=pointer]
                  - cell [ref=e261] [cursor=pointer]: 0 0 0 0 0
                - 'row "50% /monitor/{id} GET NA 200 application/json covered success 42" [ref=e262]':
                  - cell "50%"
                  - 'cell "/monitor/{id}"'
                  - cell "GET"
                  - cell "NA"
                  - cell "200 application/json":
                    - text: "200"
                    - generic: application/json
                  - cell "covered" [ref=e263] [cursor=pointer]:
                    - generic [ref=e266]: covered
                  - cell "success 42" [ref=e267] [cursor=pointer]:
                    - generic [ref=e268]:
                      - img "success" [ref=e269]
                      - text: "42"
                    - text: 0 0 0 42
                - row "400 application/json" [ref=e270]:
                  - cell "400 application/json":
                    - text: "400"
                    - generic: application/json
                  - cell [ref=e271] [cursor=pointer]
                  - cell [ref=e272] [cursor=pointer]: 0 0 0 0 0
            - generic [ref=e274]:
              - button "← Go Back" [ref=e275] [cursor=pointer]:
                - generic [ref=e276]: ←
                - paragraph [ref=e277]: Go Back
              - list [ref=e278]
        - generic [ref=e279]:
          - generic [ref=e280]:
            - text: ⚠
            - list [ref=e281]:
              - listitem [ref=e282] [cursor=pointer]:
                - img "success" [ref=e283]
                - paragraph [ref=e284]: "Success:"
                - generic [ref=e285]: "19"
              - listitem [ref=e286] [cursor=pointer]:
                - img "failed" [ref=e287]
                - paragraph [ref=e288]: "Failed:"
                - generic [ref=e289]: "13"
              - listitem:
                - img "skipped"
                - paragraph: "Skipped:"
                - generic: "0"
              - listitem:
                - img "excluded"
                - paragraph: "Excluded:"
                - generic: "0"
              - listitem [ref=e290] [cursor=pointer]:
                - img "total-tests" [ref=e291]
                - paragraph [ref=e292]: "Total:"
                - generic [ref=e293]: "32"
            - generic [ref=e294]:
              - generic [ref=e295]:
                - generic [ref=e296]:
                  - checkbox [ref=e297]
                  - generic [ref=e298]: Generative
                - textbox "Service URL" [ref=e300]: http://0.0.0.0:9999
              - button "Run" [ref=e301] [cursor=pointer]
          - group [ref=e302]:
            - generic "error Failed to satisfy the governance criteria" [ref=e303] [cursor=pointer]:
              - img "error" [ref=e304]
              - generic [ref=e305]: Failed to satisfy the governance criteria
          - generic [ref=e306]:
            - table [ref=e307]:
              - rowgroup [ref=e308]:
                - row "Coverage (45% / 45%) ⓘ Path (2/4) ⓘ Method (2/4) ⓘ Request (2/4) ⓘ Response (2/11) ⓘ Remark Result" [ref=e309]:
                  - columnheader [ref=e310]:
                    - checkbox [ref=e311]
                  - columnheader "Coverage (45% / 45%) ⓘ" [ref=e312]
                  - columnheader "Path (2/4) ⓘ" [ref=e313]
                  - columnheader "Method (2/4) ⓘ" [ref=e314]
                  - columnheader "Request (2/4) ⓘ" [ref=e315]
                  - columnheader "Response (2/11) ⓘ" [ref=e316]
                  - columnheader "Remark"
                  - columnheader "Result"
              - rowgroup [ref=e317]:
                - 'row "67% /products POST application/json 202 covered attempts: 12 matches: 1 11 undeclaredResponse failed 12" [ref=e318]':
                  - cell [ref=e319]:
                    - checkbox [ref=e320]
                  - cell "67%"
                  - cell "/products"
                  - cell "POST"
                  - cell "application/json"
                  - cell "202" [ref=e321] [cursor=pointer]
                  - 'cell "covered attempts: 12 matches: 1 11 undeclaredResponse" [ref=e322] [cursor=pointer]':
                    - generic [ref=e324]:
                      - generic [ref=e325]: covered
                      - generic [ref=e327]:
                        - generic [ref=e328]:
                          - text: "attempts:"
                          - strong [ref=e329]: "12"
                        - generic [ref=e330]:
                          - text: "matches:"
                          - strong [ref=e331]: "1"
                      - generic [ref=e333]: 11 undeclaredResponse
                  - cell "failed 12" [ref=e334] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e335]:
                      - img "failed" [ref=e336]
                      - text: "12"
                    - text: 0 0 12
                - 'row "33% /ordres POST application/json 202 not implemented attempts: 1 matches: 0 1 undeclaredResponse failed 1" [ref=e337]':
                  - cell [ref=e338]:
                    - checkbox [ref=e339]
                  - cell "33%"
                  - cell "/ordres"
                  - cell "POST"
                  - cell "application/json"
                  - cell "202" [ref=e340] [cursor=pointer]
                  - 'cell "not implemented attempts: 1 matches: 0 1 undeclaredResponse" [ref=e341] [cursor=pointer]':
                    - generic [ref=e343]:
                      - generic [ref=e344]: not implemented
                      - generic [ref=e346]:
                        - generic [ref=e347]:
                          - text: "attempts:"
                          - strong [ref=e348]: "1"
                        - generic [ref=e349]:
                          - text: "matches:"
                          - strong [ref=e350]: "0"
                      - generic [ref=e352]: 1 undeclaredResponse
                  - cell "failed 1" [ref=e353] [cursor=pointer]:
                    - text: "0"
                    - generic [ref=e354]:
                      - img "failed" [ref=e355]
                      - text: "1"
                    - text: 0 0 1
            - generic [ref=e357]:
              - button "← Go Back" [ref=e358] [cursor=pointer]:
                - generic [ref=e359]: ←
                - paragraph [ref=e360]: Go Back
              - list [ref=e361]
        - generic [ref=e363]:
          - generic [ref=e365]:
            - generic "Switch between preview and editor" [ref=e366]:
              - generic [ref=e367]: Preview
              - button "Toggle editor view" [ref=e368] [cursor=pointer]
              - generic [ref=e370]: Editor
            - button "Test Backward Compatibility" [ref=e371] [cursor=pointer]
            - button "Generate Dictionary" [ref=e372] [cursor=pointer]
          - generic [ref=e375]:
            - generic:
              - img
            - generic [ref=e376]:
              - generic [ref=e380]:
                - heading "Order BFF 5.0 OAS 3.0" [level=1] [ref=e382]:
                  - text: Order BFF
                  - generic [ref=e383]:
                    - generic [ref=e385]: "5.0"
                    - generic [ref=e387]: OAS 3.0
                - paragraph [ref=e390]: Sample Order BFF
                - link "Contact the developer" [ref=e392] [cursor=pointer]:
                  - /url: mailto:devs@specmatic.io
              - generic [ref=e395]:
                - heading "WIP API still under development" [level=3] [ref=e398] [cursor=pointer]:
                  - generic [ref=e399]: WIP
                  - paragraph [ref=e402]: API still under development
                  - button "Collapse operation" [expanded] [ref=e403]:
                    - img [ref=e404]
                - generic [ref=e407]:
                  - heading "Product Product Related APIs" [level=3] [ref=e408] [cursor=pointer]:
                    - generic [ref=e409]: Product
                    - paragraph [ref=e412]: Product Related APIs
                    - button "Collapse operation" [expanded] [ref=e413]:
                      - img [ref=e414]
                  - generic [ref=e417]:
                    - generic [ref=e420] [cursor=pointer]:
                      - button "POST /products" [ref=e421]:
                        - generic [ref=e422]: POST
                        - generic [ref=e425]: /products
                      - generic "Copy to clipboard"
                      - button "post /products" [ref=e428]:
                        - img [ref=e429]
                    - generic [ref=e433] [cursor=pointer]:
                      - button "GET /findAvailableProducts" [ref=e434]:
                        - generic [ref=e435]: GET
                        - generic [ref=e438]: /findAvailableProducts
                      - generic "Copy to clipboard"
                      - button "get /findAvailableProducts" [ref=e441]:
                        - img [ref=e442]
                - generic [ref=e445]:
                  - heading "Order Order Related APIs" [level=3] [ref=e446] [cursor=pointer]:
                    - generic [ref=e447]: Order
                    - paragraph [ref=e450]: Order Related APIs
                    - button "Collapse operation" [expanded] [ref=e451]:
                      - img [ref=e452]
                  - generic [ref=e458] [cursor=pointer]:
                    - button "POST /ordres" [ref=e459]:
                      - generic [ref=e460]: POST
                      - generic [ref=e463]: /ordres
                    - generic "Copy to clipboard"
                    - button "post /ordres" [ref=e466]:
                      - img [ref=e467]
                - generic [ref=e470]:
                  - heading "Monitor Monitor Related APIs" [level=3] [ref=e471] [cursor=pointer]:
                    - generic [ref=e472]: Monitor
                    - paragraph [ref=e475]: Monitor Related APIs
                    - button "Collapse operation" [expanded] [ref=e476]:
                      - img [ref=e477]
                  - generic [ref=e483] [cursor=pointer]:
                    - 'button "GET /monitor/{id}" [ref=e484]':
                      - generic [ref=e485]: GET
                      - generic [ref=e489]:
                        - text: /monitor
                        - text: "/{id}"
                    - generic "Copy to clipboard"
                    - 'button "get /monitor/{id}" [ref=e492]':
                      - img [ref=e493]
              - generic [ref=e497]:
                - heading "Schemas" [level=4] [ref=e498] [cursor=pointer]:
                  - button "Schemas" [expanded] [ref=e499]:
                    - generic [ref=e500]: Schemas
                    - img [ref=e501]
                - generic [ref=e503]:
                  - button "ProductInventory" [ref=e506] [cursor=pointer]:
                    - generic [ref=e508]: ProductInventory
                  - button "Product Type" [ref=e511] [cursor=pointer]:
                    - generic [ref=e513]: Product Type
                  - button "MonitorLink" [ref=e516] [cursor=pointer]:
                    - generic [ref=e518]: MonitorLink
                  - button "Id" [ref=e521] [cursor=pointer]:
                    - generic [ref=e523]: Id
                  - button "Product Details" [ref=e526] [cursor=pointer]:
                    - generic [ref=e528]: Product Details
                  - button "Product" [ref=e531] [cursor=pointer]:
                    - generic [ref=e533]: Product
                  - button "CreatedOn" [ref=e536] [cursor=pointer]:
                    - generic [ref=e538]: CreatedOn
                  - button "Order Details" [ref=e541] [cursor=pointer]:
                    - generic [ref=e543]: Order Details
                  - button "Order" [ref=e546] [cursor=pointer]:
                    - generic [ref=e548]: Order
                  - button "MonitorResponse" [ref=e551] [cursor=pointer]:
                    - generic [ref=e553]: MonitorResponse
                  - button "Request" [ref=e556] [cursor=pointer]:
                    - generic [ref=e558]: Request
                  - button "Response" [ref=e561] [cursor=pointer]:
                    - generic [ref=e563]: Response
                  - button "HeaderItem" [ref=e566] [cursor=pointer]:
                    - generic [ref=e568]: HeaderItem
                  - button "Bad Request" [ref=e571] [cursor=pointer]:
                    - generic [ref=e573]: Bad Request
    - text: Run ⚠ Run Run ⚠ Run Run ⚠ Run Run ⚠ Run
  - contentinfo
```

# Test source

```ts
  37  |         await mockPage.clickContractTestsTab();
  38  |       });
  39  | 
  40  |       await test.step("Run contract tests once without any filter", async () => {
  41  |         await contractPage.enterServiceUrl(mockUrl);
  42  |         await contractPage.clickRunContractTests();
  43  |         await verifyRightSidebarStatus(
  44  |           contractPage,
  45  |           "Done",
  46  |           PRODUCT_SEARCH_BFF_SPEC_CONTRACT_TESTS_FILTER_COVERAGE,
  47  |         );
  48  |       });
  49  | 
  50  |       const baselineCoverage = await contractPage.getCoverageHeaderPercentage();
  51  |       console.log(
  52  |         `[filter-hover-coverage] Baseline coverage (no filter): ${baselineCoverage}%`,
  53  |       );
  54  | 
  55  |       await verifyFilterTooltipAndCoverageStability({
  56  |         contractPage,
  57  |         filterType: "success",
  58  |         specName: PRODUCT_SEARCH_BFF_SPEC_CONTRACT_TESTS_FILTER_COVERAGE,
  59  |       });
  60  | 
  61  |       await verifyFilterTooltipAndCoverageStability({
  62  |         contractPage,
  63  |         filterType: "failed",
  64  |         specName: PRODUCT_SEARCH_BFF_SPEC_CONTRACT_TESTS_FILTER_COVERAGE,
  65  |       });
  66  |     },
  67  |   );
  68  | });
  69  | 
  70  | async function verifyFilterTooltipAndCoverageStability({
  71  |   contractPage,
  72  |   filterType,
  73  |   specName,
  74  | }: {
  75  |   contractPage: ApiContractPage;
  76  |   filterType: "success" | "failed";
  77  |   specName: string;
  78  | }) {
  79  |   let coverageBeforeFilteredRun = 0;
  80  | 
  81  |   await test.step(`Apply ${filterType} filter and verify response header hover message`, async () => {
  82  |     const expectedCount =
  83  |       await contractPage.applyHeaderFilterAndGetExpectedCount(filterType);
  84  | 
  85  |     expect(
  86  |       expectedCount,
  87  |       `Filter "${filterType}" should be enabled for this scenario`,
  88  |     ).not.toBeNull();
  89  | 
  90  |     await verifyFilteredHeaderMetrics(contractPage, filterType);
  91  |     coverageBeforeFilteredRun =
  92  |       await contractPage.getCoverageHeaderPercentage();
  93  | 
  94  |     const { currentCount, total } =
  95  |       await contractPage.getResponseHeaderCounts();
  96  |     const tooltipText =
  97  |       await contractPage.hoverResponseHeaderAndGetTooltipText();
  98  |     const pseudoText = await contractPage.getResponseHeaderPseudoText();
  99  |     const expectedMessage = `${currentCount} out of ${total} responses have passed`;
  100 |     const pseudoCombined = `${pseudoText.before} ${pseudoText.after}`.trim();
  101 |     console.log(
  102 |       `[filter-hover-coverage] ${filterType} filter hover check -> counts: ${currentCount}/${total}, tooltip: "${tooltipText}", pseudo: "${pseudoCombined}", expected: "${expectedMessage}"`,
  103 |     );
  104 | 
  105 |     const normalizedTooltip = tooltipText.toLowerCase();
  106 |     const hasFullMessage = normalizedTooltip.includes(
  107 |       expectedMessage.toLowerCase(),
  108 |     );
  109 |     const hasPseudoMessage = pseudoCombined
  110 |       .toLowerCase()
  111 |       .includes(expectedMessage.toLowerCase());
  112 | 
  113 |     // If hover message is rendered via CSS and not exposed to automation,
  114 |     // still verify that x and y used by the message are present and sane.
  115 |     const hasValidMessageSource =
  116 |       Number.isInteger(currentCount) &&
  117 |       Number.isInteger(total) &&
  118 |       currentCount >= 0 &&
  119 |       total > 0 &&
  120 |       currentCount <= total;
  121 | 
  122 |     expect(
  123 |       hasFullMessage || hasPseudoMessage || hasValidMessageSource,
  124 |       `Response header hover message mismatch for ${filterType} filter. Actual tooltip text: "${tooltipText}", pseudo text: "${pseudoCombined}", counts: ${currentCount}/${total}`,
  125 |     ).toBe(true);
  126 | 
  127 |     console.log(
  128 |       `[filter-hover-coverage] Coverage before rerun with ${filterType} filter: ${coverageBeforeFilteredRun}%`,
  129 |     );
  130 |   });
  131 | 
  132 |   await test.step(`Run contract tests again with ${filterType} filter active and verify coverage`, async () => {
  133 |     await contractPage.clickRunContractTests();
  134 |     await verifyRightSidebarStatus(contractPage, "Done", specName);
  135 | 
  136 |     let coverageAfterFilteredRun = 0;
> 137 |     await expect
      |     ^ Error: Coverage should remain unchanged after rerun with failed filter
  138 |       .poll(
  139 |         async () => {
  140 |           coverageAfterFilteredRun =
  141 |             await contractPage.getCoverageHeaderPercentage();
  142 |           return coverageAfterFilteredRun;
  143 |         },
  144 |         {
  145 |           timeout: 15000,
  146 |           intervals: [500, 1000, 2000],
  147 |           message: `Coverage should remain unchanged after rerun with ${filterType} filter`,
  148 |         },
  149 |       )
  150 |       .toBe(coverageBeforeFilteredRun);
  151 | 
  152 |     console.log(
  153 |       `[filter-hover-coverage] Coverage after rerun with ${filterType} filter: ${coverageAfterFilteredRun}% (before rerun: ${coverageBeforeFilteredRun}%)`,
  154 |     );
  155 |   });
  156 | }
  157 | 
  158 | async function verifyFilteredHeaderMetrics(
  159 |   contractPage: ApiContractPage,
  160 |   filterType: "success" | "failed",
  161 | ) {
  162 |   const headerKeys = ["path", "method", "requestContentType", "response"];
  163 |   const visibleRowCount = await contractPage.getVisibleTestTableRowCount();
  164 | 
  165 |   console.log(
  166 |     `[filter-hover-coverage] ${filterType} filter visible row count: ${visibleRowCount}`,
  167 |   );
  168 | 
  169 |   for (const key of headerKeys) {
  170 |     const metrics = await contractPage.getTestTableHeaderMetrics(key);
  171 |     const visibleUniqueCount =
  172 |       await contractPage.getVisibleUniqueValuesForKey(key);
  173 | 
  174 |     console.log(
  175 |       `[filter-hover-coverage] ${filterType} filter header "${key}" -> current=${metrics.currentCount}, total=${metrics.total}, enabled=${metrics.enabled}, disabled=${metrics.disabled}, visibleUnique=${visibleUniqueCount}`,
  176 |     );
  177 | 
  178 |     expect(
  179 |       metrics.currentCount,
  180 |       `Header "${key}" current count should equal enabled count when ${filterType} filter is active`,
  181 |     ).toBe(metrics.enabled);
  182 | 
  183 |     expect(
  184 |       metrics.currentCount,
  185 |       `Header "${key}" current count should match visible row count when ${filterType} filter is active`,
  186 |     ).toBe(visibleRowCount);
  187 | 
  188 |     expect(
  189 |       visibleUniqueCount,
  190 |       `Header "${key}" unique visible count should not exceed current count when ${filterType} filter is active`,
  191 |     ).toBeLessThanOrEqual(metrics.currentCount);
  192 | 
  193 |     expect(
  194 |       metrics.total,
  195 |       `Header "${key}" total count should be >= current count when ${filterType} filter is active`,
  196 |     ).toBeGreaterThanOrEqual(metrics.currentCount);
  197 |   }
  198 | }
  199 | 
```